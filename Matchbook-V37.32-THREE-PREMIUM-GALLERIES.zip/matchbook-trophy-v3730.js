/* MATCHBOOK V37.30 — Trophy Room V3. Presentation-only; all existing ceremony
 * and award outcome handlers remain authoritative, as does the shared outlook.
 */
(function(){
 'use strict';
 if(!window.MatchbookAwardOutlookV3726)return;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const names={ballon_dor:"Ballon d'Or",fifa_the_best:'The Best (FIFA)',european_golden_shoe:'European Golden Shoe',domestic_player_of_season:'Domestic Player of the Season',kopa_trophy:'Kopa Trophy',ucl_player_of_season:'UCL Player of the Season',playmaker_of_year:'Playmaker of the Year'};
 const icons={ballon_dor:'ball',kopa_trophy:'ball',european_golden_shoe:'boot',fifa_the_best:'silver'};
 const order=['ballon_dor','fifa_the_best','european_golden_shoe','domestic_player_of_season','kopa_trophy','ucl_player_of_season','playmaker_of_year','gerd_muller_trophy','yashin_trophy','puskas'];
 let tab='overview',chosenAward='',selectedSeason='';
 function art(id,small=false){
  const shape=icons[id]||'cup',w=small?51:105;
  const cup='<path d="M28 20h48l-4 34q-7 15-20 15T32 54z"/><path d="M30 30H17q-1 23 18 24M74 30h13q1 23-18 24" fill="none" stroke="currentColor" stroke-width="7"/><path d="M47 68h10v11H47zM33 79h38v8H33z"/>';
  const ball='<circle cx="52" cy="43" r="33"/><path d="m52 19 17 12-7 20H42l-7-20zM42 51 25 67m37-16 17 16M35 31 19 27m50 4 16-4M52 19V10" fill="none" stroke="#936627" stroke-width="1.6"/><path d="M39 78h26v9H39z"/>';
  const boot='<path d="M16 55c9-3 19-7 26-17l4-24 16 3 2 23 20 10q10 5 8 19l-78 1q-3-7 2-15z"/><path d="m40 42 23 9m-26-3 21 10m-23-3 17 10" fill="none" stroke="#956324" stroke-width="2"/>';
  return `<svg class="tr30-art tr30-art-${shape}" width="${w}" height="${Math.round(w*.95)}" viewBox="0 0 104 100" role="img" aria-label="Trophy illustration"><defs><linearGradient id="tr30-gold-${shape}" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#fff6d0"/><stop offset=".42" stop-color="#d9a23b"/><stop offset=".7" stop-color="#f4ce71"/><stop offset="1" stop-color="#986226"/></linearGradient><linearGradient id="tr30-silver" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#fff"/><stop offset=".5" stop-color="#a6a9b6"/><stop offset="1" stop-color="#5b6274"/></linearGradient></defs><g fill="url(#tr30-${shape==='silver'?'silver':'gold-'+shape})" stroke="${shape==='silver'?'#9295a4':'#b28137'}" stroke-width="2">${shape==='ball'?ball:shape==='boot'?boot:cup}</g></svg>`;
 }
 const statusTone=s=>/strong|serious|excellent|outstanding|favourite|won/i.test(s)?'good':/not currently|insufficient|limited|inconsistent|lost|declining/i.test(s)?'low':/radar|emerging|mixed|competitive/i.test(s)?'warm':'neutral';
 const pill=s=>`<span class="tr30-status tr30-status-${statusTone(s)}">${esc(s||'Not recorded')}</span>`;
 function choice(){
  const seasons=Array.isArray(db?.seasons)?db.seasons:[];
  const active=seasons.find(s=>String(s.id)===String(selectedSeason))||seasons.find(s=>String(s.id)===String(season))||seasons.at(-1);
  if(active)selectedSeason=String(active.id);
  return `<label class="tr30-season"><span class="sr-only">Season</span><select data-tr26-season aria-label="Trophy Room season">${seasons.map(s=>`<option value="${esc(s.id)}" ${String(s.id)===selectedSeason?'selected':''}>${esc(s.year||s.name||'Season')}</option>`).join('')}</select></label>`;
 }
 function data(){const s=(db.seasons||[]).find(s=>String(s.id)===String(selectedSeason));if(!s)return null;
  const helpers={matchView:typeof matchView==='function'?matchView:null,seasonTotals:typeof seasonTotals==='function'?seasonTotals:null,actionStats:typeof actionStats==='function'?actionStats:null,playerMatcher:typeof playerMatcher==='function'?playerMatcher:null};
  return {s,r:window.MatchbookAwardOutlookV3726.buildReport(db,s.id,helpers)};
 }
 function confirmed(s){const snap=s.awardsV3717?.seasonSnapshot;const comps=(snap?.snapshotLocked?snap.competitions:s.competitions)||[];
  const won=(Array.isArray(comps)?comps:[]).filter(c=>c&&String(c.status||'').toLowerCase()==='won'&&c.name);
  if(snap?.snapshotLocked&&Array.isArray(snap.trophies))for(const c of snap.trophies){if(String(c?.status||'won').toLowerCase()==='won'&&c.name&&!won.some(w=>String(w.name).toLowerCase()===String(c.name).toLowerCase()))won.push(c);}
  return won;
 }
 function stored(s,id){return s?.awardsV3717?.global?.[id]||null;}
 const expl=(id,children='View analysis')=>`<button type="button" class="tr30-link" data-mb28-evidence="${esc(id)}">${esc(children)} <span aria-hidden="true">↗</span></button>`;
 function trophyList(items,seasonLabel,club){return items.length?`<div class="tr30-trophy-grid">${items.map(c=>`<article class="tr30-trophy"><div class="tr30-trophy-art">${art('cup')}</div><div><strong>${esc(c.name)}</strong><span>${esc(c._season||seasonLabel||'')} ${c._club||club?'· '+esc(c._club||club):''}</span><small>Confirmed trophy</small></div></article>`).join('')}</div>`:'<p class="tr30-empty">No trophies won this season. Confirmed honours will appear here.</p>';}
 function progress(s){const snap=s.awardsV3717?.seasonSnapshot;const comps=(snap?.snapshotLocked?snap.competitions:s.competitions)||[];
  const pending=(Array.isArray(comps)?comps:[]).filter(c=>c?.name&&c.status&&!/won|not entered|not started|unknown/i.test(String(c.status)));
  if(!pending.length)return '';
  return `<details class="tr30-progress"><summary>Competition progress · ${pending.length} active records</summary><div>${pending.map(c=>`<div><strong>${esc(c.name)}</strong><span>${esc(c.status)}</span></div>`).join('')}</div></details>`;
 }
 function overviewAwards(r){return order.map(id=>r.outlook?.find(a=>a.id===id)).filter(Boolean);}
 function bestAward(r){const arr=overviewAwards(r).filter(a=>(a.level??0)>0);return arr.slice().sort((a,b)=>(b.level??0)-(a.level??0)||order.indexOf(a.id)-order.indexOf(b.id))[0]||null;}
 function awardSummary(a,feature=false){const detail=a.evidence?.[0]||a.conditions?.[0]||'Available career evidence is limited.';
  if(feature)return `<div class="tr30-feature"><div class="tr30-feature-text"><small>FEATURED AWARD OUTLOOK · NOT AN OFFICIAL RESULT</small><h2>${esc(a.name)}</h2>${pill(a.label)}<p>${esc(detail)}</p>${expl(a.id)}</div><div class="tr30-feature-trophy">${art(a.id)}</div></div>`;
  return `<article class="tr30-race" data-tr30-feature="${esc(a.id)}" tabindex="0" aria-label="Feature ${esc(a.name)}"><div class="tr30-race-icon">${art(a.id,true)}</div><div class="tr30-race-info"><strong>${esc(a.name)}</strong>${pill(a.label)}<p>${esc(detail)}</p></div>${expl(a.id)}</article>`;
 }
 const dims=[['Individual Performance','individual','individual'],['Recent Form','form','form'],['Consistency','consistency','consistency'],['Big-Match Influence','big','big'],['Collective Achievements','team','team'],['European Performance','europe','europe']];
 function dimensions(r,limit=6){return `<div class="tr30-dimension-list">${dims.slice(0,limit).map(([name,id,key])=>{
   const v=r[key]||{},evidence=id==='form'?v.summary:id==='individual'?v.evidence?.[0]:v.evidence||v.contributionNote||'Read recorded match evidence';
   return `<button type="button" class="tr30-dimension" data-mb28-evidence="${id}"><span class="tr30-dim-glyph" aria-hidden="true">${({individual:'◈',form:'↗',consistency:'≋',big:'★',team:'♜',europe:'◎'})[id]}</span><span class="tr30-dim-text"><strong>${esc(name)}</strong><small>${esc(evidence||'Limited evidence available.')}</small></span>${pill(v.label||'Insufficient data')}<span class="tr30-dim-arrow" aria-hidden="true">›</span></button>`;
 }).join('')}</div>`;}
 function history(max=100){const rows=(db.seasons||[]).slice().reverse().flatMap(s=>{
   const a=s.awardsV3717||{};const globals=Object.entries(a.global||{}).filter(([,v])=>v&&(v.status==='Won'||v.status==='Lost'||v.status==='Nominated'||v.stage==='resolved')).map(([id,v])=>({id:`${s.id}-${id}`,name:names[id]||id,season:s.year||s.name,status:v.status||'Resolved'}));
   const manual=(a.manualAwards||[]).filter(x=>x&&(x.status==='Won'||x.status==='Nominated')).map((x,i)=>({id:`${s.id}-manual-${i}`,name:x.label||x.type,season:s.year||s.name,status:x.status}));
   const explicit=Object.entries(s.awardResultsV4||{}).map(([id,v])=>({id:`${s.id}-v4-${id}`,name:names[id]||id.replaceAll('_',' '),season:s.year||s.name,status:`${v.kind==='official'?'Confirmed':'Simulated'} · ${v.winner?'Winner':v.placement?'Place '+v.placement:v.nomination} · ${v.source}`}));
   return [...explicit,...globals.map(v=>({...v,status:'Legacy ceremony · '+v.status})),...manual];
 });
  return rows.length?rows.slice(0,max).map(x=>`<div class="tr30-history-row"><strong>${esc(x.season)}</strong><span>${esc(x.name)}</span>${pill(x.status)}</div>`).join(''):'<p class="tr30-empty">No confirmed nominations or award results recorded.</p>';
 }
 function awardsHistory(s,r){const ids=order.filter(id=>r.outlook.some(x=>x.id===id));return `<div class="tr30-award-history">${ids.map(id=>{
  const a=r.outlook.find(a=>a.id===id),o=stored(s,id);const label=o?('Legacy ceremony: '+(o.status||'Recorded')):'No confirmed result';
  return `<article class="tr30-history-award"><span class="tr30-history-icon">${art(id,true)}</span><div class="tr30-history-copy"><strong>${esc(a.name)}</strong><small>${esc(r.seasonLabel)} · ${esc(label)}</small></div>${pill(a.label)}${expl(id)}</article>`;
 }).join('')}</div>`;}
 function ceremony(){const html=window.matchbookAwardsV3719?.awardRoom?.()||'';
  if(!html)return '<p class="tr30-empty">No saved ceremonies available for this season.</p>';
  const node=document.createElement('div');node.innerHTML=html;const el=node.querySelector('.aw19-nominations');return el?el.outerHTML:'<p class="tr30-empty">No ceremony records found.</p>';
 }
 function overview(s,r){if(window.MatchbookAwardsV4UI)return window.MatchbookAwardsV4UI.overview(s,r);const all=overviewAwards(r);const eligible=bestAward(r);const selected=all.find(a=>a.id===chosenAward&&(a.level??0)>0)||eligible;
  const others=all.filter(a=>a.id!==selected?.id);
  const featured=selected?awardSummary(selected,true):`<div class="tr30-feature"><div class="tr30-feature-text"><small>SEASON IN PROGRESS</small><h2>Award candidacy is developing</h2><p>${esc(r.totals.matches)} appearances recorded. More verified performances are needed before an eligible award can be highlighted.</p><button type="button" class="tr30-link" data-tr30-tab="outlook">Explore performance analysis →</button></div><div class="tr30-feature-trophy">${art('cup')}</div></div>`;
  return `<section class="tr30-topline"><div><small>SEASON OUTLOOK</small><h2>Awards, performances & achievements</h2><p>Live analytical assessments. A candidacy is not a nomination or confirmed victory.</p></div><div class="tr30-quicknumbers"><div><strong>${esc(r.totals.matches)}</strong><span>Appearances</span></div><div><strong>${esc(r.totals.goals)} / ${esc(r.totals.assists)}</strong><span>Goals / Assists</span></div><div><strong>${esc(r.totals.rating??'—')}</strong><span>Avg rating</span></div></div></section>
  <div class="tr30-hero-grid">${featured}<section class="tr30-side-summary"><small>SEASON PERFORMANCE</small><h3>What shapes the candidacy?</h3>${dimensions(r,3)}<button type="button" class="tr30-subtle-link" data-tr30-tab="outlook">All performance assessments →</button></section></div>
  <section class="tr30-panel"><header class="tr30-panel-head"><div><small>OTHER AWARD RACES</small><h2>Individual recognition</h2></div><span>Click an award to explore its evidence</span></header><div class="tr30-races">${others.map(a=>awardSummary(a)).join('')}</div></section>
  <div class="tr30-lower-grid"><section class="tr30-panel"><header class="tr30-panel-head"><div><small>CONFIRMED HONOURS</small><h2>Trophy Cabinet</h2></div><button type="button" class="tr30-subtle-link" data-tr30-tab="trophies">All honours →</button></header>${trophyList(confirmed(s),s.year||s.name,r.club)}${progress(s)}</section><section class="tr30-panel"><header class="tr30-panel-head"><div><small>SAVED RESULTS</small><h2>Award history</h2></div><button type="button" class="tr30-subtle-link" data-tr30-tab="history">Full history →</button></header>${history(3)}</section></div>`;
 }
 function outlook(r){return `<section class="tr30-panel"><header class="tr30-panel-head"><div><small>PERFORMANCE ASSESSMENT</small><h2>Six dimensions of the season</h2><p>Form, consistency, individual impact and team success are assessed independently.</p></div></header>${dimensions(r)}</section><section class="tr30-panel"><header class="tr30-panel-head"><div><small>AWARD OUTLOOK</small><h2>Each award has its own criteria</h2></div></header><div class="tr30-races">${overviewAwards(r).map(a=>awardSummary(a)).join('')}</div></section>`;}
 function trophies(s,r){const across=(db.seasons||[]).flatMap(se=>confirmed(se).map(c=>({c,se})));
  return `<section class="tr30-panel"><header class="tr30-panel-head"><div><small>TROPHY CABINET</small><h2>Confirmed career honours</h2><p>Final appearances and ongoing competition progress never count as trophies won.</p></div></header>${across.length?trophyList(across.map(({c,se})=>({...c,_season:se.year||se.name,_club:se.club})),'',''):trophyList([])}${progress(s)}</section>`;}
 function individual(s,r){return `<section class="tr30-panel"><header class="tr30-panel-head"><div><small>AWARD CEREMONIES</small><h2>Nominations & decisions</h2><p>Saved ceremony records and existing confirmation controls. Matchbook-generated outcomes are simulated career results.</p></div></header><div class="tr30-ceremony">${ceremony()}</div></section>`;}
 function screen(){if(!(db.seasons||[]).length)return '<section class="tr30"><p class="tr30-empty">Create a season to view your honours.</p></section>';
  const selector=choice(),payload=data();if(!payload?.r)return '<section class="tr30">No season report available.</section>';
  const {s,r}=payload,p=s.playerProfile||db.profile||{};
  const portrait=typeof playerPhotoMarkup==='function'?playerPhotoMarkup('tr30-photo',p):`<span class="tr30-avatar-fallback">${esc(String(p.name||'P').charAt(0))}</span>`;
  const pageBody=tab==='overview'?overview(s,r):tab==='outlook'?outlook(r):tab==='trophies'?trophies(s,r):tab==='individual'?individual(s,r):`<section class="tr30-panel"><header class="tr30-panel-head"><div><small>RECORDED HISTORY</small><h2>Career recognition</h2></div></header>${history()}</section>`;
  return `<div class="tr30"><header class="tr30-header"><div class="tr30-identity">${portrait}<div><strong>${esc(p.name||'Player')}</strong><span>${esc(r.club||'Club unknown')} · #${esc(p.number||'—')} · ${esc(r.position||'Position not recorded')}</span></div></div><div class="tr30-heading"><small>MATCHBOOK / HONOURS & AWARDS</small><h1>The Trophy Room</h1><p>The awards and defining moments of your football career</p></div>${selector}</header><nav class="tr30-tabs" aria-label="Trophy Room sections">${[['overview','Trophy Room'],['trophies','Trophy Cabinet'],['individual','Ceremonies'],['history','History']].map(([k,label])=>`<button type="button" data-tr30-tab="${k}" aria-current="${tab===k?'page':'false'}" class="${tab===k?'active':''}">${label}</button>`).join('')}</nav><main class="tr30-main">${pageBody}</main><footer class="tr30-foot">Every season. Every honour. Your football story.</footer></div>`;
 }
 const previous=typeof managementView==='function'?managementView:null;
 if(previous)managementView=function(){return page==='Awards'?screen():previous();};
 document.addEventListener('click',e=>{
  if(page!=='Awards')return;
  const feature=e.target.closest?.('[data-tr30-feature]');
  if(feature&&!e.target.closest('[data-mb28-evidence]')){chosenAward=feature.dataset.tr30Feature;tab='overview';if(typeof render==='function')render();return;}
  const btn=e.target.closest?.('[data-tr30-tab]');if(!btn)return;
  e.preventDefault();if(btn.dataset.tr30Tab==='overview')window.MatchbookAwardsV4UI?.home();tab=btn.dataset.tr30Tab;if(typeof render==='function')render();
 });
 document.addEventListener('keydown',e=>{if(page!=='Awards'||!['Enter',' '].includes(e.key))return;const feature=e.target.closest?.('[data-tr30-feature]');if(feature&&e.target===feature){e.preventDefault();chosenAward=feature.dataset.tr30Feature;tab='overview';if(typeof render==='function')render();}});
 document.addEventListener('change',e=>{if(e.target.matches?.('[data-tr26-season]')&&page==='Awards'){selectedSeason=e.target.value;chosenAward='';if(typeof render==='function')render();}});
 window.MatchbookTrophyRoomV3730={screen,art,showOverview(){tab='overview';},selectSeason(id){selectedSeason=String(id)},version:'37.30'};
})();
