/* V37.28 - Evidence modal. Reads the SAME calculation report that renders Awards.
   Never writes to match history, snapshots, ceremonies or data storage. */
(function(){
 'use strict';
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const text=v=>v===null||v===undefined||v===''?'—':String(v);
 const details={
  individual:['Individual Performance','Season games, minutes, goal involvements, ratings, position-adjusted creation and defensive actions. Small samples reduce confidence.'],
  form:['Individual Form','Last five and ten rated games; average recent ratings and comparison to the previous five.'],
  consistency:['Consistency','Dispersion (standard deviation) of recorded match ratings, strong/poor games, and number of rated games.'],
  goals:['Goalscoring','Verified goals, minutes and recorded shooting events; no missing shots are invented.'],
  assists:['Assists & Creativity','Verified assists plus recorded key passes and big chances created; availability depends on tracking coverage.'],
  big:['Big-Match Influence','Only matches selected by the shared knockout-stage / recorded-opponent-difficulty classifier; player performance is assessed separately.'],
  team:['Collective Achievements','Confirmed saved titles and available participation. Progress and semifinal appearances do not count as trophies won.'],
  europe:['European Performance','Separate UCL, UEL and UECL fixture totals and knockout context; unknown games are not assigned a competition.']
 };
 let lastFocus=null,lastSeasonId=null;
 function getReport(){
  const seasons=db.seasons||[],id=document.querySelector('[data-tr26-season]')?.value||season;
  const pick=seasons.some(s=>String(s.id)===String(id))?id:seasons[0]?.id;
  return window.MatchbookAwardOutlookV3726?.buildReport(db,pick,{
   matchView:typeof matchView==='function'?matchView:null,
   seasonTotals:typeof seasonTotals==='function'?seasonTotals:null,
   actionStats:typeof actionStats==='function'?actionStats:null,
   playerMatcher:typeof playerMatcher==='function'?playerMatcher:null
  });
 }
 const line=(name,value)=>`<div class="mb28-metric"><span>${esc(name)}</span><b>${esc(text(value))}</b></div>`;
 function factList(items){return items?.length?`<ul>${items.filter(Boolean).map(v=>`<li>${esc(v)}</li>`).join('')}</ul>`:'<p class="mb28-muted">No verified information available.</p>';}
 function matchRows(rows,showReasons=false){
  if(!rows.length)return '<p class="mb28-muted">No qualifying recorded matches for this season.</p>';
  return `<div class="mb28-match-list">${rows.map(m=>{
    const more=showReasons?`<small class="mb29-importance">${esc(m.importance||'Important Match')}</small><small class="mb29-reason">${esc((m.reasons||[]).join(' · ')||'Reason not recorded')}</small>${m.ranking?`<small class="mb30-rank-source">${esc(m.ranking.source)} · ${esc(m.ranking.snapshotDate)} · ${esc(m.ranking.basis==='retrospective-season-baseline'?'2024/25 retrospective baseline; not an exact match-day ranking':m.ranking.basis)}</small>`:''}`:'';'';
    return `<button type="button" class="mb28-match" data-mb28-match="${esc(m.id)}"><div><b>${esc(m.opponent||'Opponent not recorded')}</b><small>${esc(m.date||'Date not recorded')} · ${esc(m.competition||'Competition not recorded')}${m.stage?' · '+esc(m.stage):''}</small>${more}</div><div class="mb28-match-stats"><strong>${esc(m.score||'—')}</strong><small>${esc(text(m.minutes))}′ · rating ${esc(text(m.rating))}</small><small>${esc(text(m.goals))} G · ${esc(text(m.assists))} A</small>${m.keyPasses!==null&&m.keyPasses!==undefined?`<small>${esc(m.keyPasses)} key passes</small>`:''}</div></button>`;
  }).join('')}</div>`;
 }
 function makeData(r,id){
  const award=r.outlook.find(a=>a.id===id);
  if(award){
   const scoped=award.rows?window.MatchbookAwardOutlookV3726.aggregate(award.rows):r.totals;
   const related=award.rows|| (id==='european_golden_shoe'||id==='domestic_player_of_season'?r.rows.filter(x=>x.category==='League'):id==='ucl_player_of_season'?r.rows.filter(x=>x.category==='UCL'):id==='playmaker_of_year'?r.rows:id==='ballon_dor'||id==='fifa_the_best'?r.rows:[]);
   return {title:award.name,label:award.label,scope:id==='european_golden_shoe'||id==='domestic_player_of_season'?'Domestic league':id==='ucl_player_of_season'?'Champions League':'Season',metrics:[[id==='european_golden_shoe'?'Golden Shoe league-goal points':'Matchbook Assessment (not official votes)',award.score],...(award.thresholds||[]).map((t,i)=>[['On the radar','Emerging contender','Serious contender','TOP 10-level threshold','Favourite-level threshold'][i],t]),...(award.components||[]).map(c=>[c.name,`${c.points??'Unknown'} / ${c.max}`]),...Object.entries(award.gates||{}).map(([k,v])=>['Gate: '+k,v?'Met':'Not met']),['Recorded appearances',scoped.matches],['Goals',scoped.goals],['Assists',scoped.assists],['Average rating',scoped.rating],['Key passes',scoped.keyPasses]],evidence:award.evidence,limits:[...(award.conditions||[]),...(award.limits||[])],method:award.method||`Award-specific analytical criteria use the same Season Performance Assessment and the relevant eligible matches. This is an outlook, not an official nomination or guaranteed rank.`,rows:related};
  }
  const part=details[id];if(!part)return null;
  const total=r.totals,base=[['Appearances',total.matches],['Minutes',total.minutes],['Goals',total.goals],['Assists',total.assists],['Average rating',total.rating]],all=r.rows;
  const dim={individual:r.individual,form:r.form,consistency:r.consistency,big:r.big,team:r.team,europe:r.europe}[id];
  const big=r.big?.qualifiedMatches||[];
  const metrics=id==='consistency'?[['Rated matches',all.filter(x=>x.rating!=null).length],['Rating standard deviation',r.consistency.std],['Strong performances (7.5+)',r.consistency.strong],['Low performances (<6.5)',r.consistency.poor]]:id==='big'?[['Qualifying matches',r.big.matches],['Goals',r.big.stats.goals],['Assists',r.big.stats.assists],['Average rating',r.big.stats.rating],['Key passes',r.big.stats.keyPasses]]:id==='europe'?[['European appearances',r.europe.count],...r.europe.competitions.map(x=>[x.id+' appearances',x.stats.matches])]:id==='goals'?[['Goals',total.goals],['Goals / 90',total.g90],['Shot conversion (%)',total.conversion],['Available recorded xG',total.xg]]:id==='assists'?[['Assists',total.assists],['Assists / 90',total.a90],['Recorded key passes',total.keyPasses],['Recorded big chances created',total.bigChances]]:base;
  const selection=id==='big'?big:id==='europe'?all.filter(x=>['UCL','UEL','UECL'].includes(x.category)):id==='form'?all.slice(-10):all;
  let supporting=[];
  if(id==='individual')supporting=r.individual.evidence||[];
  else if(id==='big')supporting=[r.big.evidence];
  else if(id==='team')supporting=[r.team.evidence,r.team.contributionNote];
  else if(id==='europe')supporting=[r.europe.evidence];
  else if(id==='consistency')supporting=[r.consistency.evidence];
  else if(id==='form')supporting=[r.form.summary];
  else supporting=[`${total.goals} verified goals and ${total.assists} verified assists across ${total.matches} appearances`];
  const limits=[...(dim?.limitations||[]),...(id==='big'?r.big.limitations||[]:[]),...(total.matches<5?['Very small match sample']:[]),...(r.coverage.baseAppearances?['Some imported historical appearances have no detailed match-level breakdown']:[])];
  return {title:part[0],label:dim?.label || (id==='goals'?`${total.goals} recorded goals`:`${total.assists} recorded assists`),scope:id==='big'?'Big Matches':id==='europe'?'European competitions':'All recorded season matches',metrics,evidence:supporting,limits,method:part[1],rows:selection,reason:id==='big'};
 }
 function close(){document.getElementById('mb28-evidence-modal')?.remove();lastFocus?.focus?.();lastFocus=null;}
 function open(id){
  const r=getReport();if(!r)return;
  const data=makeData(r,id);if(!data)return;
  close();lastFocus=document.activeElement;lastSeasonId=r.seasonId;
  const node=document.createElement('div');node.id='mb28-evidence-modal';node.className='mb28-overlay';
  node.innerHTML=`<section class="mb28-dialog" role="dialog" aria-modal="true" aria-labelledby="mb28-evidence-title">
   <header><div><small>MATCHBOOK PERFORMANCE ASSESSMENT · ${esc(r.seasonLabel)} · ${esc(data.scope)}</small><h2 id="mb28-evidence-title">${esc(data.title)}</h2><span class="mb28-status">${esc(data.label)}</span></div><button type="button" data-mb28-close aria-label="Close analysis">✕</button></header>
   <div class="mb28-content"><section><h3>Supporting statistics</h3><div class="mb28-metrics">${data.metrics.map(([name,value])=>line(name,value)).join('')}</div></section>
   <section><h3>Positive evidence</h3>${factList(data.evidence)}</section>
   <section><h3>Limits and missing data</h3>${factList(data.limits)}</section>
   <section><h3>Contributing matches · ${data.rows.length}</h3>${matchRows(data.rows,data.reason)}</section>
   <details class="mb28-method"><summary>How was this calculated?</summary><p>${esc(data.method)}</p><p>Matchbook only counts saved match records; incomplete or unknown inputs are not invented. Confirmed awards remain independent from this assessment.</p></details></div>
   <footer>${id==='big'?'<button type="button" data-mb28-open-stats>View these Big Matches in Statistics</button>':''}<button type="button" data-mb28-close>Close</button></footer>
  </section>`;
  document.body.append(node);node.querySelector('[data-mb28-close]')?.focus();
 }
 document.addEventListener('click',e=>{
  const target=e.target.closest?.('[data-mb28-evidence], [data-mb28-close], [data-mb28-match], [data-mb28-open-stats]');
  if(target?.hasAttribute('data-mb28-evidence')){e.preventDefault();open(target.dataset.mb28Evidence);}
  else if(target?.hasAttribute('data-mb28-close')){e.preventDefault();close();}
  else if(target?.hasAttribute('data-mb28-match')){const id=target.dataset.mb28Match;close();if(typeof act==='function')act('recap:'+id);}
  else if(target?.hasAttribute('data-mb28-open-stats')){const chosen=lastSeasonId;close();if(chosen&&db.seasons.some(s=>String(s.id)===String(chosen)))season=chosen;analyticsState.bigMatches=true;statsCompetition='';if(typeof profileCompetitionCategory==='string')profileCompetitionCategory='all';page='Statistics';if(typeof render==='function')render();}
  else if(e.target?.id==='mb28-evidence-modal')close();
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.getElementById('mb28-evidence-modal'))close();});
 window.MatchbookAwardsEvidenceV3728={open};
})();
