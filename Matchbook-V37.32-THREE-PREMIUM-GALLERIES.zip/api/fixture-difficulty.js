const FDB_BASE='https://footballdatabase.com/ranking/world';
const ELO_FALLBACK='https://raw.githubusercontent.com/xgabora/Club-Football-Match-Data/main/data/EloRatings.csv';
const HOME_ADVANTAGE_FDB=55;
const HOME_ADVANTAGE_ELO=65;
const CACHE_TTL=12*60*60*1000;
const rankingCache={at:0,rows:[],sourceUpdatedAt:''};
const eloCache={at:0,rows:[],sourceUpdatedAt:''};

function decodeHtml(s=''){
 return String(s).replace(/<br\s*\/?\s*>/gi,' ').replace(/&amp;/g,'&').replace(/&nbsp;/g,' ').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&ndash;|&mdash;/g,'-').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
}
function normalize(s=''){
 return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ß/g,'ss').replace(/ł/g,'l').replace(/ø/g,'o').replace(/æ/g,'ae').replace(/œ/g,'oe').replace(/\bsaint\b/g,'st').replace(/[^a-z0-9]+/g,' ').trim();
}
const GENERIC=new Set(['fc','cf','afc','ac','sc','sl','ssc','rcd','club','calcio','football','futbol','de','the','real']);
function tokens(s=''){return normalize(s).split(/\s+/).filter(Boolean).filter(x=>!GENERIC.has(x))}
function compact(s=''){return tokens(s).join('')}
function scoreName(alias,name){
 const a=compact(alias),b=compact(name);if(!a||!b)return 0;if(a===b)return 100;
 const an=normalize(alias).replace(/\s+/g,''),bn=normalize(name).replace(/\s+/g,'');if(an===bn)return 99;
 if(Math.min(a.length,b.length)>=5&&(a.includes(b)||b.includes(a)))return 93;
 const at=new Set(tokens(alias)),bt=new Set(tokens(name)),common=[...at].filter(x=>bt.has(x)).length,union=new Set([...at,...bt]).size,j=union?common/union:0;
 return j>=.8?92:j>=.66?88:j>=.5&&common>=2?84:0;
}
function bestMatch(aliases,rows,min=88){
 let best=null,bestScore=0;
 for(const row of rows)for(const alias of aliases||[]){const s=scoreName(alias,row.name);if(s>bestScore){best=row;bestScore=s}}
 return bestScore>=min?{...best,confidence:bestScore}:null;
}
function parseFdbRows(html){
 const out=[];
 for(const m of String(html).matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
  const raw=m[1],cells=[...raw.matchAll(/<(?:td|th)\b[^>]*>([\s\S]*?)<\/(?:td|th)>/gi)].map(x=>x[1]);
  if(cells.length<3)continue;
  const rank=Number((decodeHtml(cells[0]).match(/\b\d{1,5}\b/)||[])[0]);
  let name='';
  const clubLink=raw.match(/<a\b[^>]*href=["'][^"']*\/clubs-ranking\/[^"']+["'][^>]*>([\s\S]*?)<\/a>/i);
  if(clubLink)name=decodeHtml(clubLink[1]);
  if(!name){
   const anchors=[...cells[1].matchAll(/<a\b[^>]*>([\s\S]*?)<\/a>/gi)].map(x=>decodeHtml(x[1])).filter(Boolean);
   name=anchors.sort((a,b)=>b.length-a.length)[0]||decodeHtml(cells[1]);
  }
  let points=0;
  for(const cell of cells.slice(2)){const nums=decodeHtml(cell).match(/\b\d{3,4}\b/g)||[];for(const n of nums){const v=Number(n);if(v>=1000&&v<=2500){points=v;break}}if(points)break}
  if(rank&&name&&points)out.push({rank,name,points});
 }
 return out;
}
function parseUpdated(html){const m=String(html).match(/Updated after matches played on\s*([^<\n]+)/i);return m?decodeHtml(m[1]):''}
async function fetchFdbPage(page){
 const url=`${FDB_BASE}/${page}`;
 const r=await fetch(url,{headers:{'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36','accept':'text/html,application/xhtml+xml','accept-language':'en-GB,en;q=0.9','cache-control':'no-cache'},redirect:'follow'});
 if(!r.ok)throw new Error(`FootballDatabase ${r.status}`);
 const html=await r.text();return {rows:parseFdbRows(html),updated:parseUpdated(html)};
}
function uniqueRows(rows){const map=new Map();for(const r of rows){const k=normalize(r.name);if(!k)continue;const old=map.get(k);if(!old||Number(r.points)>0)map.set(k,r)}return [...map.values()]}
async function fdbRowsFor(aliasGroups){
 if(rankingCache.rows.length&&Date.now()-rankingCache.at<CACHE_TTL){const allFound=aliasGroups.every(g=>bestMatch(g,rankingCache.rows));if(allFound)return {...rankingCache,sourceName:'FootballDatabase'}}
 let rows=[...rankingCache.rows],sourceUpdatedAt=rankingCache.sourceUpdatedAt||'';
 for(let start=1;start<=24;start+=3){
  const pages=[start,start+1,start+2].filter(x=>x<=24);
  const settled=await Promise.allSettled(pages.map(fetchFdbPage));
  let success=false;
  for(const item of settled){if(item.status==='fulfilled'){success=true;rows.push(...item.value.rows);if(!sourceUpdatedAt&&item.value.updated)sourceUpdatedAt=item.value.updated}}
  rows=uniqueRows(rows);
  if(aliasGroups.every(g=>bestMatch(g,rows)))break;
  if(!success&&start===1)throw new Error('FootballDatabase unavailable');
 }
 if(!rows.length)throw new Error('No FootballDatabase rows parsed');
 rankingCache.at=Date.now();rankingCache.rows=rows;rankingCache.sourceUpdatedAt=sourceUpdatedAt;
 return {rows,sourceUpdatedAt,sourceName:'FootballDatabase'};
}
function csvCells(line){
 const out=[];let cur='',quoted=false;
 for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'){if(quoted&&line[i+1]==='"'){cur+='"';i++}else quoted=!quoted}else if(ch===','&&!quoted){out.push(cur);cur=''}else cur+=ch}out.push(cur);return out;
}
async function fallbackEloRows(){
 if(eloCache.rows.length&&Date.now()-eloCache.at<CACHE_TTL)return {...eloCache,sourceName:'Open Elo dataset'};
 const r=await fetch(ELO_FALLBACK,{headers:{'user-agent':'Matchbook/1.0','accept':'text/csv,*/*'},redirect:'follow'});
 if(!r.ok)throw new Error(`Elo fallback ${r.status}`);
 const text=await r.text(),lines=text.split(/\r?\n/).filter(Boolean);if(lines.length<2)throw new Error('Empty Elo fallback');
 const head=csvCells(lines[0]).map(x=>normalize(x)),dateI=head.indexOf('date'),clubI=head.indexOf('club'),eloI=head.indexOf('elo');
 if(dateI<0||clubI<0||eloI<0)throw new Error('Elo fallback columns missing');
 const latest=new Map();let latestDate='';
 for(let i=1;i<lines.length;i++){const c=csvCells(lines[i]);const date=String(c[dateI]||''),name=String(c[clubI]||'').trim(),elo=Number(c[eloI]);if(!name||!Number.isFinite(elo))continue;const key=normalize(name),prev=latest.get(key);if(!prev||date>prev.date)latest.set(key,{name,points:Math.round(elo),date});if(date>latestDate)latestDate=date}
 const rows=[...latest.values()].map((x,i)=>({rank:i+1,name:x.name,points:x.points,date:x.date}));
 eloCache.at=Date.now();eloCache.rows=rows;eloCache.sourceUpdatedAt=latestDate;return {...eloCache,sourceName:'Open Elo dataset'};
}
function difficulty(own,opp,venue,sourceName){
 const homeAdv=sourceName==='FootballDatabase'?HOME_ADVANTAGE_FDB:HOME_ADVANTAGE_ELO;
 const venueAdj=venue==='away'?homeAdv:venue==='home'?-homeAdv:0;
 const delta=opp-own+venueAdj;
 const rating=delta<=-220?1:delta<=-80?2:delta<80?3:delta<220?4:5;
 return {rating,adjustedDelta:Math.round(delta)};
}
async function resolveSource(aliasGroups){
 try{const live=await fdbRowsFor(aliasGroups);if(aliasGroups.every(g=>bestMatch(g,live.rows)))return live}catch(error){console.warn('FootballDatabase difficulty source failed:',error?.message||error)}
 const fallback=await fallbackEloRows();return fallback;
}
module.exports=async function handler(req,res){
 if(req.method==='GET')return res.status(200).json({ok:true,service:'fixture-difficulty',primary:'FootballDatabase',fallback:'Open Elo dataset'});
 if(req.method!=='POST'){res.setHeader('Allow','POST');return res.status(405).json({error:'POST required'})}
 try{
  const body=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{}),club=String(body.club||'').trim(),fixtures=Array.isArray(body.fixtures)?body.fixtures.slice(0,8):[];
  if(!club||!fixtures.length)return res.status(400).json({error:'club and fixtures are required'});
  const clubAliases=[club,...(Array.isArray(body.clubAliases)?body.clubAliases:[])],fixtureAliases=fixtures.map(f=>[String(f.opponent||'').trim(),...(Array.isArray(f.opponentAliases)?f.opponentAliases:[])]),source=await resolveSource([clubAliases,...fixtureAliases]);
  const clubMatch=bestMatch(clubAliases,source.rows,84);
  if(!clubMatch)return res.status(200).json({source:source.sourceName,sourceUpdatedAt:source.sourceUpdatedAt,fixtures:fixtures.map(f=>({id:f.id,rating:0,error:'club_not_found'}))});
  const results=fixtures.map((f,i)=>{
   const opp=bestMatch(fixtureAliases[i],source.rows,84);
   if(!opp)return {id:f.id,rating:0,error:'opponent_not_found'};
   const d=difficulty(clubMatch.points,opp.points,String(f.venue||'').toLowerCase(),source.sourceName);
   return {id:f.id,...d,clubPoints:clubMatch.points,opponentPoints:opp.points,matchedClub:clubMatch.name,matchedOpponent:opp.name,sourceUpdatedAt:source.sourceUpdatedAt,source:source.sourceName};
  });
  res.setHeader('Cache-Control','s-maxage=21600, stale-while-revalidate=86400');
  return res.status(200).json({source:source.sourceName,sourceUpdatedAt:source.sourceUpdatedAt,fixtures:results});
 }catch(error){console.error(error);return res.status(503).json({error:'difficulty_source_unavailable',message:String(error?.message||error)})}
};
