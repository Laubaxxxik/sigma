const CACHE_TTL=24*60*60*1000;
const memory=new Map();

function normalize(s=''){
  return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ł/g,'l').replace(/[^a-z0-9]+/g,' ').trim();
}
function scoreName(query,candidate=''){
  const a=normalize(query),b=normalize(candidate);if(!a||!b)return 0;if(a===b)return 100;
  if(a.includes(b)||b.includes(a))return 92;
  const A=new Set(a.split(/\s+/)),B=new Set(b.split(/\s+/));const common=[...A].filter(x=>B.has(x)).length,union=new Set([...A,...B]).size;
  return union?Math.round(common/union*85):0;
}
async function json(url,headers={}){
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),5500);
  try{const r=await fetch(url,{headers:{'user-agent':'Matchbook/1.0 (+Vercel crest resolver)','accept':'application/json',...headers},signal:controller.signal,redirect:'follow'});if(!r.ok)throw new Error(String(r.status));return await r.json()}finally{clearTimeout(timer)}
}
async function sportsDb(name){
  try{
    const data=await json(`https://www.thesportsdb.com/api/v1/json/123/searchteams.php?t=${encodeURIComponent(name)}`);
    const teams=Array.isArray(data?.teams)?data.teams:[];
    const soccer=teams.filter(t=>!t?.strSport||String(t.strSport).toLowerCase()==='soccer');
    const ranked=(soccer.length?soccer:teams).map(t=>({t,s:Math.max(scoreName(name,t?.strTeam),scoreName(name,t?.strAlternate))})).sort((a,b)=>b.s-a.s);
    const best=ranked[0]?.t, url=best?.strBadge||best?.strTeamBadge||best?.strLogo||'';
    if(url)return {url,source:'TheSportsDB',matched:best?.strTeam||name};
  }catch{}
  return null;
}
async function wikipedia(name){
  try{
    const q=`${name} football club`;
    const u='https://en.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrnamespace=0&gsrlimit=6&gsrsearch='+encodeURIComponent(q)+'&prop=pageimages|pageterms&piprop=thumbnail&pithumbsize=320&pilimit=6&pilicense=any&wbptterms=description&redirects=1';
    const data=await json(u);
    const pages=Array.isArray(data?.query?.pages)?data.query.pages:[];
    const ranked=pages.filter(p=>p?.thumbnail?.source).map(p=>{
      const desc=String(p?.terms?.description?.[0]||'').toLowerCase();
      let s=scoreName(name,p.title);if(/football club|association football|soccer club/.test(desc))s+=18;if(/season|footballer|stadium|women/.test(desc))s-=22;
      return {p,s};
    }).sort((a,b)=>b.s-a.s);
    const best=ranked[0]?.p;
    if(best?.thumbnail?.source)return {url:best.thumbnail.source,source:'Wikipedia',matched:best.title};
  }catch{}
  return null;
}
async function resolve(name){
  const key=normalize(name),cached=memory.get(key);if(cached&&Date.now()-cached.at<CACHE_TTL)return cached.value;
  const value=await sportsDb(name)||await wikipedia(name)||{url:'',source:'fallback',matched:name};
  memory.set(key,{at:Date.now(),value});return value;
}
module.exports=async function handler(req,res){
  if(req.method!=='GET'){res.setHeader('Allow','GET');return res.status(405).json({error:'GET required'})}
  const name=String(req.query?.name||'').trim();if(!name||name.length>120)return res.status(400).json({error:'valid club name required'});
  const result=await resolve(name);
  res.setHeader('Cache-Control','s-maxage=86400, stale-while-revalidate=604800');
  return res.status(200).json({ok:!!result.url,...result});
}
