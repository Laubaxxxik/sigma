const CLUBS=[
[546,'RC Lens','lens|racing club de lens|rcl'],[524,'Paris Saint-Germain','psg|paris|paris saint germain'],[81,'FC Barcelona','barca|barça|barcelona'],[498,'Sporting CP','sporting|sporting lizbona'],[1903,'SL Benfica','benfica|benfica lizbona'],[503,'FC Porto','porto'],[851,'Club Brugge','brugge|club brugge kv|brugia'],[86,'Real Madrid','real madryt|real'],[78,'Atlético Madrid','atletico|atletico madryt|atletico madrid'],[65,'Manchester City','man city|city'],[66,'Manchester United','man utd|manchester utd'],[61,'Chelsea','chelsea fc'],[57,'Arsenal','arsenal fc'],[64,'Liverpool','liverpool fc'],[73,'Tottenham Hotspur','tottenham|spurs'],[67,'Newcastle United','newcastle'],[58,'Aston Villa','villa'],[62,'Everton','everton fc'],[397,'Brighton','brighton hove albion'],[563,'West Ham United','west ham'],[5,'Bayern München','bayern|bayern monachium|bayern munich'],[4,'Borussia Dortmund','dortmund|bvb'],[721,'RB Leipzig','leipzig|lipsk'],[3,'Bayer Leverkusen','leverkusen|bayer'],[19,'Eintracht Frankfurt','frankfurt'],[10,'VfB Stuttgart','stuttgart'],[12,'Werder Bremen','werder'],[18,'Borussia Mönchengladbach','gladbach'],[109,'Juventus','juve'],[108,'Inter Milan','inter|inter mediolan|internazionale'],[98,'AC Milan','milan'],[113,'SSC Napoli','napoli'],[100,'AS Roma','roma'],[110,'Lazio','ss lazio'],[102,'Atalanta','atalanta bergamo'],[99,'Fiorentina','acf fiorentina'],[115,'Udinese','udinese calcio'],[516,'Olympique Marseille','marsylia|marseille|om'],[523,'Olympique Lyonnais','lyon|ol'],[548,'AS Monaco','monaco'],[521,'Lille OSC','lille|losc'],[522,'OGC Nice','nice|nicea'],[529,'Stade Rennais','rennes'],[576,'RC Strasbourg','strasbourg'],[511,'Toulouse FC','toulouse'],[543,'FC Nantes','nantes'],[512,'Stade Brestois','brest|brestois'],[547,'Stade Reims','reims'],[518,'Montpellier HSC','montpellier'],[527,'AS Saint-Étienne','saint etienne|asse|saint-étienne'],[525,'FC Lorient','lorient'],[95,'Valencia CF','valencia'],[94,'Villarreal CF','villarreal'],[559,'Sevilla FC','sevilla'],[90,'Real Betis','betis'],[92,'Real Sociedad','sociedad'],[77,'Athletic Club','athletic bilbao|bilbao'],[298,'Girona FC','girona'],[80,'RCD Espanyol','espanyol'],[82,'Getafe CF','getafe'],[678,'Ajax','ajax amsterdam'],[674,'PSV Eindhoven','psv'],[675,'Feyenoord','feyenoord rotterdam'],[600,'Galatasaray','galatasaray sk'],[1899,'SC Braga','braga']];
const normalizeClub=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ł/g,'l').replace(/[^a-z0-9]/g,'');
// Alias index avoids repeated full scans during stadium resolution and award rendering.
// Preserve the first matching alias and incorporate catalogue entries appended by extensions.
const clubAliasIndex=new Map();let indexedClubCount=0;
function findClub(s){if(CLUBS.length<indexedClubCount){clubAliasIndex.clear();indexedClubCount=0;}
 for(;indexedClubCount<CLUBS.length;indexedClubCount++){const c=CLUBS[indexedClubCount];for(const a of [c[1],...c[2].split('|')]){const key=normalizeClub(a);if(!clubAliasIndex.has(key))clubAliasIndex.set(key,c);}}
 return clubAliasIndex.get(normalizeClub(s));}

const EXTRA_CLUBS=[["Leeds United"], ["Leicester City"], ["Nottingham Forest"], ["Wolverhampton Wanderers", "wolves"], ["Crystal Palace"], ["Fulham"], ["Brentford"], ["AFC Bournemouth", "bournemouth"], ["Southampton"], ["Burnley"], ["Sunderland"], ["Ipswich Town"], ["Sheffield United"], ["Sheffield Wednesday"], ["West Bromwich Albion", "west brom"], ["Middlesbrough"], ["Coventry City"], ["Watford"], ["Norwich City"], ["Derby County"], ["Blackburn Rovers"], ["Stoke City"], ["Hull City"], ["Swansea City"], ["Cardiff City"], ["Bristol City"], ["Queens Park Rangers", "qpr"], ["Preston North End"], ["Portsmouth"], ["Wrexham"], ["RCD Mallorca", "mallorca"], ["CA Osasuna", "osasuna"], ["Celta Vigo", "celta"], ["Deportivo Alavés", "alaves"], ["Rayo Vallecano", "rayo"], ["UD Las Palmas", "las palmas"], ["Real Valladolid", "valladolid"], ["CD Leganés", "leganes"], ["Levante UD", "levante"], ["Elche CF", "elche"], ["Real Oviedo", "oviedo"], ["UD Almería", "almeria"], ["Cádiz CF", "cadiz"], ["Granada CF", "granada"], ["Málaga CF", "malaga"], ["Real Zaragoza", "zaragoza"], ["Deportivo La Coruña", "deportivo"], ["Schalke 04", "schalke"], ["Hamburger SV", "hsv"], ["1. FC Köln", "koln"], ["SC Freiburg", "freiburg"], ["VfL Wolfsburg", "wolfsburg"], ["TSG Hoffenheim", "hoffenheim"], ["1. FSV Mainz 05", "mainz"], ["FC Augsburg", "augsburg"], ["Union Berlin"], ["Hertha BSC", "hertha berlin"], ["VfL Bochum", "bochum"], ["FC St. Pauli", "st pauli"], ["1. FC Heidenheim", "heidenheim"], ["Holstein Kiel", "kiel"], ["SV Darmstadt 98", "darmstadt"], ["Hannover 96", "hannover"], ["Fortuna Düsseldorf", "dusseldorf"], ["1. FC Nürnberg", "nurnberg"], ["Bologna FC", "bologna"], ["Torino FC", "torino"], ["Genoa CFC", "genoa"], ["Cagliari Calcio", "cagliari"], ["US Lecce", "lecce"], ["Hellas Verona", "verona"], ["Parma Calcio", "parma"], ["Como 1907", "como"], ["US Sassuolo", "sassuolo"], ["Empoli FC", "empoli"], ["Venezia FC", "venezia"], ["AC Monza", "monza"], ["US Cremonese", "cremonese"], ["Pisa SC", "pisa"], ["Sampdoria"], ["Palermo FC", "palermo"], ["Stade Lavallois", "laval"], ["Le Havre AC", "le havre"], ["AJ Auxerre", "auxerre"], ["Angers SCO", "angers"], ["FC Metz", "metz"], ["Paris FC"], ["SM Caen", "caen"], ["EA Guingamp", "guingamp"], ["SC Bastia", "bastia"], ["AC Ajaccio", "ajaccio"], ["Girondins de Bordeaux", "bordeaux"], ["FC Sochaux", "sochaux"], ["Vitória SC", "vitoria guimaraes", "guimaraes"], ["FC Famalicão", "famalicao"], ["Rio Ave FC", "rio ave"], ["Casa Pia AC", "casa pia"], ["Estoril Praia", "estoril"], ["Moreirense FC", "moreirense"], ["CD Nacional", "nacional madeira"], ["CD Santa Clara", "santa clara"], ["SC Farense", "farense"], ["Estrela da Amadora", "estrela amadora"], ["FC Arouca", "arouca"], ["Gil Vicente FC", "gil vicente"], ["Boavista FC", "boavista"], ["CS Marítimo", "maritimo"], ["RSC Anderlecht", "anderlecht"], ["KRC Genk", "genk"], ["KAA Gent", "gent"], ["Royal Antwerp FC", "antwerp"], ["Union Saint-Gilloise", "union sg", "usg"], ["Standard Liège", "standard liege"], ["Cercle Brugge"], ["Sporting Charleroi", "charleroi"], ["KV Mechelen", "mechelen"], ["Sint-Truiden", "stvv"], ["AZ Alkmaar", "az"], ["FC Twente", "twente"], ["FC Utrecht", "utrecht"], ["SC Heerenveen", "heerenveen"], ["FC Groningen", "groningen"], ["NEC Nijmegen", "nec"], ["Sparta Rotterdam"], ["Celtic FC", "celtic"], ["Rangers FC", "rangers"], ["Aberdeen FC", "aberdeen"], ["Heart of Midlothian", "hearts"], ["Fenerbahçe", "fenerbahce"], ["Beşiktaş", "besiktas"], ["Trabzonspor"], ["İstanbul Başakşehir", "basaksehir"], ["Olympiacos", "olympiakos"], ["Panathinaikos"], ["AEK Athens", "aek ateny"], ["PAOK"], ["FC Copenhagen", "fc kopenhaga", "kobenhavn"], ["FC Midtjylland", "midtjylland"], ["Brøndby IF", "brondby"], ["Red Bull Salzburg", "rb salzburg", "salzburg"], ["SK Sturm Graz", "sturm graz"], ["Rapid Vienna", "rapid wieden"], ["Young Boys", "bsc young boys"], ["FC Basel", "basel"], ["FC Zürich", "zurich"], ["Shakhtar Donetsk", "szachtar donieck"], ["Dynamo Kyiv", "dynamo kijow"], ["Sparta Prague", "sparta praha"], ["Slavia Prague", "slavia praha"], ["Viktoria Plzeň", "viktoria pilzno"], ["Dinamo Zagreb", "dinamo zagrzeb"], ["Hajduk Split"], ["Red Star Belgrade", "crvena zvezda"], ["Partizan Belgrade", "partizan"], ["Bodø/Glimt", "bodo glimt"], ["Molde FK", "molde"], ["Rosenborg BK", "rosenborg"], ["Malmö FF", "malmo"], ["Ferencváros", "ferencvaros"], ["Legia Warszawa", "legia"], ["Lech Poznań", "lech"], ["Raków Częstochowa", "rakow"], ["Jagiellonia Białystok", "jagiellonia"], ["Pogoń Szczecin", "pogon"], ["Górnik Zabrze", "gornik"], ["Widzew Łódź", "widzew"], ["ŁKS Łódź", "lks"], ["Wisła Kraków", "wisla"], ["Cracovia"], ["Śląsk Wrocław", "slask"], ["Zagłębie Lubin", "zaglebie lubin"], ["Piast Gliwice", "piast"], ["Korona Kielce", "korona"], ["Lechia Gdańsk", "lechia"], ["Arka Gdynia", "arka"], ["Motor Lublin", "motor"], ["GKS Katowice", "gks"], ["Radomiak Radom", "radomiak"], ["Wisła Płock", "wisla plock"], ["Ruch Chorzów", "ruch"], ["GKS Tychy"], ["Polonia Warszawa"], ["Odra Opole"], ["Inter Miami CF", "inter miami"], ["LA Galaxy"], ["Los Angeles FC", "lafc"], ["Atlanta United"], ["Seattle Sounders"], ["New York City FC", "nycfc"], ["Al Hilal"], ["Al Nassr"], ["Al Ittihad"], ["Al Ahli"], ["Boca Juniors", "boca"], ["River Plate", "river"], ["Flamengo"], ["Palmeiras"], ["Santos FC", "santos"], ["São Paulo FC", "sao paulo"], ["Corinthians"], ["Fluminense"], ["Botafogo"], ["Grêmio", "gremio"]];
for(const [name,...aliases] of EXTRA_CLUBS){if(!findClub(name))CLUBS.push(["local-"+normalizeClub(name),name,aliases.join("|")])}
function clubCrestUrl(club){return club&&typeof club[0]==='number'?`https://crests.football-data.org/${club[0]}.png`:''}
function clubBadge(name,size=''){let c=findClub(name),letters=String(name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase(),src=clubCrestUrl(c);return `<span class="club-badge ${size}" title="${esc(c?.[1]||name)}"><span>${esc(letters)}</span>${src?`<img src="${src}" alt="Crest ${esc(c[1])}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="this.previousElementSibling.hidden=true" onerror="this.remove()">`:''}</span>`}
function attachClubInputs(){if(!document.querySelector('#club-list')){let dl=document.createElement('datalist');dl.id='club-list';dl.innerHTML=CLUBS.slice().sort((a,b)=>a[1].localeCompare(b[1],'pl')).map(c=>`<option value="${esc(c[1])}" label="${esc(c[2].replaceAll('|',' · '))}"></option>`).join('');document.body.append(dl)}for(const input of document.querySelectorAll('#form input[name="club"],#form input[name="home"],#form input[name="away"],#form input[name="owner"]')){input.setAttribute('list','club-list');let preview=document.createElement('span');preview.className='club-preview';input.after(preview);const update=()=>{const c=findClub(input.value);preview.innerHTML=input.value?clubBadge(input.value)+`<span>${esc(c?.[1]||'Własny klub · inicjały zamiast herbu')}</span>`:''};input.addEventListener('input',update);update()}}

/* V33 full-app audit: additional career-relevant clubs not already covered.
   These entries intentionally use local stable IDs when no verified football-data.org ID is stored;
   the UI then uses the Matchbook shield fallback instead of inventing a crest URL. */
const AUDIT_EXTRA_CLUBS_V33=[
 ['FCSB','steaua|steaua bucuresti'],['CFR Cluj','cfr'],['Rapid București','rapid bucharest|rapid bucuresti'],['Universitatea Craiova','craiova'],['Dinamo București','dinamo bucharest'],
 ['Ludogorets Razgrad','ludogorets'],['Levski Sofia','levski'],['CSKA Sofia','cska sofia'],
 ['APOEL','apoel nicosia'],['Omonia Nicosia','omonia'],['Pafos FC','pafos'],['Aris Limassol','aris limassol'],
 ['Maccabi Tel Aviv','maccabi ta'],['Maccabi Haifa','maccabi haifa'],['Hapoel Be’er Sheva','hapoel beer sheva'],
 ['Slovan Bratislava','slovan'],['Spartak Trnava','trnava'],['DAC Dunajská Streda','dac'],
 ['NK Maribor','maribor'],['Olimpija Ljubljana','olimpija'],['NK Celje','celje'],
 ['Ferencvárosi TC','fradi|ferencvarosi'],['Puskás Akadémia','puskas akademia'],['Fehérvár FC','videoton|fehervar'],
 ['FCSB','steaua bucuresti'],['Sheriff Tiraspol','sheriff'],['Maccabi Netanya','maccabi netanya'],
 ['Slovan Liberec','liberec'],['Baník Ostrava','banik'],['Sigma Olomouc','sigma'],
 ['Rijeka','hnk rijeka'],['Osijek','nk osijek'],['Vojvodina','fk vojvodina'],['Čukarički','cukaricki'],
 ['Zrinjski Mostar','zrinjski'],['FK Sarajevo','sarajevo'],['Borac Banja Luka','borac'],
 ['Qarabağ','qarabag|karabakh'],['Neftçi Baku','neftchi'],
 ['Dinamo Tbilisi','dynamo tbilisi'],['Astana','fc astana'],['Kairat','kairat almaty'],
 ['HJK Helsinki','hjk'],['KuPS','kups'],['Vikingur Reykjavík','vikingur reykjavik'],['Breiðablik','breidablik'],
 ['Shamrock Rovers','shamrock'],['Bohemians Dublin','bohemians'],['Derry City','derry'],
 ['The New Saints','tns'],['Linfield','linfield fc'],
 ['LASK','lask linz'],['Austria Wien','austria vienna'],['Wolfsberger AC','wolfsberger'],
 ['Servette FC','servette'],['FC Lugano','lugano'],['Grasshopper Club Zürich','grasshoppers|gc zurich'],
 ['Aris Thessaloniki','aris thessaloniki'],['OFI Crete','ofi'],
 ['Nordsjælland','fc nordsjaelland'],['AGF Aarhus','agf'],['Randers FC','randers'],
 ['Viking FK','viking stavanger'],['Brann','sk brann'],['Tromsø IL','tromso'],
 ['AIK','aik stockholm'],['Djurgårdens IF','djurgarden'],['Hammarby IF','hammarby'],['BK Häcken','hacken'],
 ['Śląsk Wrocław','slask wroclaw'],['Stal Mielec','stal mielec'],['Bruk-Bet Termalica Nieciecza','termalica'],
 ['Ludogorets','ludogorets razgrad'],['Larne FC','larne'],['Víkingur Gøta','vikingur gota'],
 ['Al Sadd','al-sadd'],['Al Duhail','al-duhail'],['Urawa Red Diamonds','urawa reds'],['Yokohama F. Marinos','yokohama marinos'],['Kawasaki Frontale','kawasaki'],
 ['Club América','america mexico|club america'],['Monterrey','rayados'],['Tigres UANL','tigres'],
 ['Racing Club','racing avellaneda'],['Independiente','independiente avellaneda'],['Vélez Sarsfield','velez'],
 ['Atlético Mineiro','atletico mineiro'],['Internacional','sc internacional'],['Cruzeiro','cruzeiro ec'],['Vasco da Gama','vasco']
];
for(const [name,...aliases] of AUDIT_EXTRA_CLUBS_V33){if(!findClub(name))CLUBS.push(['local-'+normalizeClub(name),name,aliases.join('|')])}

/* Better fallback rendering metadata without changing saved club IDs. */
const clubBadgeBase=clubBadge;
clubBadge=function(name,size=''){
 const c=findClub(name),letters=String(c?.[1]||name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase(),src=clubCrestUrl(c);
 return `<span class="club-badge ${size} ${src?'has-crest':'crest-fallback'}" title="${esc(c?.[1]||name)}"><span aria-hidden="true">${esc(letters)}</span>${src?`<img src="${src}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="this.parentElement?.classList.add('crest-loaded');if(this.previousElementSibling)this.previousElementSibling.hidden=true" onerror="this.parentElement?.classList.add('crest-failed');this.remove()">`:''}</span>`
}

/* V37.9 — dynamic crest resolution + cache fallback
   Keeps existing football-data crests, but also tries remote lookup for clubs without a stored numeric ID. */
const MATCHBOOK_CREST_CACHE_KEY='matchbook_crest_cache_v3710';
function matchbookLoadCrestCache(){
  try{return JSON.parse(localStorage.getItem(MATCHBOOK_CREST_CACHE_KEY)||'{}')||{}}catch{return {}}
}
function matchbookSaveCrestCache(cache){
  try{localStorage.setItem(MATCHBOOK_CREST_CACHE_KEY,JSON.stringify(cache||{}))}catch{}
}
window.__matchbookCrestCache=window.__matchbookCrestCache||matchbookLoadCrestCache();
function crestCacheKey(name){return normalizeClub(name||'')}
function cachedCrestFor(name){
  const key=crestCacheKey(name), cache=window.__matchbookCrestCache||{};
  return key?cache[key]||'':''
}
function storeCrestFor(name,url){
  if(!name||!url)return;
  const key=crestCacheKey(name); if(!key)return;
  window.__matchbookCrestCache=window.__matchbookCrestCache||{};
  window.__matchbookCrestCache[key]=url;
  matchbookSaveCrestCache(window.__matchbookCrestCache);
}
function canonicalClubName(name){return findClub(name)?.[1]||String(name||'').trim()}
clubCrestUrl=function(club){
  const canonical=club?.[1]||'';
  if(club&&typeof club[0]==='number')return `https://crests.football-data.org/${club[0]}.png`;
  return cachedCrestFor(canonical)||'';
}
function clubBadgeLetters(name){
  return String(canonicalClubName(name)||name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase();
}
clubBadge=function(name,size=''){
  const c=findClub(name), canonical=canonicalClubName(name), primary=(c&&typeof c[0]==='number')?`https://crests.football-data.org/${c[0]}.png`:'', cached=cachedCrestFor(canonical)||cachedCrestFor(name)||'', src=primary||cached, source=primary?'primary':cached?'cache':'', letters=clubBadgeLetters(name);
  return `<span class="club-badge ${size} ${src?'has-crest':'crest-fallback'}" data-club-name="${esc(String(name||''))}" data-club-canonical="${esc(canonical)}" title="${esc(canonical)}"><span aria-hidden="true">${esc(letters)}</span>${src?`<img src="${src}" data-crest-source="${source}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="this.parentElement?.classList.add('crest-loaded');if(this.previousElementSibling)this.previousElementSibling.hidden=true" onerror="window.matchbookHandleCrestError&&window.matchbookHandleCrestError(this)">`:''}</span>`;
}
async function matchbookFetchJson(url,timeoutMs=5000){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{const res=await fetch(url,{signal:controller.signal,mode:'cors'}); if(!res.ok)throw new Error(String(res.status)); return await res.json();}
  finally{clearTimeout(timer)}
}
function pickBestSportsDbTeam(teams,name){
  if(!Array.isArray(teams)||!teams.length)return null;
  const targets=[name,canonicalClubName(name),findClub(name)?.[1]].filter(Boolean).map(normalizeClub);
  return teams.find(t=>targets.includes(normalizeClub(t?.strTeam||'')))||teams.find(t=>targets.some(k=>normalizeClub(t?.strAlternate||'')===k))||teams[0];
}
async function lookupCrestOnline(name){
  const canonical=canonicalClubName(name)||String(name||'').trim();
  if(!canonical)return '';
  try{
    const data=await matchbookFetchJson(`/api/crest?name=${encodeURIComponent(canonical)}`,6500);
    const badge=String(data?.url||'').trim();
    if(badge){storeCrestFor(name,badge);storeCrestFor(canonical,badge);return badge}
  }catch{}
  return '';
}
window.__matchbookCrestFailed=window.__matchbookCrestFailed||new Set();
function forgetCachedCrest(name){const key=crestCacheKey(name);if(!key)return;delete window.__matchbookCrestCache?.[key];matchbookSaveCrestCache(window.__matchbookCrestCache||{})}
window.matchbookHandleCrestError=function(img){
  const wrap=img?.closest?.('.club-badge'),source=img?.dataset?.crestSource||'';
  const name=wrap?.dataset?.clubCanonical||wrap?.dataset?.clubName||'';
  if(wrap){wrap.classList.remove('crest-loaded');wrap.classList.add('crest-failed');wrap.querySelector('span')?.removeAttribute('hidden')}
  img?.remove?.();
  if(!name)return;
  if(source==='primary'){
    if(wrap)wrap.dataset.primaryFailed='1';
    queueMicrotask(()=>ensureClubCrests(wrap||document));
  }else{
    forgetCachedCrest(name);window.__matchbookCrestFailed.add(crestCacheKey(name));
  }
}
async function ensureClubCrests(root=document){
  const badges=[...(root?.querySelectorAll?.('.club-badge[data-club-name]')||[])];
  for(const badge of badges){
    if(badge.classList.contains('crest-loaded')||badge.dataset.crestLoading==='1')continue;
    const canonical=badge.dataset.clubCanonical||badge.dataset.clubName||'';
    if(window.__matchbookCrestFailed?.has(crestCacheKey(canonical)))continue;
    const currentImg=badge.querySelector('img');
    const cached=cachedCrestFor(canonical)||cachedCrestFor(badge.dataset.clubName||'');
    if(currentImg?.getAttribute('src'))continue;
    if(cached){
      const img=document.createElement('img');
      img.alt=''; img.loading='lazy'; img.decoding='async'; img.referrerPolicy='no-referrer'; img.dataset.crestSource='cache';
      img.onload=()=>{badge.classList.add('crest-loaded'); badge.classList.remove('crest-failed'); badge.querySelector('span')?.setAttribute('hidden','hidden')};
      img.onerror=()=>window.matchbookHandleCrestError(img);
      img.src=cached; badge.append(img); continue;
    }
    badge.dataset.crestLoading='1';
    try{
      const remote=await lookupCrestOnline(canonical||badge.dataset.clubName||'');
      if(remote && !badge.querySelector('img')){
        const img=document.createElement('img');
        img.alt=''; img.loading='lazy'; img.decoding='async'; img.referrerPolicy='no-referrer'; img.dataset.crestSource='remote';
        img.onload=()=>{badge.classList.add('crest-loaded'); badge.classList.remove('crest-failed'); badge.querySelector('span')?.setAttribute('hidden','hidden')};
        img.onerror=()=>window.matchbookHandleCrestError(img);
        img.src=remote; badge.append(img);
      }else if(!remote){window.__matchbookCrestFailed.add(crestCacheKey(canonical||badge.dataset.clubName||''))}
    }catch{window.__matchbookCrestFailed.add(crestCacheKey(canonical||badge.dataset.clubName||''))}
    badge.dataset.crestLoading='';
  }
}
window.ensureClubCrests=ensureClubCrests;
const matchbookCrestObserver=()=>{
  if(window.__matchbookCrestObserverInstalled)return; window.__matchbookCrestObserverInstalled=true;
  const run=()=>queueMicrotask(()=>ensureClubCrests(document));
  run();
  document.addEventListener('click',run,true);
  const body=document.body; if(!body)return;
  const obs=new MutationObserver(mutations=>{if(mutations.some(m=>m.addedNodes?.length))run()});
  obs.observe(body,{childList:true,subtree:true});
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',matchbookCrestObserver,{once:true});else matchbookCrestObserver();
