# Matchbook V37.28 — Evidence, Big Matches & Your Seasons

Based on V37.27. This update does not modify the xG or Action Creator engines, saved career records, or historical award outcomes.

## Included
- FIFPRO World XI retired from new automated awards, while historical results remain readable.
- Awards: clickable supporting evidence and actual qualifying match references.
- Shared `matchbook-big-matches-v3728.js` classifier for Awards and Statistics, including verified knockout stage, recorded difficult opponents, and the frozen UEFA 2025 club-strength reference. This is not an official world ranking.
- Statistics: Big Matches filter operates before aggregation, so shot maps and all other derived metrics use the same restricted match set. The filter combines with season, competition and other supported filters.
- Your Seasons: cream/plum career timeline, compact season summaries, expandable original season-editing tools, confirmed achievements and direct links to Awards/Statistics.

## Files added
- `matchbook-big-matches-v3728.js`
- `matchbook-awards-evidence-v3728.js`
- `matchbook-seasons-v3728.js`
- `matchbook-v3728-ui.js`
- `matchbook-v3728.css`

## Compatibility
- No automatic mutation of career history for the new analytics.
- Historical World XI result entries remain available in history and historical trophy view.
- The original season editor, competition assignment form, award ceremony logic, xG logic, live Match Maker and JSON backup are preserved.
- Incomplete historical fixture data is not fabricated. Unknown stats display `—` or a limitation notice.

## Deployment
1. Export a backup JSON from Matchbook.
2. Keep your current V37.27 ZIP as a rollback option.
3. Upload/extract this ZIP as a new Vercel preview deployment.
4. Test Awards, Big Matches statistics, Your Seasons and match editing with your own saved career before promoting it to production.

## Testing
- Node: 26 tests passed across active suites. `tests/v3714-action-creator.test.cjs` is an obsolete test of a source file not present in the prior cleaned deployment, so it is excluded; see QA report.
- Chromium offline browser: new Awards -> evidence -> Statistics -> Seasons navigation, empty combined filters, legacy Match History Maker and penalty/card compatibility tests passed.
- Your Seasons viewport widths 390, 768 and 1280 px did not introduce horizontal document overflow.
- Tests use representative synthetic career data, not the user's production cloud save.

This project is a static web app and uses local/cloud saves depending on your Matchbook settings. This update has not been deployed automatically.
