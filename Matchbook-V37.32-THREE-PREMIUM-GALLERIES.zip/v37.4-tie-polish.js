/* Matchbook V37.4 — reliable two-leg ties + knockout/stadium automation */
(function(){
'use strict';

const TIE_COMPETITIONS=['Champions League','Europa League','Conference League','Domestic cup','League cup','Super cup','Other'];
const TIE_EUROPE=new Set(['Champions League','Europa League','Conference League']);
const TIE_DOMESTIC=new Set(['Domestic cup','League cup','Super cup']);

function tieRoundOptions(category){
 const rows=TIE_EUROPE.has(category)?europeanRoundChoices:TIE_DOMESTIC.has(category)?domesticRoundChoices:[
  ['Round of 32','Round of 32'],['Round of 16','Round of 16'],['Quarter-final','Quarter-final'],['Semi-final','Semi-final'],['Final','Final'],['__custom__','Other / custom']
 ];
 const seen=new Set();
 return rows.filter(([value])=>{if(seen.has(value))return false;seen.add(value);return true});
}
function tieDefaultCategory(seasonId){
 const s=db.seasons.find(x=>x.id===seasonId),rows=(s?.competitions||[]).filter(c=>c&&c.status!=='Not entered');
 for(const c of rows){const cat=competitionCategory({competition:c.name});if(TIE_COMPETITIONS.includes(cat)&&cat!=='Other')return cat}
 return 'Champions League';
}
function tieCompetitionName(seasonId,category){
 const suggested=typeof suggestedCompetitionName==='function'?suggestedCompetitionName(seasonId,category):category;
 return String(suggested||category||'').trim();
}
function tieRoundLabel(v){return v.roundPreset==='__custom__'?String(v.customRound||'').trim():String(v.roundPreset||'').trim()}
function tieHomeTeams(v){
 const club=calendarSeasonClub(v.season),opponent=String(v.opponent||'').trim(),clubFirst=v.firstVenue!=='away';
 return {club,opponent,firstHome:clubFirst?club:opponent,firstAway:clubFirst?opponent:club,secondHome:clubFirst?opponent:club,secondAway:clubFirst?club:opponent,firstSide:clubFirst?'home':'away',secondSide:clubFirst?'away':'home'};
}
function tieAutoStadium(team){return typeof knownStadium==='function'?String(knownStadium(team)||'').trim():''}
function tieBuildFixtures(v,tieId=uid()){
 const teams=tieHomeTeams(v),round=tieRoundLabel(v),competitionType=TIE_COMPETITIONS.includes(v.competitionType)?v.competitionType:'Other',competitionName=String(v.competitionName||'').trim()||tieCompetitionName(v.season,competitionType),baseOrder=calendarFixtures().length;
 const make=(leg,date,kickoff,home,away,playerSide,venueName,order)=>({
  id:uid(),season:v.season,date,kickoff:kickoff||'',home,away,playerSide,fixtureVenue:playerSide,venueType:'home',venueName:String(venueName||'').trim()||tieAutoStadium(home),
  competitionType,competitionName,competitionStage:'knockout',roundLabel:round,competitionDetail:round,matchday:'',leg,tieId,status:'scheduled',note:'',trophyWon:false,specialTags:[],createdOrder:baseOrder+order
 });
 return [make('first',v.date1,v.kickoff1,teams.firstHome,teams.firstAway,teams.firstSide,v.venueName1,0),make('second',v.date2,v.kickoff2,teams.secondHome,teams.secondAway,teams.secondSide,v.venueName2,1)];
}
window.calendarBuildTwoLegFixturesV374=tieBuildFixtures;

function stadiumDatalist(){
 if(typeof stadiums==='undefined'||!Array.isArray(stadiums))return '';
 const names=[...new Set(stadiums.map(s=>String(s?.[0]||'').trim()).filter(Boolean))];
 return `<datalist id="tie-stadium-list">${names.map(x=>`<option value="${esc(x)}"></option>`).join('')}</datalist>`;
}
function tieHelpPreview(form){
 let box=form.querySelector('.calendar-tie-preview');if(!box)return;
 const v=Object.fromEntries(new FormData(form)),teams=tieHomeTeams(v),round=tieRoundLabel(v),name=String(v.competitionName||'').trim()||tieCompetitionName(v.season,v.competitionType);
 box.innerHTML=`<div><small>1ST LEG</small><b>${esc(teams.firstHome||'Home')} <span>vs</span> ${esc(teams.firstAway||'Away')}</b><em>${esc(String(v.venueName1||'').trim()||tieAutoStadium(teams.firstHome)||'Stadium TBC')}</em></div><i>↔</i><div><small>2ND LEG</small><b>${esc(teams.secondHome||'Home')} <span>vs</span> ${esc(teams.secondAway||'Away')}</b><em>${esc(String(v.venueName2||'').trim()||tieAutoStadium(teams.secondHome)||'Stadium TBC')}</em></div><p>${esc(name)}${round?' · '+esc(round):''}</p>`;
}

window.openCalendarTie=function(){
 const defaultCategory=tieDefaultCategory(season),defaultName=tieCompetitionName(season,defaultCategory),defaultRounds=tieRoundOptions(defaultCategory),defaultRound=(defaultRounds.find(([v])=>v==='Round of 16')||defaultRounds.find(([v])=>v==='1/8')||defaultRounds[0]||['Quarter-final'])[0];
 const body=choice('season','Season',db.seasons.map(s=>[s.id,s.name]),season)
  +field('opponent','Opponent','','text','required list="club-list" placeholder="Choose opponent"')
  +choice('competitionType','Competition',TIE_COMPETITIONS,defaultCategory)
  +field('competitionName','Competition name',defaultName,'text','required')
  +choice('roundPreset','Knockout round',defaultRounds,defaultRound)
  +field('customRound','Custom round','','text','placeholder="e.g. Play-off final"')
  +choice('firstVenue','Who hosts the 1st leg?',[['home','Your club'],['away','Opponent']],'away')
  +`<div class="wide calendar-tie-preview" aria-live="polite"></div>`
  +field('date1','1st leg date','','date','required')
  +field('kickoff1','1st leg kick-off','','time')
  +field('venueName1','1st leg stadium','','text','list="tie-stadium-list" placeholder="Auto from home club, or type another stadium"')
  +field('date2','2nd leg date','','date','required')
  +field('kickoff2','2nd leg kick-off','','time')
  +field('venueName2','2nd leg stadium','','text','list="tie-stadium-list" placeholder="Auto from home club, or type another stadium"')
  +stadiumDatalist()
  +`<div class="wide calendar-tie-help"><b>Linked knockout tie</b><span>Both fixtures are created together. Home/away reverses automatically, stadiums follow the home club, and the 2nd leg carries the aggregate result.</span></div>`;
 modal('Add two-leg tie',body,v=>{
  v.date1=calendarStrictDate(v.date1);v.date2=calendarStrictDate(v.date2);
  const teams=tieHomeTeams(v),round=tieRoundLabel(v);
  if(!v.date1||!v.date2){sequenceError('Enter valid dates for both legs.');return false}
  if(v.date2<v.date1){sequenceError('The 2nd leg cannot be before the 1st leg.');return false}
  if(!teams.opponent){sequenceError('Choose an opponent.');return false}
  if(!teams.club){sequenceError('The selected season needs a club before creating a tie.');return false}
  if(sameClub(teams.club,teams.opponent)){sequenceError('Choose a different opponent.');return false}
  if(!round){sequenceError('Choose the knockout round.');return false}
  if(v.kickoff1&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(v.kickoff1)){sequenceError('1st leg kick-off must use HH:MM.');return false}
  if(v.kickoff2&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(v.kickoff2)){sequenceError('2nd leg kick-off must use HH:MM.');return false}
  const tieId=uid(),pair=tieBuildFixtures(v,tieId);
  if(pair.length!==2||pair[0].leg!=='first'||pair[1].leg!=='second'||pair[0].tieId!==pair[1].tieId)throw new Error('Two-leg tie could not be constructed safely');
  for(const fixture of pair)upsert('calendarFixtures',fixture);
  const stored=calendarFixtures().filter(f=>f.tieId===tieId&&f.season===v.season);
  if(stored.length!==2||!stored.some(f=>f.leg==='first')||!stored.some(f=>f.leg==='second'))throw new Error('Both legs were not saved — no changes were kept');
  season=v.season;calendarFocusDate(pair[0].date,v.season);
  if(typeof v2SyncBrackets==='function')v2SyncBrackets();
 },null,()=>toast('Two-leg tie created · 1st leg + 2nd leg'));
 const form=$('#form');if(!form)return;
 form.classList.add('calendar-tie-form');
 const seasonInput=form.elements.namedItem('season'),opponent=form.elements.namedItem('opponent'),category=form.elements.namedItem('competitionType'),name=form.elements.namedItem('competitionName'),round=form.elements.namedItem('roundPreset'),custom=form.elements.namedItem('customRound'),firstVenue=form.elements.namedItem('firstVenue'),stadium1=form.elements.namedItem('venueName1'),stadium2=form.elements.namedItem('venueName2');
 let autoName=name?.value||'',autoStadium1='',autoStadium2='';
 const rebuildRoundOptions=()=>{
  if(!round)return;const current=round.value,options=tieRoundOptions(category.value);round.innerHTML=options.map(([v,l])=>`<option value="${esc(v)}">${esc(l)}</option>`).join('');round.value=options.some(([v])=>v===current)?current:(options.find(([v])=>v==='Round of 16')||options.find(([v])=>v==='1/8')||options[0]||['__custom__'])[0];
 };
 const syncCustom=()=>{const label=custom?.closest('label');if(label)label.hidden=round?.value!=='__custom__';if(custom)custom.disabled=round?.value!=='__custom__'};
 const syncName=()=>{if(!name)return;const next=tieCompetitionName(seasonInput.value,category.value);if(!name.value||name.value===autoName)name.value=next;autoName=next};
 const syncStadiums=()=>{const v=Object.fromEntries(new FormData(form)),teams=tieHomeTeams(v),next1=tieAutoStadium(teams.firstHome),next2=tieAutoStadium(teams.secondHome);if(stadium1&&(!stadium1.value||stadium1.value===autoStadium1))stadium1.value=next1;if(stadium2&&(!stadium2.value||stadium2.value===autoStadium2))stadium2.value=next2;autoStadium1=next1;autoStadium2=next2;tieHelpPreview(form)};
 const syncAll=()=>{rebuildRoundOptions();syncCustom();syncName();syncStadiums();tieHelpPreview(form)};
 seasonInput?.addEventListener('change',syncAll);category?.addEventListener('change',syncAll);opponent?.addEventListener('input',syncStadiums);opponent?.addEventListener('change',syncStadiums);firstVenue?.addEventListener('change',syncStadiums);round?.addEventListener('change',()=>{syncCustom();tieHelpPreview(form)});custom?.addEventListener('input',()=>tieHelpPreview(form));name?.addEventListener('input',()=>tieHelpPreview(form));stadium1?.addEventListener('input',()=>tieHelpPreview(form));stadium2?.addEventListener('input',()=>tieHelpPreview(form));
 syncAll();
};

/* Guarantee the leg is visible anywhere the compact round text is used. */
if(typeof calendarDenseRoundV27==='function'){
 const denseBase=calendarDenseRoundV27;
 calendarDenseRoundV27=function(e){let text=String(denseBase(e)||''),leg=e?.leg||e?.fixture?.leg||e?.match?.leg||'';const label=leg==='first'?'1st leg':leg==='second'?'2nd leg':'';if(label&&!new RegExp(label.replace(' ','\\s*'),'i').test(text))text=[text,label].filter(Boolean).join(' · ');return text};
}
})();
