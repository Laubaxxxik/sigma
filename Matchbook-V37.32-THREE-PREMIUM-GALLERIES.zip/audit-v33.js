/* Matchbook V33 — full-app audit helpers. Intentionally additive and non-destructive. */
(function(){
 'use strict';
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ł/g,'l').replace(/[^a-z0-9]+/g,' ').trim();
 function uniqueIssues(values,label){const seen=new Map(),out=[];for(const value of values){const k=norm(value);if(!k)continue;if(seen.has(k))out.push(`${label}: ${value}`);else seen.set(k,value)}return out}
 function auditDatabase(){
  const issues=[];
  if(typeof CLUBS!=='undefined'&&Array.isArray(CLUBS)){issues.push(...uniqueIssues(CLUBS.map(c=>c?.[1]),'Duplicate club name'));const ids=new Map();for(const c of CLUBS){if(c?.[0]==null)continue;const key=String(c[0]);if(ids.has(key)&&norm(ids.get(key))!==norm(c[1]))issues.push(`Duplicate club ID ${key}: ${ids.get(key)} / ${c[1]}`);else ids.set(key,c[1])}}
  if(typeof stadiums!=='undefined'&&Array.isArray(stadiums))issues.push(...uniqueIssues(stadiums.map(s=>`${s?.[0]}|${s?.[1]}`),'Duplicate stadium relation'));
  return {clubs:(typeof CLUBS!=='undefined'&&Array.isArray(CLUBS))?CLUBS.length:0,stadiums:(typeof stadiums!=='undefined'&&Array.isArray(stadiums))?stadiums.length:0,issues};
 }
 function fixAssetFallback(img){const holder=img.closest?.('.club-badge,.national-badge');if(!holder)return;holder.classList.add('asset-failed');const fallback=img.previousElementSibling;if(fallback)fallback.hidden=false;img.remove()}
 document.addEventListener('error',e=>{const img=e.target;if(img instanceof HTMLImageElement&&img.closest?.('.club-badge,.national-badge'))fixAssetFallback(img)},true);
 function polishRenderedUi(){
  document.body.dataset.matchbookPage=String(typeof page==='string'?page:'').toLowerCase().replace(/[^a-z0-9]+/g,'-');
  document.querySelectorAll('button,a,[role="button"]').forEach(el=>{if(!el.getAttribute('aria-label')&&!el.textContent.trim()&&el.getAttribute('title'))el.setAttribute('aria-label',el.getAttribute('title'))});
  document.querySelectorAll('img').forEach(img=>{if(!img.hasAttribute('decoding'))img.decoding='async'});
  document.querySelectorAll('.club-badge img,.national-badge img').forEach(img=>{if(img.complete&&img.naturalWidth===0)fixAssetFallback(img)});
  document.querySelectorAll('table').forEach(t=>{if(!t.closest('.table-wrap,.v2-table-wrap')){const p=t.parentElement;if(p&&p.scrollWidth>p.clientWidth)p.classList.add('table-wrap-auto')}});
  if(String(typeof page==='string'?page:'')==='Data & Help'){const grid=document.querySelector('.v32-data-grid');if(grid&&!grid.querySelector('[data-audit-database]')){const report=auditDatabase(),card=document.createElement('section');card.className='panel';card.dataset.auditDatabase='1';card.innerHTML=`<span class="overline">DATABASE</span><h2>Built-in football data</h2><p><b>${report.clubs}</b> club suggestions · <b>${report.stadiums}</b> stadium relations.</p><small>${report.issues.length?`${report.issues.length} database warning(s) detected.`:'No duplicate club/stadium relations detected.'} Custom clubs and stadiums remain supported.</small>`;grid.append(card)}}
 }
 function install(){
  window.Matchbook??={};Matchbook.fullAudit=auditDatabase;
  if(typeof registerHook==='function')registerHook('afterRenderComplete',polishRenderedUi);else setTimeout(polishRenderedUi,0);
  document.addEventListener('dialogclose',()=>setTimeout(polishRenderedUi,0));
  polishRenderedUi();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
})();
