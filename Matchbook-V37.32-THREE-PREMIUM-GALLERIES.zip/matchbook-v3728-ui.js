/* V37.29 — Big Matches shares the existing main Competition row (profile-polish-v327.js). No duplicate toggle handlers. */
