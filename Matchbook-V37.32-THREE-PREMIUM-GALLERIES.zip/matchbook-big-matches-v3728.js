/* Matchbook V37.30 — one historical, evidence-aware Big Match classifier.
 * Read-only by design. No original match is rewritten. World rankings are only
 * described as verified for clubs for which a dated source snapshot exists.
 */
(function(root,factory){
 const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.MatchbookBigMatchesV3728=api;
})(typeof window!=='undefined'?window:globalThis,function(){
 'use strict';
 const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
 const CLUBS=Object.freeze({
  'FC Barcelona':{id:81,aliases:['barcelona','barca','fc barca','fc barcelona','barcelona fc','f c barcelona']},
  'Real Madrid':{id:86,aliases:['real madrid','real madrid cf','real madrid c f','real madryt','r madrid']},
  'Atlético de Madrid':{id:78,aliases:['atletico madrid','atletico de madrid','atletico madryt','atleti','atletico','atletico madrid cf']},
  'Bayern Munich':{id:5,aliases:['bayern munich','bayern munchen','fc bayern munchen','fc bayern','bayern','bayern monachium']},
  'Manchester City':{id:65,aliases:['manchester city','man city','manchester city fc']},
  'Liverpool':{id:64,aliases:['liverpool','liverpool fc']},
  'Arsenal':{id:57,aliases:['arsenal','arsenal fc']},
  'Paris Saint-Germain':{id:524,aliases:['paris saint germain','paris sg','psg','paris saint germain fc']},
  'Inter Milan':{id:108,aliases:['inter','inter milan','internazionale','fc internazionale','internazionale milano','inter mediolan']},
  'AC Milan':{id:98,aliases:['ac milan','milan','milan ac']},
  'Juventus':{id:109,aliases:['juventus','juventus fc','juve']},
  'Borussia Dortmund':{id:4,aliases:['borussia dortmund','dortmund','bvb']},
  'Chelsea':{id:61,aliases:['chelsea','chelsea fc']},
  'Manchester United':{id:66,aliases:['manchester united','man united','man utd']},
  'Bayer Leverkusen':{id:3,aliases:['bayer leverkusen','leverkusen','bayer 04 leverkusen']},
  'Benfica':{id:1903,aliases:['benfica','sl benfica','sport lisboa e benfica']},
  'FC Porto':{id:503,aliases:['fc porto','porto']},
  'Atalanta':{id:102,aliases:['atalanta','atalanta bc']},
  'RB Leipzig':{id:721,aliases:['rb leipzig','leipzig']},
  'AS Roma':{id:100,aliases:['as roma','roma']},
  'Villarreal':{id:94,aliases:['villarreal','villarreal cf']},
  'Lazio':{id:110,aliases:['lazio','ss lazio']},
  'Eintracht Frankfurt':{id:19,aliases:['eintracht frankfurt','frankfurt']},
  'Club Brugge':{id:851,aliases:['club brugge','club bruges','club brugge kv']},
  'Rangers':{id:null,aliases:['rangers','rangers fc','glasgow rangers']},
  'Newcastle United':{id:67,aliases:['newcastle','newcastle united']},
  'Napoli':{id:113,aliases:['napoli','ssc napoli']},
  'Real Betis':{id:90,aliases:['real betis','betis']}
 });
 const aliases=new Map(),ids=new Map();
 Object.entries(CLUBS).forEach(([club,data])=>{for(const a of [club,...data.aliases]){const key=norm(a);if(!aliases.has(key))aliases.set(key,club);}if(data.id!=null)ids.set(String(data.id),club);});
 const asName=v=>v&&typeof v==='object'?String(v.name||v.clubName||v.teamName||v.title||''):String(v??'');
 function clubIdentity(v,id){
  const label=norm(asName(v));
  if(/(?:\bcastilla\b|\breserves?\b|\bacademy\b|\bu\d{2}\b|\bii\b|\bb\b)$/.test(label))return null;
  if(id!=null&&ids.has(String(id)))return ids.get(String(id));
  if(v&&typeof v==='object'&&v.id!=null&&ids.has(String(v.id)))return ids.get(String(v.id));
  return aliases.get(norm(asName(v)))||null;
 }
 function getSide(m,side){
  const name=m?.[side]??m?.[side+'Team']??m?.fixture?.[side]??m?.fixture?.[side+'Team'];
  const id=m?.[side+'ClubId']??m?.[side+'TeamId']??m?.fixture?.[side+'TeamId'];
  return {name:asName(name),id};
 }
 function resolveOpponent(m){
  if(!m||typeof m!=='object')return {name:'',id:null,identity:null,source:'missing'};
  const explicit=asName(m.opponent??m.opponentName??m.opponentTeam??m.fixture?.opponent);
  const explicitId=m.opponentClubId??m.opponentId??m.opponentTeamId??null;
  const home=getSide(m,'home'),away=getSide(m,'away');
  const playerSide=norm(m.playerSide||m.trackedSide||m.teamSide);
  const sideOpponent=playerSide==='home'?away:playerSide==='away'?home:null;
  if(sideOpponent&&(sideOpponent.name||sideOpponent.id!=null)){
   return {name:sideOpponent.name||explicit,id:sideOpponent.id??explicitId,
     identity:sideOpponent.name?clubIdentity(sideOpponent.name,sideOpponent.id):clubIdentity(explicit,explicitId),source:'home-away'};
  }
  const team=asName(m.playerTeam||m.trackedTeam||m.club||m.team);
  const teamCanonical=clubIdentity(team);
  const homeCanon=clubIdentity(home.name,home.id),awayCanon=clubIdentity(away.name,away.id);
  if(team&&home.name&&away.name){
   if(norm(team)===norm(home.name)||teamCanonical&&teamCanonical===homeCanon)return {name:away.name,id:away.id,identity:awayCanon,source:'club-match'};
   if(norm(team)===norm(away.name)||teamCanonical&&teamCanonical===awayCanon)return {name:home.name,id:home.id,identity:homeCanon,source:'club-match'};
  }
  if(explicit||explicitId!=null)return {name:explicit,id:explicitId,identity:clubIdentity(explicit,explicitId),source:'opponent'};
  return {name:'',id:null,identity:null,source:'unknown'};
 }
 const opponent=m=>resolveOpponent(m).name;
 const competition=m=>norm([m?.competitionType,m?.competitionName,m?.competition,m?.leagueName].filter(Boolean).join(' '));
 const matchStage=m=>norm([m?.stage,m?.round,m?.phase,m?.fixtureRound,m?.roundName,m?.roundLabel,m?.competitionStage,m?.competitionDetail,m?.fixture?.round].filter(Boolean).join(' '));
 function kind(c){
  if(/champions league|\bucl\b|liga mistrzow/.test(c))return 'UCL';
  if(/europa league|\buel\b|liga europy/.test(c))return 'UEL';
  if(/conference league|\buecl\b|liga konferencji/.test(c))return 'UECL';
  if(/world cup|copa america|european championship|\beuro\b|afcon/.test(c))return 'INT';
  if(/domestic cup|league cup|super cup|copa del rey|coppa italia|dfb|puchar|fa cup|coupe de france|\bcup\b|pokal/.test(c))return 'CUP';
  return 'LEAGUE';
 }
 function roundStage(t){
  if(/\bsemi ?final|\bpol ?final|\b1 ?2\b|last 4/.test(t))return 'Semi-final';
  if(/quarter ?final|cwierc ?final|\b1 ?4\b|last 8/.test(t))return 'Quarter-final';
  if(/round of 16|last 16|\br16\b|\b1 8\b/.test(t))return 'Round of 16';
  if(/round of 32|last 32|\b1 16\b/.test(t))return 'Round of 32';
  if(/\bfinal\b|\bfinale\b/.test(t)&&!/semi|quarter|cwierc|pol final/.test(t))return 'Final';
  if(/knockout|play ?off/.test(t))return 'Knockout';
  return '';
 }
 // Historical *verified subset*: Statista/Opta, 17 March 2025, top ten.
 // This is NOT an invented complete world Top 25 and does NOT imply the
 // same exact world ranking was held on every match day of 2024/25.
 const HISTORICAL_SNAPSHOTS=Object.freeze([Object.freeze({
  id:'opta-2025-03-17-top10',season:'2024/25',date:'2025-03-17',
  source:'Opta Power Rankings (reported by Statista, 17 March 2025)',
  url:'https://www.statista.com/statistics/808025/best-soccer-club-teams-worldwide/',
  basis:'retrospective-season-baseline',verifiedTop:10,
  teams:Object.freeze(['Liverpool','Arsenal','FC Barcelona','Inter Milan','Paris Saint-Germain','Real Madrid','Bayern Munich','Manchester City','Atlético de Madrid','Bayer Leverkusen'])
 })]);
 const asSeason=s=>{const v=String(s??'');const x=v.match(/(20\d\d)\s*[\/–-]\s*(\d{2,4})/);return x?`${x[1]}/${x[2].slice(-2)}`:null;};
 function seasonFor(m,context={}){
  const provided=[context.seasonLabel,context.seasonYear,m?.seasonLabel,m?.seasonYear,m?.year,m?.seasonName,m?.season].map(asSeason).find(Boolean);
  if(provided)return provided;
  const iso=String(m?.date||m?.kickoff||m?.matchDate||'').match(/^\s*(20\d\d)[-\/.](\d{1,2})[-\/.](\d{1,2})/);
  if(iso){const year=Number(iso[1]),month=Number(iso[2]);if(month>=1&&month<=12){const start=month>=7?year:year-1;return `${start}/${String(start+1).slice(-2)}`;}}
  // ISO-less imported match dates with a clear year and month are not guessed.
  return null;
 }
 function rankingFor(club,season,context={}){
  if(!club)return null;
  const snapshots=Array.isArray(context.snapshots)?context.snapshots:HISTORICAL_SNAPSHOTS;
  for(const s of snapshots){
   if(asSeason(s?.season)!==season||!s?.source||!/^\d{4}-\d{2}-\d{2}$/.test(s?.date||''))continue;
   if(!Array.isArray(s.teams))continue;
   const index=s.teams.findIndex(t=>clubIdentity(t?.name??t?.club??t?.id??t,t?.id)===club);
   if(index<0)continue;
   const row=s.teams[index],rank=Number(row&&typeof row==='object'?row.rank: index+1);
   if(!Number.isInteger(rank)||rank<1||rank>25)continue;
   const verified=s.basis!=='fallback'&&s.verifiedTop>=rank;
   return {rank:verified?rank:null,category:verified?'verified-top-25':'historical-elite-baseline',
     source:String(s.source),url:String(s.url||''),snapshotDate:s.date,sourceVersion:String(s.id||''),
     basis:String(s.basis||'snapshot'),applicableSeason:season};
  }
  return null;
 }
 const LEVELS=Object.freeze({'Important Match':1,'High-Stakes Match':2,'Major Match':3});
 function classify(m,context={}){
  if(!m||typeof m!=='object')return {qualifies:false,category:null,importance:null,stake:0,reasons:[],stage:'',criteria:'Insufficient fixture metadata'};
  const c=kind(competition(m)),r=roundStage(matchStage(m)),reasons=[];
  let level=0;
  const add=(rank,reason)=>{level=Math.max(level,rank);if(!reasons.includes(reason))reasons.push(reason);};
  if(c==='UCL'){
   if(['Final','Semi-final'].includes(r))add(3,`UEFA Champions League · ${r}`);
   else if(r==='Quarter-final')add(2,'UEFA Champions League · Quarter-final');
   else if(['Round of 16','Knockout'].includes(r))add(1,`UEFA Champions League · ${r}`);
  }else if(c==='UEL'||c==='UECL'){
   const name=c==='UEL'?'UEFA Europa League':'UEFA Conference League';
   if(['Final','Semi-final'].includes(r))add(2,`${name} · ${r}`);
   else if(['Quarter-final','Round of 16','Knockout'].includes(r))add(1,`${name} · ${r}`);
  }else if(c==='CUP'||c==='INT'){
   if(r==='Final')add(c==='INT'?3:2,`${c==='INT'?'International tournament':'Domestic cup'} · Final`);
   else if(r==='Semi-final')add(1,`${c==='INT'?'International tournament':'Domestic cup'} · Semi-final`);
  }
  const resolved=resolveOpponent(m),season=seasonFor(m,context),rank=rankingFor(resolved.identity,season,context);
  if(rank){
   add(1,`Elite opponent: ${resolved.identity} · ${rank.category==='verified-top-25'?'verified Opta Top 10 snapshot':'historical season baseline'} (${rank.snapshotDate})`);
  }
  // Only explicitly stored contextual metadata is used; no form-based guess.
  const difficulty=norm(m.difficulty||m.opponentDifficulty||m.difficultyRating);
  if(/^(elite|very hard|extreme|top 25|very difficult)$/.test(difficulty))add(1,`Recorded opponent difficulty: ${difficulty}`);
  const tags=(Array.isArray(m.specialTags)?m.specialTags:[]).map(norm);
  const notable=tags.filter(t=>/^(derby|classic rivalry|title decider|promotion decider|relegation decider|decisive match)$/.test(t));
  if(notable.length)add(1,`Recorded high-stakes context: ${notable.join(', ')}`);
  const importance=Object.keys(LEVELS).find(k=>LEVELS[k]===level)||null;
  return {qualifies:level>0,category:importance,importance,stake:level===3?4.2:level===2?3:level===1?2:0,reasons,stage:r,
    opponent:resolved.name,opponentId:resolved.identity,opponentSource:resolved.source,seasonReference:season,
    ranking:rank,criteria:rank?'Verified dated ranking subset / documented season baseline, recorded stage and stakes':'Recorded competition stage, difficulty and explicit stakes; missing ranking is not assumed'};
 }
 function selected(matches,context){return (Array.isArray(matches)?matches:[]).filter(m=>classify(m,context).qualifies);}
 function rebuild(career,context={}){
  const seasons=new Map((Array.isArray(career?.seasons)?career.seasons:[]).map(s=>[String(s.id),s]));
  return (Array.isArray(career?.matches)?career.matches:[]).filter(m=>m&&m.count!==false).map(m=>{
   const meta=seasons.get(String(m.season));
   return {id:m.id,season:m.season,...classify(m,{...context,seasonLabel:meta?.year||meta?.name})};
  });
 }
 return Object.freeze({classify,selected,rebuild,clubIdentity,resolveOpponent,opponent,roundStage,seasonFor,rankingFor,historicalSnapshots:HISTORICAL_SNAPSHOTS,normaliseName:norm});
});
