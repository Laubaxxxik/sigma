/* A season owns its player snapshot. db.profile keeps legacy data and identity defaults. */
const seasonIdentityFields=['name','nationality','secondNationality','birthDate','birthPlace','shirtName','academy'];
const internationalProfileFields=['nationalTeamId','internationalStatus','internationalLevel','internationalNumber','internationalPositions','internationalDebutDate','internationalNotes','internationalEligibility'];

function seasonProfileSnapshot(profile){
 const copy=structuredClone(profile||{});
 for(const key of internationalProfileFields)delete copy[key];
 if(Object.hasOwn(copy,'photoData'))delete copy.photoSource;
 return copy;
}

function playerProfilePhoto(profile=playerProfile()){
 return Object.hasOwn(profile,'photoData')?profile.photoData||'':profile.photoSource==='legacy'?db.profile.photoData||'':'';
}

function seasonProfileMatches(id,data=db){
 return (data.matches||[]).filter(m=>m.season===id||m.teamContext==='international'&&m.sourceClubSeasonId===id);
}

function ensureSeasonProfiles(data){
 if(!data||!Array.isArray(data.seasons)||!data.profile)return false;
 let changed=false;
 for(const s of data.seasons){
  if(!s||Object.hasOwn(s,'playerProfile'))continue;
  const profile=seasonProfileSnapshot(data.profile),date=latestRecordedMatchDate(seasonProfileMatches(s.id,data));
  // Keep one copy of the old shared portrait; edited portraits belong to their season.
  if(data.profile.photoData){delete profile.photoData;profile.photoSource='legacy'}
  profile.club=s.club||profile.club||'';
  profile.careerDate=date;
  const age=ageAtDate(profile.birthDate,date);
  profile.ageMode=age===null?'manual':'birth';
  if(age!==null)profile.age=String(age);
  s.playerProfile=profile;
  s.playerProfileSource='legacy';
  changed=true;
 }
 return changed;
}

function latestPlayerProfileSeason(){
 return (db.seasons||[]).map((s,index)=>({s,index,year:Number(String(s.year||s.name||'').match(/(?:19|20|21)\d{2}/)?.[0])||0}))
  .sort((a,b)=>a.year-b.year||a.index-b.index).at(-1)?.s||null;
}

function playerProfileSeason(id=season){
 return db.seasons.find(s=>s.id===id)||latestPlayerProfileSeason();
}

function playerProfile(id=season){
 return playerProfileSeason(id)?.playerProfile||db.profile;
}

function playerProfileScope(){
 const s=playerProfileSeason();
 return s?`${season==='@career'?'Latest season · ':''}${s.year||s.name}`:'Career identity';
}

function newSeasonPlayerProfile(s){
 // The initial onboarding profile is the starting point for the first season only.
 if(!db.seasons.length)return {...seasonProfileSnapshot(db.profile),club:s.club||'',careerDate:'',ageMode:'manual'};
 const identity={};
 for(const key of seasonIdentityFields)identity[key]=db.profile[key]||'';
 return {...identity,club:s.club||'',number:'',positions:'',height:'',weight:'',age:'',careerDate:'',ageMode:'manual',photoData:''};
}

function savePlayerProfileSnapshot(profile,{target=null,pending=false}={}){
 // Freeze old event attribution before a player name is corrected.
 for(const m of db.matches||[])if(m.actions?.length&&!m.trackedPlayer)m.trackedPlayer=playerProfile(m.season||m.sourceClubSeasonId).name;
 if(db.draft&&!db.draft.trackedPlayer)db.draft.trackedPlayer=playerProfile(db.draft.season||db.draft.sourceClubSeasonId).name;
 if(target){
  const stored=db.seasons.find(s=>s.id===target.id);
  if(!stored&&!pending)throw Error('This season no longer exists');
  const next={...(stored||target),club:profile.club,playerProfile:seasonProfileSnapshot(profile),playerProfileSource:'saved'};
  next.name=next.club+' · '+next.year+(next.customName?' · '+next.customName:'');
  upsert('seasons',next);
  for(const key of seasonIdentityFields)db.profile[key]=profile[key]||'';
  if(db.profile.ageMode==='birth'&&ageAtDate(db.profile.birthDate,latestRecordedMatchDate(db.matches)||db.profile.careerDate)===null)db.profile.ageMode='manual';
  for(const key of internationalProfileFields)if(Object.hasOwn(profile,key))db.profile[key]=profile[key];
 }else db.profile=structuredClone(profile);
 if(Object.hasOwn(profile,'nationalTeamId')){
  db.internationalCurrent.nationalTeamId=profile.nationalTeamId;
  if(db.internationalCurrent.cycleId&&!db.internationalCycles.some(c=>c.id===db.internationalCurrent.cycleId&&c.nationalTeamId===profile.nationalTeamId))db.internationalCurrent.cycleId='';
 }
 db.profileReady=true;
}

function seasonPlayerProfileErrors(s,data){
 const p=s.playerProfile,errors=[],label=`Season profile (${s.year||s.name||s.id})`;
 if(!p||typeof p!=='object'||Array.isArray(p))return [`${label}: invalid player profile.`];
 for(const key of [...seasonIdentityFields,'club','positions','foot','contract','contractEnd','careerDate','ageMode','owner','status','playStyle','personality','bio','photoData','photoSource']){
  if(p[key]!=null&&typeof p[key]!=='string')errors.push(`${label}: invalid ${key}.`);
 }
 for(const key of ['birthDate','careerDate','contractEnd'])if(p[key]&&!validProfileDate(p[key]))errors.push(`${label}: invalid ${key}.`);
 for(const key of ['age','number','height','weight','marketValueOverride'])if(p[key]!=null&&p[key]!==''&&!Number.isFinite(Number(p[key])))errors.push(`${label}: invalid ${key}.`);
 const date=latestRecordedMatchDate(seasonProfileMatches(s.id,data))||p.careerDate;
 if(p.birthDate&&date&&date<p.birthDate)errors.push(`${label}: profile date precedes birth date.`);
 if(s.playerProfileSource==='saved'&&['name','nationality','club','positions'].some(k=>typeof p[k]!=='string'||!p[k].trim()))errors.push(`${label}: incomplete player details.`);
 return errors;
}

function editSeason(id='',pending=null,profileDraft=null){
 const s=db.seasons.find(s=>s.id===id)||pending||{},t=seasonTotals(s),r=recordedTotals(s.id);
 modal(s.id&&!pending?'Edit season':'Create your season · 1 of 2',
  (!s.id||pending?'<p class="wide season-profile-notice">Step 1: season details. Next, create this season’s player profile. The season is saved only after both steps are complete.</p>':'')+
  field('club','Club',s.club||'','text','required list="club-list"')+
  field('year','Year / season (e.g. 2028/29)',s.year||'','text','required')+
  field('name','Additional title (optional)',s.customName||'')+
  field('baseM','Total season appearances',t.m,'number','min="'+r.m+'" required')+
  field('baseG','Total season goals',t.g,'number','min="'+r.g+'" required')+
  field('baseA','Total season assists',t.a,'number','min="'+r.a+'" required')+
  `<small class="wide">Enter full totals, including matches already recorded here. Recorded matches: ${r.m} appearances, ${r.g} goals, ${r.a} assists. These numbers are already included and will not be counted twice. To reduce them, edit the relevant match.</small>`+
  `<div class="wide" id="competition-editor" data-rows="${esc(JSON.stringify(seasonCompetitions(s)))}"></div>`+
  area('note','Notes',s.note||''),v=>{
   const next=seasonFromForm(v,s);
   if(!db.seasons.some(row=>row.id===next.id)){
    setTimeout(()=>editPlayerProfile(false,{target:next,pending:true,profile:profileDraft?{...profileDraft,club:next.club}:newSeasonPlayerProfile(next)}),0);
    return false;
   }
   if(next.playerProfile)next.playerProfile={...next.playerProfile,club:next.club};
   upsert('seasons',next);
  },s.id&&!pending?()=>{
   const used=db.matches.filter(m=>m.season===s.id).length;
   if((used||db.draft?.season===s.id)&&!confirm('This season contains '+used+' matches or an active report. Delete the season and those records?'))return false;
   remove('seasons',s.id);db.matches=db.matches.filter(m=>m.season!==s.id);
   db.calendarFixtures=(db.calendarFixtures||[]).filter(f=>f.season!==s.id);
   if(db.draft?.season===s.id)db.draft=null;
   season=db.seasons[0]?.id||'';
  }:null,()=>{season=s.id;});
 if(!s.id||pending)$('#form button[type="submit"]').textContent='Next: season profile';
}
