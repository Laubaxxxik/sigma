/* Matchbook V32.2 — FotMob-inspired interface polish. No new tracking burden. */
(function(){
  const safe=(v)=>typeof esc==='function'?esc(v):String(v??'');
  const appearanceMatches=()=>{try{return typeof matches==='function'?matches().filter(m=>m&&m.count!==false):[]}catch{return []}};
  const clubFor=(m)=>{try{return typeof analyticsClub==='function'?analyticsClub(m):(typeof current==='function'?current().club:'')}catch{return ''}};
  const outcomeFor=(m)=>{try{return typeof matchOutcome==='function'?matchOutcome(m,clubFor(m)):''}catch{return ''}};
  const opponentFor=(m)=>m?.opponent||((m?.playerSide==='home')?m?.away:m?.home)||m?.away||m?.home||'Opponent';
  const positionFor=(m)=>m?.position||m?.playerPosition||m?.role||'';
  const ratingHtml=(m)=>typeof ratingBadge==='function'?ratingBadge(m?.rating):`<span>${safe(m?.rating||'—')}</span>`;

  function recentStrip(){
    const list=appearanceMatches().slice(-5).reverse();
    if(!list.length)return '';
    return `<section class="mb-fotmob-strip" aria-label="Recent player matches"><header><div><span class="overline">FORM</span><h2>Recent matches</h2></div><small>Latest recorded appearances</small></header><div class="mb-fotmob-matches">${list.map(m=>{const out=outcomeFor(m)||'unknown',opp=opponentFor(m),mins=m.minutes!=null?`${safe(m.minutes)}′`:'—',pos=positionFor(m);return `<button type="button" class="mb-fotmob-match" data-action="recap:${safe(m.id)}"><span class="mb-result ${safe(out)}">${safe(out==='unknown'?'–':out)}</span>${typeof clubBadge==='function'?clubBadge(opp):''}<strong>${safe(opp)}</strong><span class="mb-score">${safe(m.score||'—')}</span><span class="mb-meta">${safe([pos,mins].filter(Boolean).join(' · '))}</span>${ratingHtml(m)}</button>`}).join('')}</div></section>`;
  }

  function enhanceDashboard(root){
    if(typeof page==='undefined'||page!=='Dashboard')return;
    const metrics=root.querySelector('.metrics');
    if(metrics&&!root.querySelector('.mb-fotmob-strip'))metrics.insertAdjacentHTML('afterend',recentStrip());
  }

  function enhanceStats(root){
    if(typeof page==='undefined'||page!=='Statistics')return;
    const profile=root.querySelector('.stats-profile');
    if(profile&&!profile.querySelector('.mb-stats-club-badge')){
      let club='';try{club=season==='@career'?'':current().club}catch{}
      if(club&&typeof clubBadge==='function')profile.insertAdjacentHTML('afterbegin',`<div class="mb-stats-club-badge">${clubBadge(club,'large')}</div>`);
    }
  }

  function labelDataSection(root){
    const panels=[...root.querySelectorAll('.metric-panel')];
    panels.forEach(p=>{const h=p.querySelector(':scope>h3');if(h&&!h.dataset.mbPolished)h.dataset.mbPolished='1'});
  }

  function bindInjected(root){
    root.querySelectorAll('.mb-fotmob-match[data-action]').forEach(b=>{if(b.dataset.mbBound)return;b.dataset.mbBound='1';b.addEventListener('click',()=>{if(typeof act==='function')act(b.dataset.action)})});
  }

  function polishPage(){
    document.body.classList.add('fotmob-redesign');
    const root=document.querySelector('#content');if(!root)return;
    enhanceDashboard(root);enhanceStats(root);labelDataSection(root);bindInjected(root);
  }

  if(typeof registerHook==='function')registerHook('afterRenderComplete',polishPage,-100);
  else window.addEventListener('load',polishPage,{once:true});
})();
