/* Matchbook V37.26 — read-only, evidence-backed awards outlook.
   Separate from ceremony decisions. Does not write to db, mutate snapshots,
   create competitor seasons or assume missing recorded actions equal zero. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.MatchbookAwardOutlookV3726 = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  const numeric = v => {
    if (v === '' || v === null || v === undefined || typeof v === 'boolean') return null;
    const n=Number(typeof v==='string'?v.trim().replace(',','.'):v);
    return Number.isFinite(n) ? n : null;
  };
  const bounded=(v,min=0,max=1e5)=>{const n=numeric(v);return n!==null&&n>=min&&n<=max?n:null};
  const sum=(rows,key)=>rows.reduce((a,r)=>a+(bounded(r[key])??0),0);
  const mean=values=>values.length?values.reduce((a,b)=>a+b,0)/values.length:null;
  const round=(n,d=2)=>n==null||!Number.isFinite(n)?null:Number(n.toFixed(d));
  const rate=(n,mins)=>mins&&mins>0&&n!=null?round(n*90/mins):null;
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').toLowerCase();
  const str=v=>String(v??'');
  const awarded=c=>String(c?.status||'').toLowerCase()==='won';
  const idOf=(v,i)=>str(v?.id||[v?.date,v?.opponent,i].join('|'));
  function category(m){
    const type=norm(m?.competitionType||m?.type||'');
    const n=norm([m?.competitionName,m?.competition,m?.leagueName].filter(Boolean).join(' '));
    const text=type+' '+n;
    if(/champions league|\bucl\b|liga mistrzow/.test(text))return 'UCL';
    if(/europa league|\buel\b|liga europy/.test(text))return 'UEL';
    if(/conference league|\buecl\b|liga konferencji/.test(text))return 'UECL';
    if(/national team|world cup|international|copa america|euro 20/.test(text))return 'International';
    if(/friendly|towarzysk|sparing/.test(text))return 'Friendly';
    if(/domestic cup|league cup|\bfa cup\b|copa del rey|coppa italia|dfb pokal|coupe de france|puchar|super cup|supercopa/.test(text))return 'Cup';
    if(/^(league|domestic league)$/.test(type)||/laliga|la liga|premier league|serie a|bundesliga|ligue 1|eredivisie|primeira liga|liga portugal|ekstraklasa|primera division|\bliga\b|\bleague\b/.test(text))return 'League';
    return 'Unknown';
  }
  function stageOf(m){
    const field=[m?.stage,m?.round,m?.phase,m?.fixtureRound,m?.roundName,m?.roundLabel,m?.competitionStage].filter(Boolean).join(' ');
    const n=norm(field);
    if(/semi.?final|pol.?final|1\/2/.test(n))return {name:'Semi-final',weight:3.4,knockout:true};
    if(/quarter.?final|cwiercfinal|1\/4/.test(n))return {name:'Quarter-final',weight:2.9,knockout:true};
    if(/final|finale/.test(n))return {name:'Final',weight:4.2,knockout:true};
    if(/round.?of.?16|last.?16|1\/8|r16/.test(n))return {name:'Round of 16',weight:2.4,knockout:true};
    if(/knockout|play.?off/.test(n))return {name:'Knockout',weight:2.1,knockout:true};
    return {name:'',weight:0,knockout:false};
  }
  const averageRating=rows=>round(mean(rows.map(r=>r.rating).filter(v=>v!=null)));
  const status=(score,limits,labels)=>{let k=0;for(const t of limits)if(score>=t)k++;return labels[Math.min(k,labels.length-1)];};
  const confidence=n=>n>=25?'substantial':n>=10?'moderate':n>=5?'limited':'very limited';
  function sanitizeActions(raw){return Array.isArray(raw)?raw.filter(e=>e&&typeof e==='object'):[];}
  function canonicalMatch(raw, season, helpers={}){
    let m=raw;
    try{if(typeof helpers.matchView==='function')m=helpers.matchView(raw)||raw;}catch{m=raw;}
    const own = helpers.playerMatcher ? (()=>{try{return helpers.playerMatcher(m);}catch{return null;}})() : null;
    const actions=sanitizeActions(m.actions??raw.actions);
    let actionStat=null;
    if(actions.length && typeof helpers.actionStats==='function'){
      try{actionStat=helpers.actionStats(actions,m.playerSide||raw.playerSide,own||undefined)||null;}catch{}
    }
    const observedMetric=key=>actionStat&&(m.trackingMode==='full'||actionStat._observed?.includes(key)||Number(actionStat[key])>0)?bounded(actionStat[key],0,100):null;
    // Only count attached shot xG when the tracking system supplies it and it is valid.
    const isPlayer=e=>{
      if(typeof own==='function'){try{return own(e.player)&&(!m.playerSide||!e.side||e.side===m.playerSide);}catch{return false;}}
      const tracked=norm(m.trackedPlayer||season.playerProfile?.name||'').trim();
      return !!tracked&&norm(e.player).trim()===tracked&&(!m.playerSide||!e.side||e.side===m.playerSide);
    };
    const shots=actions.filter(e=>/^(goal|penalty goal|shot|shot on target|shot off target|blocked shot|post|crossbar|big chance missed|penalty missed)$/i.test(str(e.type))&&isPlayer(e));
    const xg=shots.map(e=>bounded(e.shot?.xG,0,1));
    const observedXg=xg.filter(v=>v!==null);
    const minutes=bounded(m.minutes??raw.minutes,0,150), rating=bounded(m.rating??raw.rating,1,10);
    const g=bounded(m.goals??raw.goals,0,30),a=bounded(m.assists??raw.assists,0,30);
    const source=category({...raw,...m});
    return {id:idOf(raw,0),date:str(m.date||raw.date),season:str(raw.season),opponent:str(m.opponent||raw.opponent),competition:str(m.competitionName||m.competition||raw.competition||source),category:source,stage:stageOf({...raw,...m}),difficulty:str(raw.difficulty||m.difficulty),rating,minutes,goals:g,assists:a,
      playerActions:actions.filter(isPlayer),actionsTracked:actions.length>0,goalsKnown:g!==null,assistsKnown:a!==null,
      keyPasses:observedMetric('keyPasses'),
      bigChances:observedMetric('bigChances'),
      dribbles:observedMetric('dribbles'),
      tackles:observedMetric('tackles'),
      interceptions:observedMetric('interceptions'),
      shots:observedMetric('shots'),
      xg:observedXg.length?round(observedXg.reduce((a,b)=>a+b,0),3):null,
      xgCoverage:shots.length?{known:observedXg.length,total:shots.length}:null,
      shotCoverage:actionStat!=null,
      isStarter:raw.lineupMode==='manual'&&raw.started===true ? true : (raw.started===false?false:null),
      score:str(m.score||raw.score),seasonLabel:str(season.year||season.name||''),raw};
  }
  function uniqueRows(data,season,helpers){const seen=new Set();const rows=[];
    for(const m of Array.isArray(data?.matches)?data.matches:[]){
      if(str(m?.season)!==str(season?.id)||m?.count!==true)continue;
      const key=idOf(m,rows.length);if(seen.has(key))continue;seen.add(key);
      const row=canonicalMatch(m,season,helpers);row.id=key;rows.push(row);
    }
    return rows.sort((a,b)=>a.date.localeCompare(b.date));
  }
  function aggregate(rows){
    const knownMinutes=rows.length>0&&rows.every(r=>r.minutes!==null);
    const minutes=knownMinutes?sum(rows,'minutes'):null;
    const ratings=rows.map(r=>r.rating).filter(r=>r!=null);
    const KP=rows.filter(r=>r.keyPasses!==null),DR=rows.filter(r=>r.dribbles!==null),SH=rows.filter(r=>r.shots!==null);
    const XP=rows.filter(r=>r.xgCoverage);
    const allXg=XP.length>0&&XP.every(r=>r.xgCoverage.known===r.xgCoverage.total);
    return {matches:rows.length,minutes,goals:sum(rows,'goals'),assists:sum(rows,'assists'),
      rating:round(mean(ratings)),ratedMatches:ratings.length,g90:rate(sum(rows,'goals'),minutes),a90:rate(sum(rows,'assists'),minutes),
      keyPasses:KP.length?sum(KP,'keyPasses'):null,keyPassMatches:KP.length,
      bigChances:rows.some(r=>r.bigChances!==null)?sum(rows,'bigChances'):null,
      dribbles:DR.length?sum(DR,'dribbles'):null,tackles:rows.some(r=>r.tackles!==null)?sum(rows,'tackles'):null,
      interceptions:rows.some(r=>r.interceptions!==null)?sum(rows,'interceptions'):null,
      shots:SH.length?sum(SH,'shots'):null,
      conversion:SH.length&&sum(SH,'shots')?round(sum(SH,'goals')/sum(SH,'shots')*100,1):null,
      xg:allXg?round(sum(XP,'xg'),3):null,
      xgCoverage:{known:XP.reduce((n,r)=>n+r.xgCoverage.known,0),total:XP.reduce((n,r)=>n+r.xgCoverage.total,0)},
      actionsObserved:rows.filter(r=>r.actionsTracked).length};
  }
  function individual(report){
    if(typeof MatchbookAwardsV4==='undefined')return {score:null,label:'Assessment engine unavailable',evidence:[],limitations:[]};
    const assessed=MatchbookAwardsV4.performance(report.rows,report.position);
    return {score:assessed.score,label:assessed.score>=85?'Outstanding individual performances':assessed.score>=70?'Strong individual performances':assessed.score>=40?'Developing individual contribution':'Limited individual evidence',
      evidence:assessed.metrics.map(m=>`${m.name}: ${m.actual??m.score}${m.benchmark?' (benchmark '+m.benchmark+')':''}`),limitations:assessed.coverage<.75?['Metric coverage is incomplete']:[]};
  }
  function consistency(rows){
    const rated=rows.filter(r=>r.rating!=null);const values=rated.map(r=>r.rating),avg=mean(values);
    if(values.length<5)return {label:'Insufficient data',evidence:`${values.length} rated matches; at least five are needed to assess consistency.`,average:round(avg),std:null,strong:null,poor:null};
    const std=Math.sqrt(mean(values.map(v=>(v-avg)**2)));
    const strong=values.filter(v=>v>=7.5).length,poor=values.filter(v=>v<6.5).length;
    const consistencyPenalty=Math.min(1,std/2)+poor/values.length*.65;
    let label=std<.45&&poor===0?'Highly consistent':std<.7&&poor/values.length<.12?'Consistently strong':std<.95?'Generally reliable':std<1.35?'Mixed consistency':'Inconsistent';
    if(values.length<10&&label==='Highly consistent')label='Generally reliable';
    return {label,average:round(avg),std:round(std),strong,poor,evidence:`${round(std)} rating standard deviation across ${values.length} rated matches; ${strong} rated 7.5+, ${poor} below 6.5.`,coverage:confidence(values.length),penalty:round(consistencyPenalty)};
  }
  function recentForm(rows){
    const rated=rows.filter(r=>r.rating!=null),last5=rated.slice(-5),prior=rated.slice(-10,-5);
    if(last5.length<3)return {label:'Insufficient recent matches',summary:`Only ${last5.length} rated recent matches recorded.`,last5:aggregate(rows.slice(-5)),last10:aggregate(rows.slice(-10)),trend:null};
    const avg=mean(last5.map(r=>r.rating)),oldAvg=mean(prior.map(r=>r.rating));
    const trend=oldAvg!==null?round(avg-oldAvg):null;
    const label=trend!=null&&trend>=.65?'Improving form':trend!=null&&trend<=-.65?'Declining form':avg>=8?'Excellent recent form':avg>=7.45?'Stable strong form':'Mixed recent form';
    return {label,summary:`Last ${last5.length} rated matches: ${round(avg)} average${trend===null?'':`; ${trend>0?'+':''}${trend} versus the previous five`}.`,last5:aggregate(rows.slice(-5)),last10:aggregate(rows.slice(-10)),trend};
  }
  function important(row){
    // Exact same classifier as the Big Matches filter in Statistics.
    const shared=typeof window!=='undefined'?window.MatchbookBigMatchesV3728:
      (typeof require==='function'?require('./matchbook-big-matches-v3728.js'):null);
    const found=shared?.classify({...row.raw,competitionName:row.raw?.competitionName||row.competition,
      difficulty:row.raw?.difficulty||row.difficulty}, {seasonLabel:row.seasonLabel});
    if(!found)return {stake:0,important:false,reason:null,reasons:[]};
    return {stake:found.stake,category:found.category,important:found.qualifies,reason:found.reasons.join(' · '),reasons:found.reasons,ranking:found.ranking};
  }
  function bigMatches(rows){
    const selected=rows.map(r=>({...r,importance:important(r)})).filter(r=>r.importance.important);
    const rated=selected.filter(r=>r.rating!=null);const performance=aggregate(selected);
    const rating=round(mean(rated.map(r=>r.rating)));
    const strong=rated.filter(r=>r.rating>=8).length;
    const label=!selected.length?'Limited big-match evidence':rated.length<2?'Limited big-match evidence':selected.length<3?(rating>=7.3?'Positive impact in important fixtures':'Mixed performances in high-'):(rating>=8&&strong>=2)?'Excellent in decisive matches':(rating>=7.4||(performance.goals+performance.assists)>=3)?'Strong big-match performer':'Mixed performances in high-pressure matches';
    const highlights=selected.slice().sort((a,b)=>b.importance.stake-a.importance.stake|| (b.rating??0)-(a.rating??0)).slice(0,4).map(r=>({id:r.id,opponent:r.opponent,competition:r.competition,reason:r.importance.reason,rating:r.rating,goals:r.goals,assists:r.assists,date:r.date}));
    return {label,matches:selected.length,stats:performance,qualifiedMatches:selected.map(r=>({id:r.id,date:r.date,opponent:r.opponent,competition:r.competition,category:r.category,stage:r.stage.name,score:r.score,minutes:r.minutes,rating:r.rating,goals:r.goals,assists:r.assists,keyPasses:r.keyPasses,bigChances:r.bigChances,reasons:r.importance.reasons,importance:r.importance.category,stake:r.importance.stake,ranking:r.importance.ranking})),highlightMatches:highlights,
      evidence:!selected.length?'No reliably identified high-stakes matches recorded.':`${selected.length} identified important fixtures · ${performance.goals} goals, ${performance.assists} assists${rating===null?'':`, ${rating} average rating`}.`,
      limitations:rows.some(r=>r.category==='Unknown')?['Some matches lack identifiable competition or round metadata.']:[]};
  }
  function team(season){
    const source=season.awardsV3717?.closed&&season.awardsV3717?.seasonSnapshot?.snapshotLocked?season.awardsV3717.seasonSnapshot.competitions:season.competitions;
    const comps=Array.isArray(source)?source:[];
    const confirmed=comps.filter(awarded).map(c=>({name:str(c.name),type:str(c.type||c.competitionType),date:c.date||c.wonDate||null}));
    // Archived review trophies may have more reliable proof than mutable competition status.
    const locked=season.awardsV3717?.seasonSnapshot;
    if(locked?.snapshotLocked&&Array.isArray(locked.trophies))for(const c of locked.trophies.filter(awarded))if(!confirmed.some(t=>norm(t.name)===norm(c.name)))confirmed.push({name:str(c.name),type:str(c.type||c.rankId)});
    const progress=comps.filter(c=>!awarded(c)&&c.status&& !/not entered|not started/i.test(str(c.status)))
      .map(c=>({name:str(c.name),status:str(c.status),stage:str(c.finish||c.phaseStatus||c.stage||'')}));
    const major=confirmed.filter(c=>/champions league|\bucl\b|world cup|liga mistrzow/.test(norm(c.name+' '+c.type))).length;
    const label=major?'Major collective success':confirmed.length>=2?'Strong team achievements':confirmed.length?'Competitive season':'No significant trophies confirmed';
    return {label,confirmed,progress,major,evidence:confirmed.length?`${confirmed.length} confirmed titles; ${confirmed.map(c=>c.name).join(', ')}.`:'No confirmed trophy wins found in this season record.'};
  }
  function european(rows,teamResult){
    const competitions=['UCL','UEL','UECL'].map(id=>{const games=rows.filter(m=>m.category===id),all=aggregate(games),ko=games.filter(m=>m.stage.knockout);
      return {id,stats:all,knockout:aggregate(ko),knockoutMatches:ko.length};});
    const count=competitions.reduce((n,c)=>n+c.stats.matches,0);
    const allG=competitions.reduce((n,c)=>n+c.stats.goals,0),allA=competitions.reduce((n,c)=>n+c.stats.assists,0);
    const matches=competitions.filter(c=>c.stats.matches>0);
    const allRating=mean(rows.filter(r=>['UCL','UEL','UECL'].includes(r.category)&&r.rating!=null).map(r=>r.rating));
    const label=count===0?'No European appearances recorded':count<4?'Limited European evidence':allRating>=8&&count>=6?'Outstanding European performances':allRating>=7.4?'Strong European performances':'Recorded European campaign';
    return {label,competitions,count,evidence:count?`${count} European appearances · ${allG} goals and ${allA} assists across ${matches.map(c=>c.id).join(', ')}.`:'No European appearances recorded this season.'};
  }
  function reportedTotals(season,rows,helpers){
    // The season summary includes manually imported historical totals; individual matches do not.
    // For locked seasons use frozen review stats, never mutable current season totals.
    const snap=season.awardsV3717?.seasonSnapshot;
    if(snap?.snapshotLocked&&snap.stats){const s=snap.stats;return {matches:bounded(s.matches,0,200)??rows.length,goals:bounded(s.goals,0,300)??sum(rows,'goals'),assists:bounded(s.assists,0,300)??sum(rows,'assists'),rating:bounded(s.rating,1,10)??aggregate(rows).rating,
      minutes:bounded(s.minutes,0,25000)??aggregate(rows).minutes, keyPasses:bounded(s.keyPasses,0,1000)??aggregate(rows).keyPasses,
      ratedMatches:bounded(s.ratedMatches,0,200)??aggregate(rows).ratedMatches,actionsObserved:aggregate(rows).actionsObserved,
      keyPassMatches:aggregate(rows).keyPassMatches,dribbles:aggregate(rows).dribbles,tackles:aggregate(rows).tackles,interceptions:aggregate(rows).interceptions,
      bigChances:aggregate(rows).bigChances,shots:aggregate(rows).shots,conversion:aggregate(rows).conversion,xg:aggregate(rows).xg,xgCoverage:aggregate(rows).xgCoverage,
      g90:rate(bounded(s.goals,0,300),bounded(s.minutes,1,25000)),a90:rate(bounded(s.assists,0,300),bounded(s.minutes,1,25000)),snapshot:true};}
    let st=null;try{st=typeof helpers.seasonTotals==='function'?helpers.seasonTotals(season):null;}catch{}
    const a=aggregate(rows);return {...a,matches:bounded(st?.m,0,200)??a.matches,goals:bounded(st?.g,0,300)??a.goals,assists:bounded(st?.a,0,300)??a.assists,
      // Unknown baseline minutes -> unknown rates; no extrapolating old matches.
      minutes:bounded(season.baseM,0,200)>0?null:a.minutes,
      g90:bounded(season.baseM,0,200)>0?null:rate(bounded(st?.g,0,300)??a.goals,a.minutes),
      a90:bounded(season.baseM,0,200)>0?null:rate(bounded(st?.a,0,300)??a.assists,a.minutes),snapshot:false};
  }
  // Compatibility entry point: the V4 engine is the sole analytical award model.
  function awardOutlook(report,season={}){
    return typeof MatchbookAwardsV4!=='undefined'?MatchbookAwardsV4.expand(report,season).outlook:[];
  }
  function buildReport(data,seasonId,helpers={}){
    const seasons=Array.isArray(data?.seasons)?data.seasons:[];
    const season=seasons.find(s=>str(s.id)===str(seasonId))||seasons[0];if(!season)return null;
    const rows=uniqueRows(data,season,helpers),t=reportedTotals(season,rows,helpers);
    const comps=['League','Cup','UCL','UEL','UECL','International'].map(id=>({id,stats:aggregate(rows.filter(r=>r.category===id))}));
    const seasonEnd=String(season.year||'').match(/(20\d{2})\s*[\/–-]\s*(\d{2,4})/);
    const endYear=seasonEnd?(Number(seasonEnd[2])<100?Math.floor(Number(seasonEnd[1])/100)*100+Number(seasonEnd[2]):Number(seasonEnd[2])):null;
    const dob=str(season.playerProfile?.birthDate||data?.profile?.birthDate||'');
    const derivedAge=endYear&&/^\d{4}-\d{2}-\d{2}$/.test(dob)?endYear-Number(dob.slice(0,4))-(dob.slice(5)> '06-30'?1:0):null;
    const archived=season?.awardsV3717?.seasonSnapshot?.snapshotLocked===true?season.awardsV3717.seasonSnapshot:null;
    const archivedLeague=archived?str(archived.leagueName||archived.competitions?.find(c=>category(c)==='League')?.name||''):null;
    const archivedBirth=archived?str(archived.playerBirthDate||''):null;
    const archivedYear=archived?bounded(archived.endYear,2000,2100):null;
    const archivedAge=archivedYear&&/^\d{4}-\d{2}-\d{2}$/.test(archivedBirth)?archivedYear-Number(archivedBirth.slice(0,4))-(archivedBirth.slice(5)>'06-30'?1:0):null;
    const r={seasonId:season.id,seasonLabel:str(archived?.seasonLabel||season.year||season.name||'Season'),club:str(season.club||data?.profile?.club||''),
      leagueName:archived?archivedLeague:str((season.competitions||[]).find(c=>category(c)==='League')?.name||season.league||''),leagueTier:'unknown',
      position:archived?str(archived.playerPosition||''):str(season.playerProfile?.positions||season.playerProfile?.position||data?.profile?.positions||''),
      ageAtSeasonEnd:archived?(bounded(archived.ageAtSeasonEnd,0,80)??bounded(archivedAge,0,80)):bounded(derivedAge,0,80),
      lockedCompetition:archived?archived.competitionStats||{}:null,
      rows,totals:t,competitions:comps,snapshotLocked:!!archived};
    const tierName=norm(r.leagueName||'');r.leagueTier=/laliga|la liga|premier league|bundesliga|serie a|ligue 1/.test(tierName)?'top-5':/eredivisie|primeira liga|liga portugal/.test(tierName)?'strong':tierName?'other':'unknown';
    r.team=team(season);
    if(r.team.confirmed.length&&t.matches<5){r.team.contributionNote='Trophy is confirmed, but recorded player participation is insufficient to establish a leading role.';}
    else if(r.team.confirmed.length){r.team.contributionNote=`${t.matches} season appearances recorded; team titles are confirmed separately from personal involvement.`;}
    r.consistency=consistency(rows);r.form=recentForm(rows);r.individual=individual(r);r.big=bigMatches(rows);r.europe=european(rows,r.team);
    r.outlook=[];r.coverage={journalMatches:rows.length,totalAppearances:t.matches,baseAppearances:Math.max(0,t.matches-rows.length),detailedMatches:rows.filter(row=>row.actionsTracked).length,ratedMatches:rows.filter(row=>row.rating!=null).length};
    r.playerName=season.playerProfile?.name||data.profile?.name;
    if(typeof MatchbookAwardsV4!=='undefined'&&Object.values(season.awardRulesV4||{}).some(v=>v&&v.start&&v.end)){
      r.periodRows=[];r.periodCompetitions=[];r.periodTeam={confirmed:[],progress:[]};
      for(const sourceSeason of seasons){const sourceRows=String(sourceSeason.id)===String(season.id)?rows:uniqueRows(data,sourceSeason,helpers);r.periodRows.push(...sourceRows);r.periodTeam.confirmed.push(...team(sourceSeason).confirmed.map(c=>({...c,seasonId:sourceSeason.id})));r.periodCompetitions.push(...MatchbookAwardsV4.competitions({rows:sourceRows},sourceSeason).map(c=>({...c,sourceSeasonId:sourceSeason.id})));}
      r.periodBig=bigMatches(r.periodRows);
    }
    return typeof MatchbookAwardsV4!=='undefined'?MatchbookAwardsV4.expand(r,season):r;
  }
  return Object.freeze({buildReport,category,stageOf,aggregate,consistency,recentForm,bigMatches,individual,awardOutlook,round,numeric});
});
