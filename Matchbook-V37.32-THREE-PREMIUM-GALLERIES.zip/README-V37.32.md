# Matchbook V37.32 · Three Premium Award Galleries

This updates V37.31's presentation and navigation. The statistical engine, eligibility rules, saved results, match events, career storage, snapshots and ceremony workflow remain in place.

## Explore

1. Open **Awards → Trophy Room**.
2. Choose **France Football**, **FIFA**, or **Other Honours**. Each opens a dedicated internal page.
3. Open **View award details** for a player/edition/result page. Breadcrumbs and Back buttons return to the collection or Trophy Room. Browser Back/Forward and reload retain the nested navigation state and selected season.
4. Use **Award Insights** for the internal Matchbook Performance Assessment and evidence. Scores and technical coverage do not appear on collection cards.
5. In **FIFA → Puskás**, choose a saved goal to inspect its actual shot location, Goal Mouth, technique, preparation and match. Expand its Award Insights for the goal-quality score.
6. **Other Honours** separates European, domestic and independent awards from competition leaderboard distinctions. Positions never create trophies.
7. **Manage award record** in an award detail retains the existing result and edition-rule editors. Competition rankings remain editable in **Your Seasons**.
8. Existing **Trophy Cabinet**, **Ceremonies**, and **History** remain available.

## Deployment

Extract the complete ZIP and deploy its root to the existing Vercel project, as before. No new backend, account or data reset is required. Download your career JSON backup before replacing deployed application files.

The three large trophy images are original photographic-style illustrations. They are presentation artwork, not official ceremony photographs or evidence of an award result.

## Tests

```sh
node --test tests/awards-v4.test.cjs
node tests/ui-flow.cjs
```

The browser test uses Playwright and Chromium and starts its own temporary HTTP server. Set `CHROMIUM_PATH` for a specific browser. Set `SCREENSHOT_DIR` to an existing folder to change the default `/tmp` screenshot output.

See `GALLERIES-IMPLEMENTATION-REPORT.md` and `VALIDATION-V37.32.txt` for exact verification results and limitations.
