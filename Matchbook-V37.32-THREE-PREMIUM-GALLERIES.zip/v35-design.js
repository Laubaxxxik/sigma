/* Matchbook V35.1 — stable visual layer only. No destructive DOM rewrites. */
(function(){
'use strict';
function apply(){
  document.body.classList.add('v35','v35-stable');
  document.body.classList.toggle('v36',typeof page!=='string'||page!=='Statistics');
  document.body.classList.toggle('v36-statistics',typeof page==='string'&&page==='Statistics');
  const themeMeta=document.querySelector('meta[name="theme-color"]');
  if(themeMeta)themeMeta.content='#38243f';
  const content=document.querySelector('#content');
  if(content){
    [...content.classList].filter(c=>c.startsWith('v35-page-')).forEach(c=>content.classList.remove(c));
    const key=String(typeof page==='string'?page:'').toLowerCase().replace(/[^a-z0-9]+/g,'-');
    if(key) content.classList.add('v35-page-'+key);
  }
  const modal=document.querySelector('#modal');
  if(modal) modal.classList.add('v35-modal-safe');
}
function install(){
  apply();
  if(typeof window.render==='function'){
    const previous=window.render;
    window.render=function(){
      const result=previous.apply(this,arguments);
      try{apply()}catch(err){console.error('V35.1 visual layer',err)}
      return result;
    };
  }
  if(typeof window.liveBoard==='function'){
    const previous=window.liveBoard;
    window.liveBoard=function(){
      const result=previous.apply(this,arguments);
      try{apply()}catch(err){console.error('V35.1 live visual layer',err)}
      return result;
    };
  }
  if(typeof window.liveSetup==='function'){
    const previous=window.liveSetup;
    window.liveSetup=function(){
      const result=previous.apply(this,arguments);
      try{apply()}catch(err){console.error('V35.1 setup visual layer',err)}
      return result;
    };
  }
}
window.installV35=install;
install();
})();
