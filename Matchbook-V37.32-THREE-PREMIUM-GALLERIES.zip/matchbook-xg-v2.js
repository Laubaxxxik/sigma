/* Matchbook xG v2 — transparent, heuristic logit model.
 * Inspired by the feature categories used by professional xG providers, NOT a
 * trained or reverse-engineered Opta/Sofascore model. Coefficients need eventual
 * calibration on a real labelled shot sample.
 * Geometry: normalized event pitch x,y in [0,100]; attack is towards x=100.
 * Pitch: 105m x 68m, goal: 7.32m.  Outcome/placement never enter pre-shot xG.
 */
(function(root, factory){
  const model=factory();
  if(typeof module!=='undefined' && module.exports)module.exports=model;
  if(root)root.MatchbookXGModel=model;
})(typeof globalThis!=='undefined'?globalThis:null,function(){
  'use strict';
  const MODEL_VERSION='matchbook-xg-v2.2';
  const COEFFICIENTS=Object.freeze({
    intercept:-1.45, distanceMeters:-0.082, angleRadians:1.80,
    weakerFoot:-0.40, header:-0.90, otherBodyPart:-0.25,
    cutback:0.50, throughBall:0.35, cross:-0.25,
    rebound:0.40, counterattack:0.22,
    firstTime:-0.18, volley:-0.42, halfVolley:-0.20,
    highBall:-0.20, directFreeKick:-0.65,
    underPressure:-0.42, contested:-0.23, crowded:-0.32,
    closeDefender:-0.42, nearbyDefender:-0.18, noNearbyDefender:0.14,
    clearSight:0.48, obstructedSight:-0.24, oneOnOne:0.32,
    keeperOutOfPosition:0.95, openGoal:2.05,
  });
  const PENALTY_XG=0.76;
  // API input may be partial, malformed or contain nonnumeric strings. Never allow
  // NaN, Infinity, booleans, symbols or arbitrary objects to reach the model.
  // Explicit numeric parsing for API/form data. Number(value) ?? fallback is
  // unsafe: Number('bad') is NaN, not null/undefined, and Number('') is zero.
  // Accept ordinary finite decimal strings (including Polish decimal commas),
  // but not hex, booleans, objects, whitespace-only strings or Infinity.
  function finiteNumber(value){
    if(typeof value==='number')return Number.isFinite(value)?value:null;
    if(typeof value!=='string')return null;
    const raw=value.trim();
    if(!/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?$/.test(raw))return null;
    const number=Number(raw.replace(',','.'));
    return Number.isFinite(number)?number:null;
  }
  function validDistance(...values){
    for(const raw of values){
      const number=finiteNumber(raw);
      if(number!==null&&number>=0&&number<=110)return number;
    }
    return null;
  }
  function validAngleDegrees(...values){
    for(const raw of values){
      const number=finiteNumber(raw);
      if(number===null)continue;
      // Signed angles can originate from a left/right geometry convention.
      // Geometry depends on the absolute opening angle. Reject out-of-range
      // magnitudes rather than turning invalid 900° into a plausible 180°.
      const magnitude=Math.abs(number);
      if(magnitude<=180)return magnitude;
    }
    return null;
  }
  const normalise=value => String(value??'').trim().toLowerCase().replace(/[\s_-]/g,'');
  const yes=value => value===true || value==='true' || value==='yes';
  function geometryFromLocation(location){
    const x=finiteNumber(location?.x),y=finiteNumber(location?.y);
    if(x===null||y===null||x<0||x>100||y<0||y>100)return null;
    const forward=(100-x)*1.05,lateral=(y-50)*.68;
    const a={x:forward,y:lateral-3.66},b={x:forward,y:lateral+3.66};
    const angle=Math.atan2(Math.abs(a.x*b.y-a.y*b.x),a.x*b.x+a.y*b.y);
    return {distanceMeters:Math.hypot(forward,lateral),angleRadians:angle};
  }
  function geometryFromInput(input){
    // The API accepts either normalized shot location, distance + angle in
    // degrees, or a mixture. Use recorded pitch location to fill *only* missing
    // geometry components. If geometry is entirely absent, it stays unknown.
    const distance=validDistance(input.distanceMeters,input.distance);
    const angle=validAngleDegrees(input.angleDegrees,input.angle);
    const locationGeometry=geometryFromLocation(input.location);
    if(distance===null&&!locationGeometry)return null;
    if(angle===null&&!locationGeometry)return null;
    return {
      distanceMeters:distance??locationGeometry.distanceMeters,
      angleRadians:angle===null?locationGeometry.angleRadians:angle*Math.PI/180,
    };
  }
  const clamp=(value,min,max)=>Math.min(max,Math.max(min,value));
  function boundedSigmoid(logit){
    if(typeof logit!=='number'||Number.isNaN(logit))return null;
    const boundedZ=Math.max(-20,Math.min(20,logit));
    return 1/(1+Math.exp(-boundedZ));
  }
  function estimateShotXG(input={}){
    if(!input||typeof input!=='object')return {value:null,source:'unknown',version:MODEL_VERSION,reason:'Invalid shot input'};
    // Penalty kicks in open play; shootout kicks are stored separately and excluded.
    if(yes(input.penalty)||normalise(input.situation)==='penalty')
      return {value:PENALTY_XG,source:'matchbook',version:MODEL_VERSION,logit:null,factors:{penalty:'fixed'},distance:null,angle:null};
    const geometry=geometryFromInput(input);
    if(!geometry)return {value:null,source:'unknown',version:MODEL_VERSION,reason:'Shot location or distance/angle required',factors:{}};
    let z=COEFFICIENTS.intercept+COEFFICIENTS.distanceMeters*geometry.distanceMeters+COEFFICIENTS.angleRadians*geometry.angleRadians;
    const factors={geometry:Math.round(z*10000)/10000};
    function add(key){const beta=COEFFICIENTS[key];z+=beta;factors[key]=beta;}
    const body=normalise(input.bodyPart||input.body),foot=normalise(input.dominantFoot);
    if(body==='head'||body==='header')add('header');
    else if(body==='chest'||body==='other')add('otherBodyPart');
    else if((body==='left'||body==='right'||body==='leftfoot'||body==='rightfoot') && ['left','right','leftfoot','rightfoot'].includes(foot) && body.replace('foot','')!==foot.replace('foot',''))add('weakerFoot');
    const delivery=normalise(input.delivery||input.preparation||input.assistType);
    const isDirectFreeKick=yes(input.directFreeKick)||['directfreekick','directfk'].includes(normalise(input.situation));
    if(!isDirectFreeKick){
      if(delivery==='cutback')add('cutback');
      else if(['throughball','throughpass'].includes(delivery))add('throughBall');
      else if(['cross','loftedcross'].includes(delivery))add('cross');
    }
    const situation=normalise(input.situation);
    if(!isDirectFreeKick && (yes(input.rebound)||situation==='rebound'))add('rebound');
    if(!isDirectFreeKick && (yes(input.counterattack)||['counter','counterattack','fastbreak'].includes(situation)))add('counterattack');
    if(isDirectFreeKick)add('directFreeKick');
    const technique=normalise(input.technique);
    const isVolley=technique==='volley'||body==='volley';
    if(!isDirectFreeKick){
      if(isVolley)add('volley');
      else if(technique==='halfvolley')add('halfVolley');
      else if(yes(input.firstTime)||delivery==='firsttime')add('firstTime');
    }
    // A high ball is harder to strike cleanly with the foot; do not double count headers.
    if(['high','aerial'].includes(normalise(input.ballHeight)) && !['head','header'].includes(body))add('highBall');
    const nearest=finiteNumber(input.defenderDistanceMeters);
    if(nearest!==null&&nearest>=0&&nearest<=50){
      // Nearest defender is the more precise feature; do NOT also subtract general pressure.
      if(nearest<1.5)add('closeDefender');
      else if(nearest<3.5)add('nearbyDefender');
      else if(nearest>=6)add('noNearbyDefender');
    }else{
      const pressure=normalise(input.pressure||input.context);
      if(yes(input.underPressure)||pressure==='underpressure')add('underPressure');
      else if(pressure==='crowded'||pressure==='crowdedspace')add('crowded');
      else if(pressure==='contested')add('contested');
    }
    if(yes(input.clearSight)||normalise(input.clearSight)==='yes')add('clearSight');
    else if(input.clearSight===false||normalise(input.clearSight)==='no')add('obstructedSight');
    if(!isDirectFreeKick && (yes(input.oneOnOne)||normalise(input.context)==='oneonone'))add('oneOnOne');
    const keeper=normalise(input.keeperPosition);
    if(yes(input.openGoal)||keeper==='opengoal'||keeper==='empty')add('openGoal');
    else if(keeper==='outofposition'||keeper==='offbalance')add('keeperOutOfPosition');
    // Clamp the logit BEFORE exponentiation, then clamp the probability and
    // round to three decimals. Incomplete metadata has neutral modifiers.
    if(!Number.isFinite(z))return {value:null,source:'unknown',version:MODEL_VERSION,reason:'Non-finite shot model input',factors:{}};
    const boundedZ=Math.max(-20,Math.min(20,z));
    const probability=boundedSigmoid(boundedZ);
    const value=Math.round(clamp(probability,0.01,0.99)*1000)/1000;
    return {value,source:'matchbook',version:MODEL_VERSION,logit:Math.round(boundedZ*10000)/10000,
      factors,distance:Math.round(geometry.distanceMeters*100)/100,
      angle:Math.round(geometry.angleRadians*180/Math.PI*100)/100};
  }
  return Object.freeze({version:MODEL_VERSION,penalty:PENALTY_XG,coefficients:COEFFICIENTS,geometryFromLocation,boundedSigmoid,estimateShotXG});
});
