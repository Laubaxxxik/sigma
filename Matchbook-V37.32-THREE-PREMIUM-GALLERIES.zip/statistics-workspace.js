/* Statistics presentation. Career records are read, never rewritten here. */
const statisticsWorkspaceState = { view: 'overview' };
const statisticsViews = [
  ['overview', 'Overview'], ['performance', 'Performance'],
  ['matches', 'Matches'], ['career', 'Career']
];

function statisticsRating(row) {
  const rating = suppliedNumber(row.m.rating);
  return rating !== null && rating > 0 ? rating : null;
}

function statisticsFormCard(range) {
  const rows = range.rows.slice(-8);
  const rated = rows.map(statisticsRating).filter(v => v !== null);
  const average = rated.length ? (rated.reduce((a, b) => a + b, 0) / rated.length).toFixed(1) : '—';
  return `<section class="mb-form-card">
    <div class="fm-section-title"><div><span class="fm-eyebrow">RECENT FORM</span><h2>Your last ${rows.length} appearances</h2></div><div class="mb-form-average"><b>${average}</b><small>Avg. rating</small></div></div>
    <div class="mb-form-chart" aria-label="Match ratings, oldest to newest">${rows.map(row => {
      const m = row.m, rating = statisticsRating(row), opponent = matchOpponentForProfile(m) || 'Opponent';
      const result = matchOutcome(m, analyticsClub(m));
      const resultLabel = ({ W: 'W', R: 'D', P: 'L' })[result] || '—';
      const label = `${opponent} · ${fmPrettyDate(m.date)} · rating ${rating === null ? 'not recorded' : rating.toFixed(1)}`;
      return `<button type="button" class="mb-form-column" data-action="recap:${esc(m.id)}" title="${esc(label)}" aria-label="${esc(label)}">
        <span class="mb-form-bar-slot"><span class="mb-form-bar ${rating === null ? 'is-unknown' : rating >= 8 ? 'is-high' : ''}" style="--bar-height:${rating === null ? 8 : fmClamp(rating, 0, 10) * 10}%"><b>${rating === null ? '—' : rating.toFixed(1)}</b></span></span>
        <span class="mb-form-result ${esc(result || '')}">${resultLabel}</span><small>${esc(fmPrettyDate(m.date).replace(/ \d{4}$/, ''))}</small>
      </button>`;
    }).join('')}</div>
    <p class="mb-chart-note">Oldest to newest · select a match to open its report.</p>
  </section>`;
}

function statisticsSnapshot(range, a) {
  const contributions = a.goals + a.assists;
  const per90 = a.rateMinutes > 0 ? (contributions * 90 / a.rateMinutes).toFixed(2) : '—';
  const observed = range.rows.filter(r => r.hasEvents || Object.keys(r.m.manualStats || {}).length).length;
  return `<section class="mb-snapshot"><div class="fm-section-title"><div><span class="fm-eyebrow">AT A GLANCE</span><h2>Your contribution</h2></div></div>
    <div class="mb-contribution"><b>${contributions}</b><span>goals + assists<small>${per90} per 90 minutes</small></span></div>
    <div class="mb-snapshot-row"><span>Appearances with a goal or assist</span><b>${range.rows.filter(r => num(r.m.goals) + num(r.m.assists) > 0).length} / ${range.count}</b></div>
    <div class="mb-snapshot-row"><span>Detailed matches tracked</span><b>${observed} / ${range.count}</b></div>
    <p>Totals follow your confirmed match records. Unrecorded details stay as a dash.</p>
  </section>`;
}

function statisticsEmptyState(filtered) {
  return `<section class="mb-stat-empty"><span class="mb-empty-symbol" aria-hidden="true">▥</span>
    <h2>${filtered ? 'No appearances in this selection' : 'Your next match starts the story'}</h2>
    <p>${filtered ? 'Try another season or clear the filters to see your recorded matches.' : 'Record your first appearance to see your form, contributions and match statistics here.'}</p>
    <div class="actions">${filtered ? '<button type="button" class="primary" data-stat-reset-all>Clear all filters</button>' : '<button type="button" class="primary" data-action="live">Start match</button><button type="button" data-action="new-match">Enter result</button>'}</div>
  </section>`;
}

function statisticsWorkspace({source, base, list, range, a}) {
  const view = statisticsViews.some(([key]) => key === statisticsWorkspaceState.view) ? statisticsWorkspaceState.view : 'overview';
  const filters = [['competition', statsCompetition], ['role', analyticsState.role], ['venue', analyticsState.venue], ['outcome', analyticsState.outcome], ['bigMatches', analyticsState.bigMatches ? 'Big Matches' : ''], ['recent', analyticsState.recent ? 'Last ' + analyticsState.recent : '']].filter(([, value]) => value);
  const filtered = !!source.matches.length || profileCompetitionCategory !== 'all' || !!filters.length;
  const tracked = range.rows.filter(row => row.hasEvents || Object.keys(row.m.manualStats || {}).length).length;
  const panels = {
    overview: list.length ? `<div class="mb-stats-overview-grid">${statisticsFormCard(range)}${statisticsSnapshot(range, a)}</div>${advancedShotMap(range)}` : statisticsEmptyState(filtered),
    performance: list.length ? `${fotmobSeasonPerformance(range, list)}<details class="fm-deep-analysis"><summary>Form, comparisons & records</summary>${plusForm(range)}${plusComparison(base)}${analyticsRecords(list)}</details>` : statisticsEmptyState(filtered),
    matches: list.length ? `<div class="mb-match-toolbar"><p>Latest ${Math.min(range.count, 10)} appearances in your selection.</p><button type="button" data-action="go-matches">All results →</button></div><p class="mb-table-hint">Swipe the table to see all columns.</p>${fotmobRecentMatches(range)}` : statisticsEmptyState(filtered),
    career: `${fotmobAbout(range, a)}<div class="mb-career-heading"><h2>Your career record</h2><p>All saved seasons · independent of the filters above.</p></div><div class="fm-career-layout">${fotmobCareer()}${fotmobTrophies()}</div>${fotmobMarketValueCard()}${typeof matchbookHonoursVaultMarkup==='function'?matchbookHonoursVaultMarkup():''}<div data-stats-context></div>`
  };
  return `<div class="fotmob-player-statistics mb-statistics">
    ${statisticsWarnings(source.errors)}
    <div class="fm-profile-layout">${fotmobProfileHeader()}</div>
    ${fotmobSeasonSummary(range, list, a)}
    <div class="mb-stats-filter-row">${fotmobAdvancedFilters([], filters)}<button type="button" class="mb-export" data-stats-export ${list.length ? '' : 'disabled'}>Export CSV <span aria-hidden="true">↓</span></button></div>
    <div class="mb-coverage-strip" role="status"><span class="mb-coverage-dot" aria-hidden="true"></span><span><b>${range.count}</b> appearances · <b>${tracked}</b> with detailed data${filters.length || profileCompetitionCategory !== 'all' ? ' · Filters active' : ''}</span>${filters.length || profileCompetitionCategory !== 'all' ? '<button type="button" data-stat-reset-all>Reset filters</button>' : ''}</div>
    ${analyticsState.bigMatches?`<details class="mb28-big-included"><summary>Why these ${list.length} matches qualify as Big Matches</summary><p>Qualified by recorded knockout stakes, canonical elite club identity, recorded difficulty or explicit high-stakes tags. Selection is independent of player performance. Unclassified fixtures remain excluded.</p>${list.length?list.map(m=>{const raw=db.matches.find(x=>String(x.id)===String(m.id))||m,decision=window.MatchbookBigMatchesV3728?.classify(raw,{seasonLabel:db.seasons.find(s=>String(s.id)===String(raw.season))?.year||db.seasons.find(s=>String(s.id)===String(raw.season))?.name});return `<button type="button" data-action="recap:${esc(m.id)}">${esc(m.opponent||'Opponent')} · ${esc(m.date||'Date not recorded')} — ${esc([decision?.category,...(decision?.reasons||[])].filter(Boolean).join(' · ')||'Recorded important fixture')}</button>`}).join(''):'No matches meet the current combined filters.'}</details>`:''}
    ${analyticsGoalWarnings(list)}
    <nav class="mb-stats-tabs" role="tablist" aria-label="Statistics sections">${statisticsViews.map(([key, label]) => `<button type="button" role="tab" id="stats-tab-${key}" data-stats-view="${key}" aria-selected="${key === view}" aria-controls="stats-panel-${key}" tabindex="${key === view ? '0' : '-1'}">${label}${key === 'matches' ? `<span>${range.count}</span>` : ''}</button>`).join('')}</nav>
    ${statisticsViews.map(([key]) => `<div class="mb-stats-panel" id="stats-panel-${key}" role="tabpanel" aria-labelledby="stats-tab-${key}" tabindex="0" ${key === view ? '' : 'hidden'}>${panels[key]}</div>`).join('')}
    <details class="stats-coverage fm-coverage"><summary>How these statistics work</summary><p>Totals use confirmed appearances in the selected period. Detailed metrics use recorded events or explicit post-match totals. A dash means unknown, not zero. Per-90 metrics use only matches that recorded that metric; missing playing time makes the rate unavailable.</p><p>Quick tracking captures selected actions, so detailed figures may be incomplete. Historical season totals remain in Career; they are not added to filtered journal appearances. xG and estimated market values are Matchbook models, not provider-certified values.</p></details>
  </div>`;
}

function statisticsCsvCell(value) {
  let text = String(value ?? '');
  // Spreadsheet programs must not interpret imported player/club names as formulas.
  if (/^[\s]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}

function statisticsCsv(list) {
  const rows = [['Date', 'Season', 'Competition', 'Opponent', 'Score', 'Minutes', 'Goals', 'Assists', 'Rating'], ...list.map(m => [m.date, db.seasons.find(s => s.id === m.season)?.name || m.season, profileCompetitionName(m), matchOpponentForProfile(m), m.score, suppliedNumber(m.minutes), num(m.goals), num(m.assists), suppliedNumber(m.rating)])];
  return '\ufeff' + rows.map(row => row.map(statisticsCsvCell).join(',')).join('\r\n');
}

function exportStatisticsCsv() {
  const list = analyticsFilter(statisticsSource().matches);
  if (!list.length) return toast('No appearances to export.');
  const url = URL.createObjectURL(new Blob([statisticsCsv(list)], {type:'text/csv;charset=utf-8'}));
  const a = document.createElement('a');
  a.href = url; a.download = 'matchbook-statistics-' + new Date().toISOString().slice(0, 10) + '.csv';
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('Statistics exported.');
}

function selectStatisticsView(view, focus = true) {
  if (!statisticsViews.some(([key]) => key === view)) return;
  statisticsWorkspaceState.view = view;
  // Switching sections does not rebuild charts or discard open filters.
  document.querySelectorAll('[data-stats-view]').forEach(button => {
    const selected = button.dataset.statsView === view;
    button.setAttribute('aria-selected', String(selected)); button.tabIndex = selected ? 0 : -1;
    if (selected && focus) button.focus({preventScroll: true});
  });
  document.querySelectorAll('.mb-stats-panel').forEach(panel => {panel.hidden = panel.id !== 'stats-panel-' + view;});
}

document.addEventListener('click', event => {
  const button = event.target.closest?.('[data-stats-view], [data-stats-export], [data-stat-reset-all]');
  if (!button || button.disabled) return;
  if (button.hasAttribute('data-stats-view')) selectStatisticsView(button.dataset.statsView);
  else if (button.hasAttribute('data-stats-export')) exportStatisticsCsv();
  else {
    Object.assign(analyticsState, {recent:0, venue:'', role:'', outcome:'', bigMatches:false});
    statsCompetition = ''; profileCompetitionCategory = 'all'; analyticsPlus.map = 'all'; render();
  }
});

document.addEventListener('keydown', event => {
  const tab = event.target.closest?.('[data-stats-view]');
  if (!tab || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
  event.preventDefault();
  const index = statisticsViews.findIndex(([key]) => key === tab.dataset.statsView);
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? statisticsViews.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + statisticsViews.length) % statisticsViews.length;
  selectStatisticsView(statisticsViews[next][0]);
});
