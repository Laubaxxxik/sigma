/* Matchbook V37.26 — a light, data-driven Trophy Room on the existing Awards page.
 * Completely read-only analytics; existing ceremony, inbox and Museum Vault save flows remain authoritative.
 */
(function () {
  'use strict';
  const engine=window.MatchbookAwardOutlookV3726;
  if(!engine)return;
  let tab='overview',selectedSeasonId='',expandedAward='';
  const esc26=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num=n=>n===null||n===undefined?'—':String(n);
  const st=s=>String(s||'');
  const official=(season,id)=>season?.awardsV3717?.global?.[id]||null;
  const badge=(label,tone='neutral')=>`<span class="tr26-badge ${tone}">${esc26(label)}</span>`;
  const colour=label=>/favourite|excellent|exceptional|major|highly|outstanding|strong|won|serious/i.test(label)?'positive':/not currently|insufficient|inconsistent|limited|declining|lost/i.test(label)?'negative':/emerging|on the radar|mixed|competitive|generally/i.test(label)?'amber':'neutral';
  const awardNames={ballon_dor:"Ballon d'Or",fifa_the_best:'The Best (FIFA)',european_golden_shoe:'European Golden Shoe',domestic_player_of_season:'Domestic Player of the Season',kopa_trophy:'Kopa Trophy',ucl_player_of_season:'UCL Player of the Season',playmaker_of_year:'Playmaker of the Year',fifpro_world_xi:'FIFPro World XI'};
  function icon(type){
    const common='viewBox="0 0 80 80" width="70" height="70" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"';
    const gold='<defs><linearGradient id="tr26gold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff2bd"/><stop offset=".33" stop-color="#d6992f"/><stop offset=".65" stop-color="#f8d97b"/><stop offset="1" stop-color="#89501c"/></linearGradient></defs>';
    const silver='<defs><linearGradient id="tr26silver" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff"/><stop offset=".35" stop-color="#98a0ab"/><stop offset=".69" stop-color="#e6e4df"/><stop offset="1" stop-color="#626c76"/></linearGradient></defs>';
    if(type==='ballon_dor'||type==='kopa_trophy')return `<svg ${common}>${gold}<ellipse cx="40" cy="72" rx="24" ry="5" fill="#bc956d" opacity=".28"/><path d="M33 54h14v8H33zM24 63h32v7H24z" fill="#a87931"/><circle cx="40" cy="31" r="25" fill="url(#tr26gold)" stroke="#ba832e" stroke-width="1.6"/><path d="M40 6L53 16L49 32L32 39L19 29L24 15Z M49 32L64 42L53 53L36 55L32 39M19 29L15 42L29 54" stroke="#9f702d" stroke-width="1" fill="none"/></svg>`;
    if(type==='european_golden_shoe')return `<svg ${common}>${gold}<path d="M12 44q8-6 19-7l5-18 10 2 1 21 17 9q6 3 6 10v6H9q-3-11 3-23z" fill="url(#tr26gold)" stroke="#af752b" stroke-width="2"/><path d="M33 36l12 7m-16-1l12 7m-16-2l10 7M12 63h55" stroke="#8d602a" stroke-width="2" fill="none"/></svg>`;
    return `<svg ${common}>${type==='fifa_the_best'?silver:gold}<path d="M20 18C3 16 6 46 25 48M60 18c17-2 14 28-5 30" fill="none" stroke="${type==='fifa_the_best'?'#9aa2ae':'#c7a164'}" stroke-width="7"/><path d="M20 10h40l-5 32q-5 13-15 13T25 42z" fill="url(#${type==='fifa_the_best'?'tr26silver':'tr26gold'})"/><path d="M35 54h10v10H35zM25 65h30v7H25z" fill="${type==='fifa_the_best'?'#87939e':'#b48243'}"/></svg>`;
  }
  function seasonChoice(){const seasons=(db.seasons||[]);const currentId=seasons.find(s=>String(s.id)===String(selectedSeasonId))?.id||
    seasons.find(s=>String(s.id)===String(season))?.id||seasons.at(-1)?.id||'';
    selectedSeasonId=currentId;
    return `<label class="tr26-season-label"><span class="sr-only">Select season for awards analysis</span><select data-tr26-season>${seasons.map(s=>`<option value="${esc26(s.id)}" ${String(s.id)===String(currentId)?'selected':''}>${esc26(s.year||s.name||'Season')}</option>`).join('')}</select></label>`;
  }
  function evidence(a){const metrics=[...(a.evidence||[])];const limits=a.limits||[];
    return `<details class="tr26-evidence" ${expandedAward===a.id?'open':''}><summary>Why this assessment? <span aria-hidden="true">⌄</span></summary><div><strong>Supporting evidence</strong><ul>${metrics.length?metrics.map(v=>`<li>${esc26(v)}</li>`).join(''):'<li>Not enough verified evidence yet.</li>'}</ul>${limits.length?`<strong>Limitations</strong><ul>${limits.map(v=>`<li>${esc26(v)}</li>`).join('')}</ul>`:''}<small>Analytical interpretation only; not an official nomination or predicted rank.</small></div></details>`;
  }
  function awardCard(a){return `<article class="tr26-award-card"><div class="tr26-award-art">${icon(a.id)}</div><h3>${esc26(a.name)}</h3>${badge(a.label,colour(a.label))}<p>${esc26(a.evidence?.[0]||a.limits?.[0]||'Assessment based on available career records.')}</p><button type="button" class="mb28-explain" data-mb28-evidence="${esc26(a.id)}">Evidence &amp; analysis →</button>${evidence(a)}</article>`;}
  function trophyBlocks(season){
    const snapshot=season?.awardsV3717?.seasonSnapshot;
    const comps=(snapshot?.snapshotLocked?snapshot.competitions:season?.competitions)||[];
    const items=Array.isArray(comps)?comps:[];
    const confirmed=[...items.filter(c=>String(c?.status||'').toLowerCase()==='won')];
    if(snapshot?.snapshotLocked&&Array.isArray(snapshot.trophies))for(const c of snapshot.trophies){
      if(String(c?.status||'won').toLowerCase()!=='won')continue;
      if(!confirmed.some(t=>String(t.name).toLowerCase()===String(c.name).toLowerCase()))confirmed.push(c);
    }
    return confirmed.length?confirmed.slice(0,8).map(c=>`<article class="tr26-trophy-card won"><div class="tr26-trophy-art">${icon('trophy')}</div><strong>${esc26(c.name||'Competition')}</strong>${badge('Won','positive')}<small>${esc26(season.year||'Season')}</small></article>`).join(''):'<p class="tr26-empty">No team honours confirmed for this season.</p>';
  }
  function competitionProgress(season){
    const snap=season?.awardsV3717?.seasonSnapshot;
    const comps=snap?.snapshotLocked?snap.competitions:season?.competitions;
    const pending=(Array.isArray(comps)?comps:[]).filter(c=>String(c?.status||'').toLowerCase()!=='won'&&c.name);
    return pending.length?`<div class="tr26-progress"><strong>Competition progress — not trophies won</strong><div>${pending.slice(0,8).map(c=>badge(`${c.name}: ${c.status||'Not confirmed'}`)).join('')}</div></div>`:'';
  }
  function officialTable(season,report){const asses=report?.outlook||[],review=season?.awardsV3717||{};
    const ids=['ballon_dor','fifa_the_best','kopa_trophy','european_golden_shoe','ucl_player_of_season','playmaker_of_year'];
    const rows=ids.map(id=>{const actual=official(season,id);const outlook=asses.find(a=>a.id===id);
      return `<tr><td><span class="tr26-table-icon">${icon(id)}</span><strong>${esc26(awardNames[id]||id)}</strong></td><td>${esc26(season.year||'—')}</td><td>${actual?.status?badge(actual.status,actual.status==='Won'?'positive':actual.status==='Lost'?'negative':'amber'):badge('No recorded result')}</td><td>${esc26(outlook?.label||'Insufficient evidence')}<button type="button" class="mb28-explain" data-mb28-evidence="${esc26(id)}">Why?</button></td><td><button type="button" data-tr26-tab="individual">Details</button></td></tr>`;
    });return `<div class="tr26-table-wrap"><table><thead><tr><th>Award</th><th>Season</th><th>Saved result</th><th>Analytical outlook</th><th></th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  }
  function factor(name,result,description){const key=({'Individual form':'form','Consistency':'consistency','Big-match impact':'big','Team success':'team','Goals':'goals','Assists':'assists','European stage':'europe','Data coverage':'individual'})[name]||'individual';return `<button type="button" class="tr26-factor mb28-clickable" data-mb28-evidence="${key}" title="Open supporting evidence"><span>${esc26(name)}</span>${badge(result,colour(result))}${description?`<small>${esc26(description)}</small>`:''}<small class="mb28-open-hint">Details →</small></button>`;}
  function analysisBody(r){return `<div class="tr26-factor-grid">
      ${factor('Individual form',r.form.label,r.form.summary)}
      ${factor('Consistency',r.consistency.label,r.consistency.evidence)}
      ${factor('Big-match impact',r.big.label,r.big.evidence)}
      ${factor('Team success',r.team.label,r.team.evidence)}
      ${factor('Goals',`${r.totals.goals} G`,'Confirmed season total')}
      ${factor('Assists',`${r.totals.assists} A`,'Confirmed season total')}
      ${factor('European stage',r.europe.count?`${r.europe.count} apps`:'No apps',r.europe.evidence)}
      ${factor('Data coverage',`${r.coverage.journalMatches} match logs`,`${r.coverage.detailedMatches} with recorded actions`)}
    </div>`;}
  function dimensionCards(r){const cards=[
    ['Individual Performance',r.individual.label,r.individual.evidence,r.individual.limitations],
    ['Consistency',r.consistency.label,[r.consistency.evidence,r.form.summary],[]],
    ['Big-Match Influence',r.big.label,[r.big.evidence],r.big.limitations],
    ['Collective Achievements',r.team.label,[r.team.evidence,r.team.contributionNote],[]],
    ['European Performance',r.europe.label,[r.europe.evidence],[]]];
    return cards.map(([name,label,detail,limitations])=>`<details class="tr26-dimension"><summary><div><strong>${esc26(name)}</strong><span>${esc26(label)}</span></div>${badge(label,colour(label))}</summary><div class="tr26-dim-detail">${detail.filter(Boolean).map(x=>`<p>${esc26(x)}</p>`).join('')}${limitations?.map(x=>`<p class="tr26-limit">${esc26(x)}</p>`).join('')||''}<button type="button" class="mb28-explain" data-mb28-evidence="${({'Individual Performance':'individual','Consistency':'consistency','Big-Match Influence':'big','Collective Achievements':'team','European Performance':'europe'})[name]}">Open full evidence &amp; matches →</button></div></details>`).join('');}
  function leagueSpotlight(r){const c=r.outlook.find(a=>a.id==='domestic_player_of_season');return `<div class="tr26-league-focus"><div class="tr26-league-mark">★</div><div><h3>${esc26(c.name)}</h3>${badge(c.label,colour(c.label))}<p>${esc26(c.evidence[0])}. ${esc26(c.evidence[1]||'Only league matches are considered.')}</p><button type="button" class="mb28-explain" data-mb28-evidence="domestic_player_of_season">Supporting league evidence →</button></div><span class="tr26-league-ghost" aria-hidden="true">♜</span></div>`;}
  function breakdown(r){return `<section class="tr26-section"><div class="tr26-section-heading"><div><small>EUROPEAN COMPETITIONS</small><h2>Separate European campaigns</h2></div></div><div class="tr26-euro-grid">${r.europe.competitions.map(c=>`<article><strong>${c.id}</strong><div><b>${c.stats.matches}</b><small>Apps</small></div><div><b>${c.stats.goals} / ${c.stats.assists}</b><small>G / A</small></div><div><b>${num(c.stats.rating)}</b><small>Rating</small></div><small>${c.knockoutMatches} recorded knockout appearances</small></article>`).join('')}</div><p class="tr26-footnote">Missing minute or event records are left unknown. Statistics are calculated separately for each competition.</p></section>`;}
  function detailedStats(r){
    const title={League:'Domestic league',Cup:'Domestic cups',UCL:'Champions League',UEL:'Europa League',UECL:'Conference League',International:'International'};
    return `<section class="tr26-section"><div class="tr26-section-heading"><div><small>GOALS / ASSISTS / CREATION</small><h2>Performance by competition</h2><p>Data from saved match reports only. Historical totals with unknown competition are not assigned to a league.</p></div></div><div class="tr26-table-wrap"><table><thead><tr><th>Competition</th><th>Apps</th><th>G</th><th>A</th><th>Avg rating</th><th>Key passes</th></tr></thead><tbody>${r.competitions.map(c=>`<tr><td>${esc26(title[c.id]||c.id)}</td><td>${c.stats.matches}</td><td>${c.stats.goals}</td><td>${c.stats.assists}</td><td>${num(c.stats.rating)}</td><td>${num(c.stats.keyPasses)}</td></tr>`).join('')}</tbody></table></div><div class="tr26-data-summary"><div><strong>${num(r.totals.g90)}</strong><small>Goals / 90</small></div><div><strong>${num(r.totals.a90)}</strong><small>Assists / 90</small></div><div><strong>${num(r.totals.conversion)}${r.totals.conversion===null?'':'%'}</strong><small>Recorded shot conversion</small></div><div><strong>${num(r.totals.xg)}</strong><small>xG · fully covered recorded shots only</small></div></div><p class="tr26-footnote">${esc26(r.coverage.baseAppearances?`${r.coverage.baseAppearances} historical appearances have no match-level competition split. `:'')}Chance creation figures reflect selected recorded events; unrecorded actions are not assumed to be zero. Confirmed individual awards come only from stored results.</p></section>`;
  }
  function recentHistory(){const history=(db.seasons||[]).slice().reverse().flatMap(s=>{
     const a=s.awardsV3717;if(!a?.closed)return [];
     const officialItems=Object.entries(a.global||{}).filter(([,v])=>v?.stage==='resolved'||v?.status==='Won'||v?.status==='Lost'||v?.status==='Nominated').map(([id,v])=>({season:s.year||s.name,label:awardNames[id]||id,status:v.status}));
     const manual=(a.manualAwards||[]).filter(x=>x?.status==='Won'||x?.status==='Nominated').map(x=>({season:s.year||s.name,label:x.label||x.type,status:x.status}));return [...officialItems,...manual];
   });return history.length?history.slice(0,6).map(x=>`<div class="tr26-history-row"><strong>${esc26(x.season)}</strong><span>${esc26(x.label)}</span>${badge(x.status,x.status==='Won'?'positive':'amber')}</div>`).join(''):'<p class="tr26-empty">No confirmed award history recorded.</p>';
  }
  function sidebar(r){const league=r.outlook.find(a=>a.id==='domestic_player_of_season');return `<div class="tr26-column tr26-side-column">
    <section class="tr26-section tr26-assessment"><small>SEASON ASSESSMENT</small><h2>Award Outlook — Season Analysis</h2><p>Live assessment of ${esc26(r.seasonLabel)}, based on recorded performances and confirmed results.</p>${leagueSpotlight(r)}
    <h3 class="tr26-mini-title">KEY FACTORS THIS SEASON</h3>${analysisBody(r)}
    <h3 class="tr26-mini-title">PERFORMANCE DIMENSIONS</h3><div class="tr26-dimensions">${dimensionCards(r)}</div></section>
    <section class="tr26-section"><div class="tr26-section-heading"><div><small>AWARD HISTORY</small><h2>Recent Seasons</h2></div><button data-tr26-tab="history">View full history →</button></div>${recentHistory()}</section>
  </div>`;}
  function overview(season,r){const picks=['ballon_dor','fifa_the_best','european_golden_shoe','domestic_player_of_season'].map(id=>r.outlook.find(x=>x.id===id)).filter(Boolean);
    return `<div class="tr26-main-grid"><div class="tr26-column"><section class="tr26-award-feature"><div class="tr26-feature-head"><div><small>AWARD OUTLOOK</small><h2>Main Individual Honours</h2><p>Evidence-based candidacy, not official nominations or guaranteed outcomes.</p></div><span class="tr26-feature-label">ⓘ Analytical outlook — not a prediction</span></div><div class="tr26-award-grid">${picks.map(awardCard).join('')}</div></section>
      <section class="tr26-section"><div class="tr26-section-heading"><div><small>TROPHIES WON</small><h2>Honours this Season</h2><p>Verified honours and progress — victories are never inferred.</p></div><button data-tr26-tab="trophies">View all honours →</button></div><div class="tr26-trophies">${trophyBlocks(season)}</div>${competitionProgress(season)}</section>
      <section class="tr26-section"><div class="tr26-section-heading"><div><small>INDIVIDUAL AWARDS</small><h2>Key Awards & Recognition</h2><p>Analytical outlook is separate from recorded ceremony results.</p></div></div>${officialTable(season,r)}</section>
    </div>${sidebar(r)}</div>`;}
  function trophies(season){const awards=window.matchbookAwardsV3719?.getTrophies?.()||[];
    return `<section class="tr26-section"><div class="tr26-section-heading"><div><small>THE PRIVATE COLLECTION</small><h2>All confirmed honours</h2><p>The entire saved career — no projected trophies.</p></div></div>${awards.length?`<div class="tr26-trophies">${awards.map(t=>`<article class="tr26-trophy-card won"><div class="tr26-trophy-art">${icon(t.type==='individual'?'ballon_dor':'trophy')}</div><strong>${esc26(t.name)}</strong>${badge('Won','positive')}<small>${esc26(t.season)}</small></article>`).join('')}</div>`:'<p class="tr26-empty">No confirmed trophies yet. Results remain in the season archive until recorded as won.</p>'}</section>`;}
  function individualTab(season,r){const old=window.matchbookAwardsV3719?.awardRoom?.()||'';
    const root=document.createElement('div');root.innerHTML=old;
    const nominations=root.querySelector('.aw19-nominations');
    const nominationsHtml=nominations?nominations.outerHTML:'<p>No existing ceremonies available.</p>';
    return `<section class="tr26-section"><div class="tr26-section-heading"><div><small>OFFICIAL CEREMONY RESULTS</small><h2>Individual Awards</h2><p>Saved nominations and manual WON / LOST decisions remain linked to the original awards engine.</p></div></div>${nominationsHtml}</section>
      <section class="tr26-section"><div class="tr26-section-heading"><div><small>OUTLOOK</small><h2>Award-by-award analysis</h2></div></div><div class="tr26-award-grid tr26-detail-awards">${r.outlook.map(awardCard).join('')}</div></section>`;}
  function outlookTab(r){return `<section class="tr26-section"><small>LIVE PERFORMANCE ASSESSMENT</small><h2>Detailed Season Performance</h2><p>Recent form and consistency are separate; every dimension is calculated independently from recorded evidence.</p><div class="tr26-dimensions">${dimensionCards(r)}</div></section>${breakdown(r)}${detailedStats(r)}<section class="tr26-section"><small>AWARDS CANDIDACY</small><h2>All award assessments</h2><div class="tr26-award-grid tr26-detail-awards">${r.outlook.map(awardCard).join('')}</div></section>`;}
  function historyTab(){return `<section class="tr26-section"><small>AWARD HISTORY</small><h2>Recorded career awards</h2><p>Only saved nominations, winners and recorded results. Historical assessments never create achievements.</p>${recentHistory()}</section>`;}
  function screen(){const seasons=db.seasons||[];if(!seasons.length)return '<div class="tr26-room"><p>Add a season to see awards outlook.</p></div>';
    const chooser=seasonChoice(),s=seasons.find(x=>String(x.id)===String(selectedSeasonId))||seasons[0];
    const helpers={matchView:typeof matchView==='function'?matchView:null,seasonTotals:typeof seasonTotals==='function'?seasonTotals:null,actionStats:typeof actionStats==='function'?actionStats:null,playerMatcher:typeof playerMatcher==='function'?playerMatcher:null};
    const r=engine.buildReport(db,s.id,helpers);if(!r)return '<div class="tr26-room">No season data available.</div>';
    const p=typeof playerProfile==='function'?playerProfile()||{}:db.profile||{},avatar=typeof playerPhotoMarkup==='function'?playerPhotoMarkup('tr26-portrait',p):`<span class="tr26-placeholder">${esc26(st(p.name).slice(0,1)||'P')}</span>`;
    return `<div class="tr26-room"><header class="tr26-header"><div class="tr26-identity">${avatar}<div><strong>${esc26(p.name||'Player')}</strong><span>${esc26(r.club)} · #${esc26(p.number||'—')} · ${esc26(r.position||'Position not recorded')}</span></div></div><div class="tr26-title"><small>MATCHBOOK / HONOURS & AWARDS</small><h1>The Trophy Room</h1><p>${esc26(p.name||'Player')} · career honours, award races and season recognition</p></div>${chooser}</header>
      <nav class="tr26-tabs" aria-label="Trophy Room views">${[['overview','Overview','◈'],['trophies','Trophies','♜'],['individual','Individual Awards','♕'],['outlook','Award Outlook','▥'],['history','History','◴']].map(([k,v,i])=>`<button type="button" data-tr26-tab="${k}" class="${tab===k?'active':''}" aria-current="${tab===k?'page':'false'}"><span aria-hidden="true">${i}</span> ${v}</button>`).join('')}</nav>
      <div class="tr26-tab-panel">${tab==='overview'?overview(s,r):tab==='trophies'?trophies(s):tab==='individual'?individualTab(s,r):tab==='outlook'?outlookTab(r):historyTab()}</div>
      <p class="tr26-footer">Matchbook analytical assessment · current data coverage: ${r.coverage.journalMatches} recorded matches, ${r.coverage.detailedMatches} with tracked actions. Not a verified worldwide ranking. Saved awards and ceremonies are unchanged.</p></div>`;
  }
  const previous=typeof managementView==='function'?managementView:null;
  if(previous)managementView=function(){return page==='Awards'?screen():previous();};
  document.addEventListener('click',event=>{
    const b=event.target.closest?.('[data-tr26-tab]');if(!b||page!=='Awards')return;
    event.preventDefault();tab=b.dataset.tr26Tab;
    // Refresh the panel without replacing the clicked tab button. Removing the
    // active button during its click can stall automation and keyboard focus.
    const target=document.querySelector('.tr26-tab-panel');
    if(!target)return;
    const template=document.createElement('div');template.innerHTML=screen();
    const next=template.querySelector('.tr26-tab-panel');if(next)target.innerHTML=next.innerHTML;
    document.querySelectorAll('.tr26-tabs [data-tr26-tab]').forEach(button=>{
      const active=button.dataset.tr26Tab===tab;button.classList.toggle('active',active);
      button.setAttribute('aria-current',active?'page':'false');
    });
  });
  document.addEventListener('change',event=>{if(event.target.matches?.('[data-tr26-season]')){selectedSeasonId=event.target.value;render();}});
  // The original application rerenders after every save/edit/delete. The awards view is
  // calculated on demand, so no extra listeners or persisted analytical state are needed.
  window.MatchbookTrophyRoomV3726={screen,version:'37.28',selectSeason(id){selectedSeasonId=String(id)}};
})();
