/* Matchbook V37.19 — manual global honours, dark Museum Vault, league leaders in Seasons. */
(function(){
 'use strict';
 const esc19=x=>typeof esc==='function'?esc(String(x??'')):String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const globalAwards=[{id:'ballon_dor',name:"Ballon d'Or",subtitle:'Global individual honour'},{id:'fifa_the_best',name:'FIFA The Best',subtitle:'World football award'},
 {id:'kopa_trophy',name:'Kopa Trophy',subtitle:'Under-21 individual award'},
 {id:'european_golden_shoe',name:'European Golden Shoe',subtitle:'League goals only'},
 {id:'ucl_player_of_season',name:'UCL Player of the Season',subtitle:'Champions League performances'},
 {id:'playmaker_of_year',name:'Playmaker of the Year',subtitle:'Assist and key-pass creation'}];
 const leaderKeys=[['topScorer','LaLiga Top Scorer'],['topAssister','LaLiga Top Assister']];
 const getSeason=id=>(db.seasons||[]).find(x=>String(x.id)===String(id));
 const player=()=>typeof playerProfile==='function'?playerProfile()||{}:{};
 const seasonLabel=s=>s.year||s.name||'Season';
 function trophyArt(isGold){return `<svg viewBox="0 0 140 170" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${isGold?'Gold':'Silver'} three-dimensional cup silhouette"><defs><linearGradient id="cup-metal-${isGold?'g':'s'}" x1="0" y1="0" x2="1" y2=".4"><stop stop-color="${isGold?'#6a4314':'#54636c'}"/><stop offset=".24" stop-color="${isGold?'#ffdb75':'#e9f1fa'}"/><stop offset=".5" stop-color="${isGold?'#ba822b':'#8095a7'}"/><stop offset=".72" stop-color="${isGold?'#fff0af':'#fff'}"/><stop offset="1" stop-color="${isGold?'#8a541b':'#647383'}"/></linearGradient><linearGradient id="cup-base-${isGold?'g':'s'}" x1="0" y1="0" x2="0" y2="1"><stop stop-color="${isGold?'#ffe4a0':'#f5faff'}"/><stop offset="1" stop-color="${isGold?'#5f3913':'#3b4c5d'}"/></linearGradient><filter id="cup-shadow-${isGold?'g':'s'}"><feGaussianBlur stdDeviation="3"/></filter></defs><ellipse cx="70" cy="155" rx="43" ry="7" fill="${isGold?'#c59445':'#8da0b1'}" opacity=".3" filter="url(#cup-shadow-${isGold?'g':'s'})"/><path d="M43 38C14 29 14 83 51 86M97 38C126 29 126 83 89 86" stroke="url(#cup-metal-${isGold?'g':'s'})" stroke-width="10" fill="none"/><path d="M33 28H107L97 88Q86 106 70 109Q54 106 43 88Z" fill="url(#cup-metal-${isGold?'g':'s'})" stroke="${isGold?'#ffd78a':'#c8d9e7'}" stroke-width="1.2"/><ellipse cx="70" cy="28" rx="37" ry="6" fill="${isGold?'#ffe8a6':'#ecf7ff'}"/><path d="M63 107h14v22H63z" fill="url(#cup-metal-${isGold?'g':'s'})"/><path d="M50 129h40v11H50zM42 140h56v14H42z" fill="url(#cup-base-${isGold?'g':'s'})"/><path d="M45 42L56 87" stroke="#fff" stroke-width="3" opacity=".25"/></svg>`}
 function getTrophies(){const out=[],seen=new Set();const add=(season,name,type='individual',rank='gold')=>{const key=season.id+'|'+type+'|'+name;if(seen.has(key))return;seen.add(key);out.push({season:seasonLabel(season),name,type,rank})};
  for(const season of db.seasons||[]){
   for(const c of season.competitions||[])if(String(c.status||'').toLowerCase()==='won')add(season,c.name||'Competition', 'team', /league cup|super cup|domestic|league$|puchar ligi/i.test(c.type||c.competitionType||'')?'silver':'gold');
   const r=season.awardsV3717;if(!r?.closed)continue;
   for(const t of r.trophies||[])add(season,t.name,'team',/league cup|super cup|domestic|league$/i.test(t.type||'')?'silver':'gold');
   for(const a of r.manualAwards||[])if(!['top_scorer','assist_leader'].includes(a.type)&&!(a.type==='european_golden_shoe'&&r.global?.european_golden_shoe?.status))add(season,a.label+(a.competition?' · '+a.competition:''),'individual','gold');
   for(const def of globalAwards)if(r.global?.[def.id]?.status==='Won')add(season,def.name,'global','gold');
   if(r.global?.fifpro_world_xi?.status==='Won')add(season,'FIFPro World XI (historical)', 'global','gold');
  }
  return out.reverse();
 }
 function vault(){const cups=getTrophies();return `<section class="aw19-vault" aria-label="Museum Vault"><header class="aw19-section-header"><div><small>THE PRIVATE COLLECTION</small><h2>Museum Vault</h2><p>Only trophies and awards recorded as won are displayed. No invented honours.</p></div><strong>${cups.length} UNLOCKED</strong></header>${cups.length?`<div class="aw19-cases">${cups.map(c=>`<article class="aw19-case ${c.rank==='gold'?'gold':'silver'}"><div class="aw19-case-glass"><div class="aw19-spotlight"></div><div class="aw19-trophy">${trophyArt(c.rank==='gold')}</div><div class="aw19-plinth"></div></div><div class="aw19-case-label"><small>${esc19(c.season)} · ${esc19(c.type.toUpperCase())}</small><h3>${esc19(c.name)}</h3></div></article>`).join('')}</div>`:`<div class="aw19-empty-vault"><div class="aw19-locked">♜</div><b>The vault is empty</b><p>Confirm a cup victory in Seasons or select Won for a global nomination to unlock its trophy.</p></div>`}</section>`}
 function awardCards(){const cards=[];for(const s of (db.seasons||[]).slice().reverse()){
  const r=s.awardsV3717;if(!r?.closed)continue;
  for(const def of globalAwards){const g=r.global?.[def.id];if(!g?.status)continue;cards.push({season:s,def,g})}
 }
 const p=player(),name=p.name||'Career player',age=typeof profileAge==='function'?profileAge(p):p.age;
 return `<section class="aw19-nominations"><header class="aw19-section-header"><div><small>GLOBAL CEREMONIES</small><h2>Individual Awards</h2><p>Nominations follow the career calendar. Results use the Matchbook model, with a manual override after the gala.</p></div></header>${cards.length?`<div class="aw19-nomination-grid">${cards.map(({season,def,g})=>{const pending=g.stage==='pending'||g.stage==='awaiting_decision',status=g.status==='Won'?'Won':g.status==='Lost'?'Lost':g.status==='Nominated'?'Nominated':'In Contention';return `<article class="aw19-nomination-card ${pending&&status==='Nominated'?'is-pending':''} ${status==='Won'?'is-won':''}"><div class="aw19-nom-top"><small>${esc19(seasonLabel(season))}</small><span class="aw19-award-status">${esc19(status)}</span></div><div class="aw19-nom-player"><svg viewBox="0 0 94 116" aria-hidden="true"><defs><linearGradient id="aw19-silhouette" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#ab95d6"/><stop offset="1" stop-color="#30294c"/></linearGradient></defs><circle cx="47" cy="31" r="19" fill="url(#aw19-silhouette)"/><path d="M12 111Q13 65 47 62Q81 65 82 111" fill="url(#aw19-silhouette)"/></svg><div><span class="aw19-flag">🇪🇸 <span>SPAIN</span></span><h3>${esc19(name)}</h3><p>${age==null?'Age not recorded':esc19(age)+' years old'}</p></div></div><div class="aw19-nom-name"><small>${esc19(def.subtitle)}</small><strong>${esc19(def.name)}</strong></div><div class="aw19-decision"><span>OFFICIAL RESULT</span><div><button type="button" data-aw19-decide="Won" data-aw19-season="${esc19(season.id)}" data-aw19-award="${def.id}" aria-pressed="${String(g.status==='Won')}">WON</button><button type="button" data-aw19-decide="Lost" data-aw19-season="${esc19(season.id)}" data-aw19-award="${def.id}" aria-pressed="${String(g.status==='Lost')}">LOST</button></div></div>${pending?'<small class="aw19-pending-label">NOMINATION ACTIVE · AWAITING MANUAL RESULT</small>':''}</article>`}).join('')}</div>`:`<div class="aw19-empty-nom">No recorded global nominations yet. Complete and review a season; nominations will appear once eligible.</div>`}</section>`;
 }
 function awardRoom(){const p=player();return `<div class="aw19-room"><div class="aw19-hero"><div><span>MATCHBOOK · HONOURS & AWARDS</span><h1>The Trophy Room</h1><p>${esc19(p.name||'Player')} · official results and lifetime collection</p></div><div class="aw19-hero-icon">✦</div></div>${awardCards()}${vault()}</div>`}
 function seasonLeadersPanel(s){const leaders=s.leagueHonoursV3719||{};return `<section class="aw19-league-leaders"><div><small>SEASON-ONLY RECORDS · MANUAL</small><h3>LaLiga leaders</h3><p>Enter the real winners for this season. These names do not automatically grant an individual trophy.</p></div><div class="aw19-league-fields">${leaderKeys.map(([id,label])=>`<label><span>${esc19(label)}</span><input type="text" data-aw19-leader="${id}" data-aw19-season="${esc19(s.id)}" value="${esc19(leaders[id]||'')}" placeholder="Player name (manual)" autocomplete="off"></label>`).join('')}</div><span class="aw19-leader-status" aria-live="polite"></span></section>`}
 const oldManagement=typeof managementView==='function'?managementView:null;
 if(oldManagement)managementView=function(){return page==='Awards'?awardRoom():oldManagement()};
 const oldRender=typeof render==='function'?render:null;
 if(oldRender)render=function(){const value=oldRender();const nav=document.querySelector('#nav');if(nav&&!nav.querySelector('[data-page="Awards"]')){
  const button=document.createElement('button');button.type='button';button.dataset.page='Awards';button.className=page==='Awards'?'active':'';button.setAttribute('aria-current',page==='Awards'?'page':'false');button.innerHTML='<span class="aw19-nav-symbol" aria-hidden="true">♛</span><span>Awards</span>';
  const seasons=nav.querySelector('[data-page="Seasons"]');if(seasons)seasons.after(button);else nav.append(button);
 }
 if(page==='Seasons')document.querySelectorAll('.season-card').forEach((card,i)=>{const s=db.seasons[i];if(!s)return;const section=document.createElement('div');section.innerHTML=seasonLeadersPanel(s);(card.querySelector('.awards-season-control')||null)?.before(section.firstElementChild);if(section.firstElementChild)card.append(section.firstElementChild)});
 return value;
 };
 window.matchbookHonoursVaultMarkup=vault;
 function saveDecision(node){const s=getSeason(node.dataset.aw19Season),id=node.dataset.aw19Award,decision=node.dataset.aw19Decide,g=s?.awardsV3717?.global?.[id];if(!g||!['Won','Lost'].includes(decision))return;
  const autoModel=window.MatchbookAwardsV3722,assessment=s?.awardsV3717?.awardsEngineV3722?.[id];
  if(autoModel&&assessment&&autoModel.careerDate(db)<assessment.ceremonyDate){if(typeof toast==='function')toast('Global award voting is locked until the career reaches the gala date.');return;}
  if(g.status===decision)return;
  if(typeof createRestorePoint==='function'&&!createRestorePoint('Before manual global award decision'))return;
  const original=structuredClone(g),notifications=structuredClone(db.awardNotificationsV3717||[]);
  g.status=decision;g.stage='resolved';g.manuallyDecided=true;g.decidedAt=`Manual result · ${new Date().toISOString().slice(0,10)}`;
  const notifId=`${s.id}:${id}`;db.awardNotificationsV3717=(db.awardNotificationsV3717||[]).filter(n=>n.id!==notifId);
  if(decision==='Won')db.awardNotificationsV3717.push({id:notifId,sourceSeasonId:s.id,seasonId:g.decidedInSeasonId||s.id,awardId:id,sourceYear:seasonLabel(s),dismissed:false});
  if(!save()){Object.assign(g,original);db.awardNotificationsV3717=notifications;return}render();if(typeof toast==='function')toast(`${decision==='Won'?'Award won':'Award not won'} · saved manually`);
 }
 document.addEventListener('click',e=>{const node=e.target.closest?.('[data-aw19-decide]');if(node){e.preventDefault();saveDecision(node)}});
 document.addEventListener('change',e=>{const el=e.target.closest?.('[data-aw19-leader]');if(!el)return;const s=getSeason(el.dataset.aw19Season);if(!s)return;const key=el.dataset.aw19Leader;if(!leaderKeys.some(([id])=>id===key))return;
  const value=String(el.value||'').trim().slice(0,130),before=structuredClone(s.leagueHonoursV3719||{});if(String(before[key]||'')===value)return;
  if(typeof createRestorePoint==='function'&&!createRestorePoint('Before changing LaLiga season leaders'))return;
  s.leagueHonoursV3719={...before,[key]:value};if(!save()){s.leagueHonoursV3719=before;return}
  const msg=el.closest('.aw19-league-leaders')?.querySelector('.aw19-leader-status');if(msg)msg.textContent='Saved';
 });
 window.matchbookAwardsV3719={getTrophies,awardRoom,seasonLeadersPanel,vault};
 if(oldRender)render();
})();
