'use strict';
(()=>{
 const key='fesedyo-career-v1',raw={},problems=[],items=[];
 const status=document.getElementById('status'),list=document.getElementById('records'),button=document.getElementById('export');
 function download(value,name){const url=URL.createObjectURL(new Blob([typeof value==='string'?value:JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
 function add(label,value){items.push({label,value});const card=document.createElement('article'),title=document.createElement('strong'),info=document.createElement('small'),get=document.createElement('button');title.textContent=label;let data;try{data=typeof value==='string'?JSON.parse(value):value}catch{}info.textContent=data?.profile?`${data.profile.name||"Unnamed"} · ${Array.isArray(data.matches)?data.matches.length:'?'} matches · ${Array.isArray(data.seasons)?data.seasons.length:'?'} seasons${data.draft?" · match in progress":''}`:"Cannot recognise career — download the original data for review.";get.textContent="Download this JSON save";const n=items.length;get.onclick=()=>download(value,`matchbook-odzyskiwanie-${n}.json`);card.append(title,info,get);list.append(card)}
 for(const k of [key,key+'-restore',key+'-unreadable',key+'-last-good']){try{const value=localStorage.getItem(k);if(value!==null)raw[k]=value}catch(e){problems.push("Browser storage unavailable: "+e.message)}}
 if(raw[key])add("Main save",raw[key]);
 if(raw[key+'-unreadable'])add("Protected previous save",raw[key+'-unreadable']);
 if(raw[key+'-last-good']){try{add("Automatic copy of last valid save",JSON.parse(raw[key+'-last-good']).data)}catch{problems.push("The automatic copy needs review in the recovery package.")}}
 if(raw[key+'-restore']){try{const points=JSON.parse(raw[key+'-restore']);if(!Array.isArray(points))throw Error("Invalid list");points.forEach((p,i)=>{if(p?.data)add(`Point ${i+1} · ${p.label||"Copy"} · ${p.at||"no date"}`,p.data)})}catch{problems.push("Cannot read restore points. Their original is in the recovery package.")}}
 button.disabled=false;button.onclick=()=>download({format:'matchbook-rescue-v1',createdAt:new Date().toISOString(),origin:location.origin,storage:raw,problems},'matchbook-pakiet-ratunkowy.json');
 status.textContent=items.length?`Found ${items.length} saves or snapshots. Download the package and check which copy contains your player and matches.`:"No Matchbook saves found in this browser at this address. Other browsers, profiles and devices have not been checked.";if(problems.length)status.textContent+=' '+problems.join(' ');
})();
