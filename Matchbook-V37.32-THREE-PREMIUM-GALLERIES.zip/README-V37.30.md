# Matchbook V37.30 — Big Match evidence and Trophy Room V3

Based on V37.29. This is a production build of the original Matchbook project, not a disconnected prototype.

## Changes
- Read-only Big Match classification uses the actual opponent's saved home/away side, stable IDs when available, exact club aliases, competition stages and recorded high-stakes tags. Reserve/B/academy sides are not mistaken for the first team.
- Historical ranking provenance is explicit. The built-in source is **a verified top-ten subset** of Opta Power Rankings as reported by Statista on **17 March 2025**. It is applied to the **2024/25 season as a clearly labelled retrospective baseline**, not as an exact ranking on every match date. It is **not an official worldwide top-25 dataset**. Other seasons without ranking snapshots still qualify through recorded knockout stages, difficulty and high-stakes tags; the system does not infer a ranking.
- Awards and Statistics call the same classifier and season context. Existing career records are never mutated during derived reclassification.
- The Awards Evidence panel exposes rank source and date where this source was used.
- Trophy Room V3 has a large featured outlook, spacious responsive award races, six expandable evidence-based performance dimensions, separate confirmed trophies and competition progress, and official saved award results/ceremonies. If nobody is eligible for a featured award, a neutral progress message appears rather than an invented favourite.
- Existing award outcomes, snapshots, manual WON/LOST controls, history, Match Maker and xG are preserved.

## Notes on testing
See Matchbook-V37.30-QA.md distributed alongside the ZIP.
Run `node --test tests/*.test.cjs` in a developer source copy, excluding the obsolete v3714-action-creator.test.cjs referencing a removed JS file.

## Before deployment
Back up your full career JSON. Deploy to a Vercel preview environment, load your real career, confirm Barcelona/Real Madrid fixtures and saved official awards, then validate cloud sync and recovery before production.
