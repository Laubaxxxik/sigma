/* Matchbook V37.25 — Match History / Maker
   A presentation layer on top of the existing liveBoard/event engine.
   No parallel persistence, event IDs, statistics or invented shot coordinates. */
(function(){
'use strict';
const shotTypes = new Set(['Goal','Penalty goal','Shot','Shot on target','Shot off target','Blocked shot','Post','Crossbar','Big chance missed','Penalty missed']);
const escText=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=s=>document.querySelector(s);
const field=(form,name)=>form?.elements?.namedItem(name);
const state=()=>typeof db!=='undefined'?db.draft:null;
const isShot=type=>shotTypes.has(type);
function scoreCard(d){
  if(!d)return '';
  const result=typeof liveScore==='function'?liveScore(d):[0,0];
  const clk=typeof scoreboardClock==='function'?scoreboardClock(d):{text:'—',label:'Current minute'};
  const crest=name=>{try{return typeof clubBadge==='function'?clubBadge(name,'large'):''}catch{return ''}};
  const teams=[{name:d.home,side:'home',score:result[0]},{name:d.away,side:'away',score:result[1]}];
  const all=typeof effectiveActions==='function'?effectiveActions(d.actions||[]):d.actions||[];
  const goals=side=>all.filter(e=>typeof isScoringEvent==='function'&&isScoringEvent(e)&&e.side===side)
    .map(e=>`<span class="mh-scorer">${escText(e.player||'Unknown scorer')}${e.type==='Own goal'?' (OG)':(e.type==='Penalty goal'||e.shot?.penalty)?' (P)':''} ${escText(e.minute)}${Number(e.added)>0?'+'+escText(e.added):''}′</span>`).join('');
  const comp=typeof competitionDisplayName==='function'?competitionDisplayName(d):d.competition||'Match';
  const matchStatus=d.shootout?'PENALTIES':d.currentPhase==='et'||d.extraTime?'EXTRA TIME':d.halftime&&Number(clk.text?.replace(/[^0-9].*/,''))===45?'HT':'LIVE';
  return `<section class="mh-scoreboard" aria-label="Match score">
    <div class="mh-score-meta"><span>${escText(comp)}${d.competitionDetail?' · '+escText(d.competitionDetail):''}</span><span class="mh-status">${matchStatus}</span></div>
    <div class="mh-score-row"><div class="mh-team mh-team-home">${crest(d.home)}<strong>${escText(d.home)}</strong></div>
    <div class="mh-score-main"><b>${result[0]}<i>:</i>${result[1]}</b><span>${escText(clk.text||'—')}</span></div>
    <div class="mh-team mh-team-away">${crest(d.away)}<strong>${escText(d.away)}</strong></div></div>
    <div class="mh-scorers"><div>${goals('home')}</div><div>${goals('away')}</div></div>
  </section>`;
}
function makeStructure(root){
  if(!root||root.classList.contains('mh-ready'))return;
  root.classList.add('mh-ready');
  const modal=$('#modal');modal?.classList.add('mh-mode');
  const bar=root.closest('.live-main')?.querySelector('.ac19-global-bar');
  if(bar){const brand=bar.querySelector('.ac19-brand');if(brand)brand.innerHTML='<span class="mh-brand-main">MATCHBOOK</span><span class="mh-brand-sub"> / MATCH HISTORY · MAKER</span>';bar.querySelector('.ac19-scoreline')?.remove();}
  const left=root.querySelector('.ac19-left'),right=root.querySelector('.ac19-right'),builder=root.querySelector('.ac19-builder');
  if(!left||!right||!builder)return;
  left.querySelector('.ac19-radar-host')?.remove();
  const head=left.querySelector('.ac19-heading');if(head)head.innerHTML='<span>01 / MATCH HISTORY</span><strong>Match overview</strong><small>Scoreline and recorded moments</small>';
  const scoreboard=document.createElement('div');scoreboard.className='mh-score-host';head?.after(scoreboard);
  const timeline=left.querySelector('.ac19-timeline-heading');if(timeline){timeline.querySelector('b').textContent='MATCH EVENTS';}
  const righthead=right.querySelector('.ac19-right-heading');if(righthead){const small=righthead.querySelector('small'),title=righthead.querySelector('h2');if(small)small.textContent='02 / MATCH MAKER';if(title)title.textContent='Create an action';}
  const heading=document.createElement('div');heading.className='mh-form-heading';heading.innerHTML='<div><span class="mh-eyebrow">STEP 01 / EVENT</span><h3>What happened?</h3><p>Choose a moment, then add its details.</p></div><button type="button" id="mh-new-action" title="Clear edit state and create a new action">＋ New action</button>';
  builder.prepend(heading);
  const fields=builder.querySelector('.ac19-main-fields');if(fields)fields.classList.add('mh-quick-fields');
  const stage=document.createElement('div');stage.className='mh-stage';stage.innerHTML=`<section class="mh-stage-left"><div class="mh-visual-heading"><span class="mh-eyebrow">LIVE PREVIEW</span><h3 class="mh-viz-title">Action summary</h3></div><div class="mh-nonshot-preview"><div class="mh-preview-icon">↗</div><div class="mh-preview-type">Select an event</div><div class="mh-preview-player">Choose player and team</div><div class="mh-preview-pills"></div><div class="mh-preview-note">The preview reflects only information you enter. No locations are estimated.</div></div><div class="mh-shot-visual" hidden><div class="mh-shot-placeholder">Select a shot to plot its origin and finish.</div></div></section><section class="mh-stage-right"><div class="mh-settings-heading"><span class="mh-eyebrow">STEP 02 / DETAILS</span><h3>Action details</h3></div><div class="mh-fields-content"></div></section>`;
  const controls=builder.querySelector('.ac19-controls');controls?.before(stage);
  if(controls)stage.querySelector('.mh-fields-content').append(controls);
  const people=builder.querySelector('.ac19-participant');if(people)stage.querySelector('.mh-fields-content').prepend(people);
  if(controls){const watch=new MutationObserver(()=>{try{updatePreview(root)}catch(err){console.warn('[MH] preview update',err)}});watch.observe(controls,{subtree:true,childList:true});}
  const advanced=builder.querySelector('.ac19-more');if(advanced)stage.querySelector('.mh-fields-content').append(advanced);
  const actionRow=builder.querySelector(':scope > .actions');if(actionRow)actionRow.classList.add('mh-save-row');
  const stats=root.querySelector('.match-stats-fold');if(stats){left.append(stats);stats.open=false;}
  root.addEventListener('click',e=>{if(e.target.closest('#mh-new-action')){
    const form=$('#form');const cancel=form?.querySelector('#cancel-edit');if(cancel&&!cancel.hidden){cancel.click();updateSoon();return;}
    const type=field(form,'type');if(type){type.value='Goal';type.dispatchEvent(new Event('change',{bubbles:true}));}
    for(const key of ['player','assist','incoming','detail']){const input=field(form,key);if(input)input.value='';}
    form?.querySelectorAll('[data-ac19-select]').forEach(btn=>btn.setAttribute('aria-pressed','false'));
    updateSoon();
  }});
  root.querySelectorAll('.event-card').forEach(card=>card.setAttribute('tabindex','0'));
  // Original event editing is handled by the existing liveBoard bindings. The new
  // key handler invokes the same Edit button instead of introducing another path.
  left.addEventListener('keydown',e=>{const card=e.target.closest('.event-card');if(card&&(e.key==='Enter'||e.key===' ')){if(e.target.matches('button'))return;e.preventDefault();card.querySelector('[data-event-edit]')?.click();}});
}
function updateScore(root){const box=root.querySelector('.mh-score-host');if(box){box.innerHTML=scoreCard(state());}}
function syncPicker(root){
 const form=$('#form');if(!form)return;
 const type=field(form,'type')?.value||'';
 const shot=isShot(type);
 const stage=root.querySelector('.mh-stage');if(!stage)return;
 stage.classList.toggle('mh-is-shot',shot);stage.classList.toggle('mh-is-nonshot',!shot);
 const stageLeft=root.querySelector('.mh-stage-left');
 const visual=root.querySelector('.mh-shot-visual');if(!visual)return;
 visual.hidden=!shot;
 root.querySelector('.mh-nonshot-preview').hidden=shot;
 const title=root.querySelector('.mh-viz-title');if(title)title.textContent=shot?'Shot placement':'Action summary';
 // The original picker is moved, not cloned: a single set of coordinate fields
 // remains in the form and keeps the core data serializer authoritative.
 if(!shot){visual.querySelector('.location-input')?.remove();return;}
 let picker=form.querySelector('#event-extra .location-input');
 if(picker){visual.querySelector('.location-input')?.remove();visual.innerHTML='';visual.append(picker);picker.open=true;picker.querySelectorAll('details').forEach(d=>d.open=true);}
 else if(!visual.querySelector('.location-input')&&typeof locationPicker==='function'){
   // Rare older action types render without the tracking details. Populate from
   // the original event or blank form; never infer missing coordinates.
   const idx=Number(form.dataset.editIndex??-1);const source=Number.isInteger(idx)&&idx>=0?state()?.actions?.[idx]:null;
   visual.innerHTML=locationPicker(source||{},'',type);
   const fallback=visual.querySelector('.location-input');if(fallback){fallback.open=true;}
 }
 const details=visual.querySelector('.location-input');if(details){details.open=true;}
 if(typeof syncLocationFields==='function'){try{syncLocationFields(visual)}catch(err){console.warn('[MH] picker sync',err)}}
}
function updatePreview(root){
 const form=$('#form');if(!form)return;
 const type=field(form,'type')?.value||'Action';const player=field(form,'player')?.value||'Player not selected';
 const side=field(form,'side')?.value||'';const team=side?state()?.[side]||'Team not selected':'Team not selected';
 const minute=field(form,'minute')?.value||'—';const added=Number(field(form,'added')?.value||0);
 const extra=added>0?'+'+added:'';
 const result=root.querySelector('.ac19-controls [name="ac19-result"]')?.value||'';
 const prep=root.querySelector('.ac19-controls [name="ac19-preparation"]')?.value||'';
 const context=root.querySelector('.ac19-controls [name="ac19-context"]')?.value||'';
 const words={underPressure:'Under pressure',oneOnOne:'One on one',throughBall:'Through ball',firstTime:'First-time',cutback:'Cutback',lofted:'Lofted pass',bodyContact:'Body contact'};
 const preview=root.querySelector('.mh-nonshot-preview');if(preview){
   const label=preview.querySelector('.mh-preview-type');if(label)label.textContent=type;
   const who=preview.querySelector('.mh-preview-player');if(who)who.textContent=`${player} · ${team} · ${minute}${extra}′`;
   const tags=[result,prep,context].filter(Boolean).filter(t=>t!=='normal'&&t!=='recorded').map(t=>words[t]||t.replace(/([A-Z])/g,' $1').replace(/^./,m=>m.toUpperCase()));
   preview.querySelector('.mh-preview-pills').innerHTML=tags.length?tags.map(t=>`<span>${escText(t)}</span>`).join(''):'<span>Details appear as you select them</span>';
 }
 const edit=Number(form.dataset.editIndex??-1)>=0;
 const badge=root.querySelector('.ac19-edit-label');if(badge){badge.textContent=edit?'EDITING SAVED EVENT':'NEW ACTION';badge.classList.toggle('mh-editing',edit);}
 const primary=form.querySelector('#add-event');if(primary){primary.textContent=edit?'Save changes':'＋ Add to match';}
 const cancel=form.querySelector('#cancel-edit');if(cancel)cancel.hidden=!edit;
 const heading=root.querySelector('.mh-form-heading h3');if(heading)heading.textContent=edit?'Edit existing event':'What happened?';
 const more=root.querySelector('.ac19-more');if(more)more.textContent=isShot(type)?'Advanced shot attributes · xG and linked players':'Advanced details · player links and notes';
 // For simple actions don't render pointless "not applicable" cards.
 root.querySelectorAll('.ac19-block').forEach(block=>block.classList.toggle('mh-empty-block',!!block.querySelector('.ac19-empty-option')&&!block.querySelector('.ac19-pill')));
 root.querySelectorAll('.event-card').forEach(card=>{
   card.classList.toggle('mh-selected-event',edit&&!!card.querySelector(`[data-event-edit="${Number(form.dataset.editIndex)}"]`));
 });
}
function refresh(){
 const root=$('#modal .ac19-shell');if(!root)return;
 makeStructure(root);if(!root.classList.contains('mh-ready'))return;
 $('#modal')?.classList.add('mh-mode');
 updateScore(root);syncPicker(root);updatePreview(root);
 const count=root.querySelector('.ac19-timeline-heading span');if(count)count.textContent=`${state()?.actions?.length||0} recorded`;
}
let scheduled=false;
function updateSoon(){if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;try{refresh()}catch(err){console.error('[MH] refresh',err)}})}
// Core liveBoard is still the single source of truth for score, feed, event editor
// and event-save callbacks. Refresh the new presentation only after its render.
const existing=typeof liveBoard==='function'?liveBoard:null;
if(existing){liveBoard=function(...args){const ret=existing(...args);queueMicrotask(refresh);return ret;}}
document.addEventListener('change',e=>{if(e.target.closest?.('#modal.mh-mode'))updateSoon();});
document.addEventListener('input',e=>{if(e.target.closest?.('#modal.mh-mode'))updateSoon();});
document.addEventListener('click',e=>{
 if(e.target.closest?.('#modal.mh-mode [data-ac19-select],#modal.mh-mode [data-event-edit],#modal.mh-mode #cancel-edit,#modal.mh-mode [data-quick],#modal.mh-mode #insert-player'))updateSoon();
});
// Remove old shot picker before the native type change handler replaces event-extra.
// This avoids ghost location inputs or carried-over shot coordinates.
document.addEventListener('change',e=>{if(e.target.matches?.('#modal.mh-mode [name="type"]')){
 const visual=$('#modal .mh-shot-visual');visual?.querySelector('.location-input')?.remove();
}},true);
// Other dialogs are protected by CSS requiring BOTH mh-mode and ac19-mode.
$('#modal')?.addEventListener('close',()=>{const m=$('#modal');if(!m?.open || !m.querySelector('.ac19-shell'))m?.classList.remove('mh-mode');});
window.MatchHistoryMaker={refresh,isShot,scoreCard};
if($('#modal .ac19-shell'))updateSoon();
})();
