/* Matchbook Cloud Sync — Supabase account sync.
   Local storage is the instant source of truth on this device; cloud sync runs automatically after each verified local save. */
const MATCHBOOK_CLOUD_CONFIG={
  url:'https://zxwopllupkdsybafwaxe.supabase.co',
  publishableKey:'sb_publishable_1zB38tMKHMZ_InCgE2BMCw_QX8ob1Tg'
};
const MATCHBOOK_CLOUD_META_KEY='matchbook-cloud-v1';
const MATCHBOOK_CLOUD_CAREER_ID='primary';
const CLOUD_SAVE_DELAY=450;
const CLOUD_POLL_INTERVAL=15000;
const CLOUD_RETRY_MAX=30000;
const cloudRuntime={
  client:null,session:null,sdkReady:false,loading:false,syncing:false,reconciling:false,suspend:false,
  timer:null,retryTimer:null,pollTimer:null,retryCount:0,dirty:false,pendingReconcile:false,
  status:'Cloud offline',error:'',panelOpen:false,lastCheckAt:0
};
let cloudMeta=loadCloudMeta();

function cloudMetaDefaults(){return {pairedUserId:'',lastCloudUpdatedAt:'',lastSyncedHash:'',lastLocalChangeAt:'',lastSuccessfulSyncAt:'',conflict:false,autoSync:true}}
function loadCloudMeta(){
  try{return {...cloudMetaDefaults(),...JSON.parse(localStorage.getItem(MATCHBOOK_CLOUD_META_KEY)||'{}')}}catch{return cloudMetaDefaults()}
}
function saveCloudMeta(){try{localStorage.setItem(MATCHBOOK_CLOUD_META_KEY,JSON.stringify(cloudMeta))}catch{}}
function cloudHash(value){
  const text=JSON.stringify(value??null);let h=2166136261;
  for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}
  return (h>>>0).toString(16).padStart(8,'0')+':'+text.length;
}
function cloudMeaningfulCareer(value){return !!(value&&(value.matches?.length||value.seasons?.length||(value.profile?.name&&value.profile.name!=='My player')))}
function cloudEscape(value){return typeof esc==='function'?esc(value):String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function cloudDate(value){if(!value)return 'Never';try{return new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'})}catch{return String(value)}}
function cloudIsTransientError(error){const msg=String(error?.message||error||'');return navigator.onLine===false||/failed to fetch|network|fetch failed|load failed|timeout|timed out|connection|offline/i.test(msg)}
function cloudSetStatus(text,error=''){cloudRuntime.status=text;cloudRuntime.error=error||'';updateCloudStatus()}
function cloudPaired(){const user=cloudRuntime.session?.user;return !!user&&cloudMeta.pairedUserId===user.id}
function updateCloudStatus(){
  const footer=document.querySelector('#cloud-state');
  const button=document.querySelector('#cloud-account');
  const signed=cloudRuntime.session?.user;
  const paired=cloudPaired();
  const label=cloudRuntime.error?'Cloud issue':cloudRuntime.syncing||cloudRuntime.reconciling?'Syncing…':cloudRuntime.dirty&&paired?'Cloud pending…':paired?(cloudRuntime.status||'Cloud saved'):(signed?'Cloud · connect':'Cloud · sign in');
  if(footer){
    const text=cloudRuntime.error?cloudRuntime.error:(paired?(cloudRuntime.dirty&&!cloudRuntime.syncing?'Cloud pending · '+cloudRuntime.status:cloudRuntime.status):'Cloud not connected');
    footer.textContent=' · '+text;footer.classList.toggle('save-error',!!cloudRuntime.error)
  }
  if(button){button.textContent=label;button.dataset.state=cloudRuntime.error?'error':paired?'paired':signed?'signed':'offline';button.title=signed?('Signed in as '+signed.email):'Sign in to sync this career across devices'}
  if(cloudRuntime.panelOpen&&document.querySelector('#cloud-panel')&&!cloudRuntime.syncing&&!cloudRuntime.reconciling)refreshCloudPanel().catch(()=>{});
}
function mountCloudUi(){
  const header=document.querySelector('main>header');
  if(header&&!document.querySelector('#cloud-account')){
    const b=document.createElement('button');b.type='button';b.id='cloud-account';b.textContent='Cloud · loading';b.onclick=openCloudPanel;header.append(b);
  }
  const saveState=document.querySelector('#save-state');
  if(saveState&&!document.querySelector('#cloud-state')){const span=document.createElement('span');span.id='cloud-state';saveState.after(span)}
  updateCloudStatus();
}
function loadSupabaseSdk(){
  if(window.supabase?.createClient)return Promise.resolve(window.supabase);
  if(cloudRuntime.sdkPromise)return cloudRuntime.sdkPromise;
  // Failed downloads must be removable so reconnecting can actually retry.
  document.querySelector('script[data-matchbook-supabase]')?.remove();
  cloudRuntime.sdkPromise=new Promise((resolve,reject)=>{
    const script=document.createElement('script');
    const timeout=setTimeout(()=>fail('Cloud library timed out. Local saves still work. Try again when connected.'),15000);
    function cleanup(){clearTimeout(timeout);script.onload=null;script.onerror=null}
    function fail(message){cleanup();script.remove();reject(Error(message))}
    script.src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
    script.async=true;script.dataset.matchbookSupabase='1';
    script.onload=()=>{if(!window.supabase?.createClient)return fail('Supabase library loaded without createClient.');cleanup();resolve(window.supabase)};
    script.onerror=()=>fail('Cloud library could not be downloaded. Local saves still work.');
    document.head.append(script);
  }).finally(()=>{cloudRuntime.sdkPromise=null});
  return cloudRuntime.sdkPromise;
}

async function cloudInitClient(){
  if(cloudRuntime.client)return cloudRuntime.client;
  if(cloudRuntime.loading){while(cloudRuntime.loading)await new Promise(r=>setTimeout(r,40));if(!cloudRuntime.client)throw Error('Cloud client is not available.');return cloudRuntime.client}
  cloudRuntime.loading=true;
  try{
    const sdk=await loadSupabaseSdk();
    const client=sdk.createClient(MATCHBOOK_CLOUD_CONFIG.url,MATCHBOOK_CLOUD_CONFIG.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    cloudRuntime.sdkReady=true;
    const {data,error}=await client.auth.getSession();if(error){client.auth.stopAutoRefresh?.();throw error}cloudRuntime.client=client;
    cloudRuntime.session=data.session||null;
    cloudRuntime.client.auth.onAuthStateChange((event,session)=>{
      cloudRuntime.session=session||null;
      if(!session){cloudRuntime.dirty=false;cloudSetStatus('Cloud signed out');stopCloudPolling();return}
      cloudSetStatus('Cloud connected');startCloudPolling();
      if(cloudMeta.pairedUserId===session.user.id)setTimeout(()=>requestCloudReconcile('auth'),0);
      else updateCloudStatus();
    });
    return cloudRuntime.client;
  }finally{cloudRuntime.loading=false}
}
function cloudRowSummary(data,updatedAt,label){
  const matches=Array.isArray(data?.matches)?data.matches.length:0,seasons=Array.isArray(data?.seasons)?data.seasons.length:0,name=data?.profile?.name||'Career';
  return `<article class="cloud-copy"><small>${cloudEscape(label)}</small><strong>${cloudEscape(name)}</strong><span>${matches} matches · ${seasons} season${seasons===1?'':'s'}</span><span>${updatedAt?('Updated '+cloudEscape(cloudDate(updatedAt))):'On this device'}</span></article>`;
}
async function cloudFetchRow(){
  const client=await cloudInitClient(),user=cloudRuntime.session?.user;if(!user)return null;
  const {data,error}=await client.from('career_saves').select('user_id,career_id,career_name,save_data,schema_version,updated_at').eq('user_id',user.id).eq('career_id',MATCHBOOK_CLOUD_CAREER_ID).maybeSingle();
  if(error)throw error;return data||null;
}
function cloudMarkSynced(hash,updatedAt,status='Cloud saved'){
  const user=cloudRuntime.session?.user;if(!user)return;
  cloudMeta.pairedUserId=user.id;cloudMeta.lastSyncedHash=hash;cloudMeta.lastCloudUpdatedAt=updatedAt||cloudMeta.lastCloudUpdatedAt||'';cloudMeta.lastSuccessfulSyncAt=new Date().toISOString();cloudMeta.conflict=false;saveCloudMeta();
  cloudRuntime.retryCount=0;clearTimeout(cloudRuntime.retryTimer);cloudRuntime.retryTimer=null;
  cloudRuntime.dirty=cloudHash(db)!==hash;cloudSetStatus(status);
}
function cloudScheduleRetry(){
  if(!cloudPaired()||cloudMeta.conflict||storageState?.blocked||storageState?.conflict)return;
  clearTimeout(cloudRuntime.retryTimer);
  const delay=Math.min(CLOUD_RETRY_MAX,1200*Math.pow(2,Math.min(cloudRuntime.retryCount,5)));cloudRuntime.retryCount++;
  cloudRuntime.retryTimer=setTimeout(()=>{cloudRuntime.retryTimer=null;cloudDrainQueue();},delay);
}
function cloudTransientFailure(error){
  cloudRuntime.dirty=cloudHash(db)!==cloudMeta.lastSyncedHash;
  cloudSetStatus(navigator.onLine===false?'Cloud offline · local save safe':'Cloud retrying…');
  cloudScheduleRetry();
  return false;
}
function cloudSetConflict(message='Cloud and this device both changed. Open Cloud to choose which copy to keep.'){
  cloudMeta.conflict=true;saveCloudMeta();cloudRuntime.dirty=true;cloudSetStatus('Cloud conflict',message);return false;
}
function cloudPrepareRemote(row){
  if(!row?.save_data)throw Error('No cloud career was found.');
  const prepared=typeof prepareCareerForLoad==='function'?prepareCareerForLoad(row.save_data):structuredClone(row.save_data),errors=typeof careerErrors==='function'?careerErrors(prepared):[];
  if(errors.length)throw Error('Cloud career failed validation: '+errors[0]);return prepared;
}
function cloudWriteRemoteLocally(prepared){
  if(storageState?.blocked)throw Error('Local save recovery is required before cloud data can be loaded.');
  if(storageState?.conflict)throw Error('Another tab changed the local save. Refresh before cloud sync.');
  if(cloudMeaningfulCareer(db)&&!createRestorePoint('Before automatic cloud sync'))throw Error(storageState.error||'Could not create a local restore point.');
  const before=db,beforeSeason=season;
  cloudRuntime.suspend=true;
  try{
    db=ensureCareerShape(structuredClone(prepared));storageState.blocked=false;storageState.conflict=false;storageState.lastRaw=localStorage.getItem(KEY);storageState.allowReplacement=true;
    const persisted=save();storageState.allowReplacement=false;
    if(!persisted)throw Error(storageState.error||'Could not write cloud career to this device.');
    if(!db.seasons.some(s=>s.id===season))season=db.seasons[0]?.id||'';
    render();return true;
  }catch(error){db=before;season=beforeSeason;storageState.allowReplacement=false;throw error}
  finally{cloudRuntime.suspend=false}
}
async function cloudApplyRemoteRow(row,{status='Cloud synced'}={}){
  const prepared=cloudPrepareRemote(row);cloudWriteRemoteLocally(prepared);
  const hash=cloudHash(db);cloudMarkSynced(hash,row.updated_at||'',status);cloudRuntime.dirty=false;return true;
}
async function cloudUpload({force=false,quiet=false}={}){
  if(cloudRuntime.suspend||storageState?.blocked||storageState?.conflict)return false;
  if(cloudRuntime.syncing||cloudRuntime.reconciling){cloudRuntime.dirty=true;return false}
  const client=await cloudInitClient(),user=cloudRuntime.session?.user;if(!user){cloudRuntime.dirty=true;if(!quiet)openCloudPanel();return false}
  if(cloudMeta.pairedUserId&&cloudMeta.pairedUserId!==user.id)return false;
  const snapshot=structuredClone(db),localHash=cloudHash(snapshot),errors=typeof careerErrors==='function'?careerErrors(snapshot):[];
  if(errors.length){cloudSetStatus('Cloud save blocked','Local career failed validation: '+errors[0]);return false}
  cloudRuntime.syncing=true;clearTimeout(cloudRuntime.timer);cloudRuntime.timer=null;cloudSetStatus('Syncing…');
  try{
    const existing=await cloudFetchRow();
    if(existing){
      const remoteHash=cloudHash(existing.save_data),base=cloudMeta.lastSyncedHash;
      if(remoteHash===localHash){cloudMarkSynced(localHash,existing.updated_at||'','Cloud up to date');return true}
      if(!force){
        if(base&&remoteHash===base){/* cloud has not changed since last sync: local upload is safe */}
        else if(base&&localHash===base){await cloudApplyRemoteRow(existing,{status:'Cloud updated this device'});return true}
        else if(!base&&!cloudMeaningfulCareer(snapshot)){await cloudApplyRemoteRow(existing,{status:'Cloud loaded'});return true}
        else return cloudSetConflict();
      }
    }
    const updatedAt=new Date().toISOString();
    const row={user_id:user.id,career_id:MATCHBOOK_CLOUD_CAREER_ID,career_name:snapshot.profile?.name||'Career',save_data:snapshot,schema_version:Number(snapshot.schemaVersion)||Number(snapshot.version)||1,updated_at:updatedAt};
    const {error}=await client.from('career_saves').upsert(row,{onConflict:'user_id,career_id'});if(error)throw error;
    cloudMeta.pairedUserId=user.id;cloudMarkSynced(localHash,updatedAt,'Cloud saved · '+new Date(updatedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}));
    if(cloudHash(db)!==localHash){cloudRuntime.dirty=true;setTimeout(()=>cloudDrainQueue(),80)}
    return true;
  }catch(error){
    if(cloudIsTransientError(error))return cloudTransientFailure(error);
    cloudRuntime.dirty=cloudHash(db)!==cloudMeta.lastSyncedHash;cloudSetStatus('Cloud save failed',error?.message||String(error));if(!quiet)toast('Cloud save failed. Local save is safe.');return false;
  }finally{
    cloudRuntime.syncing=false;updateCloudStatus();
    if(cloudRuntime.pendingReconcile){cloudRuntime.pendingReconcile=false;setTimeout(()=>requestCloudReconcile('queued'),0)}
    else if(cloudRuntime.dirty&&!cloudMeta.conflict&&!cloudRuntime.retryTimer)setTimeout(()=>cloudDrainQueue(),120);
  }
}
async function cloudDownload(row=null,{quiet=false}={}){
  if(cloudRuntime.syncing||cloudRuntime.reconciling)return false;
  cloudRuntime.syncing=true;cloudSetStatus('Loading cloud…');
  try{
    row=row||await cloudFetchRow();await cloudApplyRemoteRow(row,{status:'Cloud loaded'});return true;
  }catch(error){
    if(cloudIsTransientError(error))return cloudTransientFailure(error);
    cloudSetStatus('Cloud load failed',error?.message||String(error));if(!quiet)toast('Cloud career was not loaded. Local data was kept.');return false;
  }finally{cloudRuntime.syncing=false;updateCloudStatus()}
}
function scheduleCloudSave(){
  if(cloudRuntime.suspend||storageState?.blocked||storageState?.conflict)return;
  const hash=cloudHash(db);if(hash===cloudMeta.lastSyncedHash){cloudRuntime.dirty=false;return}
  cloudRuntime.dirty=true;cloudMeta.lastLocalChangeAt=new Date().toISOString();saveCloudMeta();
  if(!cloudPaired())return;
  cloudSetStatus(navigator.onLine===false?'Cloud offline · local save safe':'Cloud pending…');
  clearTimeout(cloudRuntime.timer);cloudRuntime.timer=setTimeout(()=>{cloudRuntime.timer=null;cloudDrainQueue();},CLOUD_SAVE_DELAY);
}
async function cloudDrainQueue(){
  if(cloudRuntime.suspend||storageState?.blocked||storageState?.conflict||cloudMeta.conflict)return false;
  if(!cloudPaired())return false;
  if(cloudRuntime.syncing||cloudRuntime.reconciling){cloudRuntime.dirty=true;return false}
  const hash=cloudHash(db);if(hash===cloudMeta.lastSyncedHash){cloudRuntime.dirty=false;cloudSetStatus('Cloud up to date');return true}
  cloudRuntime.dirty=true;return cloudUpload({quiet:true});
}
async function cloudStartupReconcile(){return requestCloudReconcile('startup')}
async function requestCloudReconcile(reason='manual'){
  const user=cloudRuntime.session?.user;if(!user||cloudMeta.pairedUserId!==user.id||storageState?.blocked||storageState?.conflict)return false;
  const dialog=document.querySelector('#modal');if(reason!=='manual'&&dialog?.open&&!cloudRuntime.panelOpen){cloudRuntime.pendingReconcile=true;return false}
  if(cloudRuntime.syncing||cloudRuntime.reconciling){cloudRuntime.pendingReconcile=true;return false}
  cloudRuntime.reconciling=true;cloudSetStatus('Syncing…');
  try{
    const row=await cloudFetchRow();cloudRuntime.lastCheckAt=Date.now();
    if(!row){if(cloudMeaningfulCareer(db))return await cloudUploadAfterReconcile({force:true});cloudSetStatus('Cloud ready');return true}
    const localHash=cloudHash(db),remoteHash=cloudHash(row.save_data),base=cloudMeta.lastSyncedHash;
    if(localHash===remoteHash){cloudMarkSynced(localHash,row.updated_at||'','Cloud up to date');return true}
    if(base&&localHash===base&&remoteHash!==base){await cloudApplyRemoteRow(row,{status:'Cloud updated this device'});return true}
    if(base&&remoteHash===base&&localHash!==base){return await cloudUploadAfterReconcile({force:true})}
    if(!base){
      const localMeaningful=cloudMeaningfulCareer(db),remoteMeaningful=cloudMeaningfulCareer(row.save_data);
      if(!localMeaningful&&remoteMeaningful){await cloudApplyRemoteRow(row,{status:'Cloud loaded'});return true}
      if(localMeaningful&&!remoteMeaningful)return await cloudUploadAfterReconcile({force:true});
      const localAt=Date.parse(cloudMeta.lastLocalChangeAt||'')||0,remoteAt=Date.parse(row.updated_at||'')||0;
      if(localAt&&remoteAt&&Math.abs(localAt-remoteAt)>2000){if(localAt>remoteAt)return await cloudUploadAfterReconcile({force:true});await cloudApplyRemoteRow(row,{status:'Cloud updated this device'});return true}
    }
    return cloudSetConflict();
  }catch(error){
    if(cloudIsTransientError(error))return cloudTransientFailure(error);
    cloudSetStatus('Cloud unavailable',error?.message||String(error));return false;
  }finally{
    cloudRuntime.reconciling=false;updateCloudStatus();
    if(cloudRuntime.pendingReconcile){cloudRuntime.pendingReconcile=false;setTimeout(()=>requestCloudReconcile('queued'),80)}
    else if(cloudRuntime.dirty&&!cloudMeta.conflict&&!cloudRuntime.syncing)setTimeout(()=>cloudDrainQueue(),120);
  }
}
async function cloudUploadAfterReconcile(options={}){
  cloudRuntime.reconciling=false;
  try{return await cloudUpload({...options,quiet:true})}
  finally{cloudRuntime.reconciling=true}
}
function startCloudPolling(){
  stopCloudPolling();if(!cloudRuntime.session)return;
  cloudRuntime.pollTimer=setInterval(()=>{if(document.visibilityState==='visible'&&cloudPaired())requestCloudReconcile('poll');},CLOUD_POLL_INTERVAL);
}
function stopCloudPolling(){clearInterval(cloudRuntime.pollTimer);cloudRuntime.pollTimer=null;clearTimeout(cloudRuntime.timer);cloudRuntime.timer=null;clearTimeout(cloudRuntime.retryTimer);cloudRuntime.retryTimer=null}
function cloudFlushNow(){
  if(!cloudPaired()||cloudMeta.conflict||storageState?.blocked||storageState?.conflict)return;
  clearTimeout(cloudRuntime.timer);cloudRuntime.timer=null;
  if(cloudHash(db)!==cloudMeta.lastSyncedHash){cloudRuntime.dirty=true;cloudDrainQueue()}
}
function cloudMessage(text,kind=''){const el=document.querySelector('#cloud-message');if(el){el.textContent=text||'';el.className='cloud-message '+kind}}
async function cloudSignedOutHtml(){return `<div id="cloud-panel" class="cloud-panel"><div class="cloud-hero"><span class="cloud-dot"></span><div><h3>Matchbook Cloud</h3><p>Sign in to use the same career on your phone and computer. Local saving stays enabled.</p></div></div><div class="cloud-auth"><label>Email<input id="cloud-email" type="email" autocomplete="email" inputmode="email" required></label><label>Password<input id="cloud-password" type="password" autocomplete="current-password" minlength="6" required></label><div class="cloud-actions"><button type="button" class="primary" id="cloud-signin">Sign in</button><button type="button" id="cloud-signup">Create account</button></div><p id="cloud-message" class="cloud-message"></p></div><small class="cloud-note">JSON backup remains available as an emergency copy. Your database secret key is never used in this browser.</small></div>`}
async function cloudSignedInHtml(row){
  const user=cloudRuntime.session.user,localHash=cloudHash(db),remoteHash=row?cloudHash(row.save_data):'',same=!!row&&localHash===remoteHash,paired=cloudMeta.pairedUserId===user.id&&!cloudMeta.conflict;
  const stateText=same?'This device and the cloud are identical.':cloudMeta.conflict?'Both copies changed separately. Choose the copy you want to keep.':paired?'Automatic sync is on. Local changes are uploaded after every save; this device also checks for newer cloud changes automatically.':'Choose which career to connect the first time.';
  return `<div id="cloud-panel" class="cloud-panel"><div class="cloud-hero"><span class="cloud-dot ${paired?'online':''}"></span><div><h3>Matchbook Cloud</h3><p>${cloudEscape(user.email||'Signed in')} · ${paired?'Automatic sync on':'Choose which career to connect'}</p></div></div><div class="cloud-copies">${cloudRowSummary(db,'','This device')}${row?cloudRowSummary(row.save_data,row.updated_at,'Cloud'):`<article class="cloud-copy empty"><small>Cloud</small><strong>No career yet</strong><span>Upload this device to create it.</span></article>`}</div><p class="${cloudMeta.conflict?'cloud-warning':same?'cloud-ok':'cloud-help'}">${cloudEscape(stateText)}</p><div class="cloud-actions">${row?'<button type="button" class="primary" id="cloud-load">Load cloud on this device</button>':''}<button type="button" id="cloud-upload">${row?'Upload this device':'Create cloud save'}</button>${paired?'<button type="button" id="cloud-sync">Sync now</button>':''}</div><p id="cloud-message" class="cloud-message"></p><div class="cloud-account-row"><button type="button" id="cloud-signout">Sign out</button></div></div>`;
}
async function refreshCloudPanel(){
  const root=document.querySelector('#form');if(!root||!cloudRuntime.panelOpen)return;
  try{
    await cloudInitClient();const row=cloudRuntime.session?await cloudFetchRow():null;
    root.innerHTML=`<h2>Cloud save</h2>${cloudRuntime.session?await cloudSignedInHtml(row):await cloudSignedOutHtml()}<div class="actions"><button type="button" id="cancel">Close</button></div>`;
    root.querySelector('#cancel').onclick=()=>document.querySelector('#modal').close();
    if(!cloudRuntime.session){
      const creds=()=>({email:root.querySelector('#cloud-email').value.trim(),password:root.querySelector('#cloud-password').value});
      root.querySelector('#cloud-signin').onclick=async()=>{const {email,password}=creds();if(!email||!password)return cloudMessage('Enter email and password.','error');cloudMessage('Signing in…');const {error}=await cloudRuntime.client.auth.signInWithPassword({email,password});if(error)return cloudMessage(error.message,'error');cloudMessage('Signed in.');await refreshCloudPanel()};
      root.querySelector('#cloud-signup').onclick=async()=>{const {email,password}=creds();if(!email||password.length<6)return cloudMessage('Use a valid email and a password of at least 6 characters.','error');cloudMessage('Creating account…');const {data,error}=await cloudRuntime.client.auth.signUp({email,password,options:{emailRedirectTo:location.origin+location.pathname}});if(error)return cloudMessage(error.message,'error');if(data.session){cloudMessage('Account created and signed in.');await refreshCloudPanel()}else cloudMessage('Account created. Check your email to confirm it, then sign in.','ok')};
    }else{
      const upload=root.querySelector('#cloud-upload');if(upload)upload.onclick=async()=>{const hasCloud=!!row;if(hasCloud&&!confirm('Replace the cloud career with the copy on this device?'))return;cloudMeta.pairedUserId=cloudRuntime.session.user.id;cloudMeta.lastCloudUpdatedAt=row?.updated_at||cloudMeta.lastCloudUpdatedAt;cloudMeta.conflict=false;saveCloudMeta();await cloudUpload({force:true});await refreshCloudPanel()};
      const load=root.querySelector('#cloud-load');if(load)load.onclick=async()=>{if(cloudMeaningfulCareer(db)&&!confirm('Load the cloud career on this device? A local restore point will be created first.'))return;cloudMeta.pairedUserId=cloudRuntime.session.user.id;cloudMeta.conflict=false;saveCloudMeta();await cloudDownload(row);await refreshCloudPanel()};
      const sync=root.querySelector('#cloud-sync');if(sync)sync.onclick=async()=>{await requestCloudReconcile('manual');await refreshCloudPanel()};
      root.querySelector('#cloud-signout').onclick=async()=>{stopCloudPolling();await cloudRuntime.client.auth.signOut();cloudRuntime.session=null;cloudRuntime.dirty=false;cloudSetStatus('Cloud signed out');await refreshCloudPanel()};
    }
  }catch(error){root.innerHTML=`<h2>Cloud save</h2><div id="cloud-panel" class="cloud-panel"><p class="cloud-warning">Cloud could not be opened.</p><p>${cloudEscape(error?.message||String(error))}</p><p>Your local career is unchanged and still saves in this browser.</p></div><div class="actions"><button type="button" id="cancel">Close</button></div>`;root.querySelector('#cancel').onclick=()=>document.querySelector('#modal').close()}
}
async function openCloudPanel(){
  const dialog=document.querySelector('#modal'),form=document.querySelector('#form');if(!dialog||!form)return;
  cloudRuntime.panelOpen=true;form.onsubmit=e=>e.preventDefault();form.oninput=null;form.onchange=null;form.onkeydown=null;form.innerHTML='<h2>Cloud save</h2><div id="cloud-panel" class="cloud-panel"><p>Connecting securely…</p></div><div class="actions"><button type="button" id="cancel">Close</button></div>';form.querySelector('#cancel').onclick=()=>dialog.close();if(!dialog.open)dialog.showModal();await refreshCloudPanel();
}
function installCloudSync(){
  mountCloudUi();document.querySelector('#modal')?.addEventListener('close',()=>{cloudRuntime.panelOpen=false;if(cloudRuntime.pendingReconcile){cloudRuntime.pendingReconcile=false;setTimeout(()=>requestCloudReconcile('modal-close'),0)}});
  window.addEventListener('online',()=>{if(cloudPaired()){cloudSetStatus('Back online · syncing…');requestCloudReconcile('online')}});
  window.addEventListener('offline',()=>{if(cloudPaired())cloudSetStatus('Cloud offline · local save safe')});
  window.addEventListener('focus',()=>{if(cloudPaired())requestCloudReconcile('focus')});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){if(cloudPaired())requestCloudReconcile('visible')}else cloudFlushNow()});
  window.addEventListener('pagehide',()=>cloudFlushNow());
  cloudSetStatus('Cloud loading…');
  cloudInitClient().then(()=>{
    mountCloudUi();startCloudPolling();
    if(cloudRuntime.session&&cloudMeta.pairedUserId===cloudRuntime.session.user.id)requestCloudReconcile('startup');
    else cloudSetStatus(cloudRuntime.session?'Cloud · choose a career':'Cloud · sign in');
  }).catch(error=>{if(cloudIsTransientError(error))cloudTransientFailure(error);else cloudSetStatus('Cloud unavailable',error?.message||String(error))});
}
