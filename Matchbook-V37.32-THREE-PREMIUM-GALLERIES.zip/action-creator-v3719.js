/* Matchbook V37.19 — unified Action Creator, built against the original event engine.
 * No parallel match/event store; source event IDs and the existing serializer remain authoritative.
 */
(function () {
  'use strict';
  const SHOTS = new Set(['Goal','Penalty goal','Shot','Shot on target','Shot off target','Blocked shot','Post','Crossbar','Big chance missed','Penalty missed']);
  const PASSES = new Set(['Pass','Inaccurate pass','Cross','Key pass','Assist','Corner','Free kick','Dangerous free kick']);
  const DRIBBLES = new Set(['Successful dribble','Failed dribble','Dribble attempt','Dribble']);
  const DUELS = new Set(['Touch','Ground duel','Aerial duel','Bad touch','Possession lost']);
  const DEFENCE = new Set(['Tackle','Interception','Defensive block','Ball recovery','Clearance','Goal-line intervention','Error leading to goal','Goalkeeper save','Goalkeeper intervention']);
  const DISCIPLINE = new Set(['Foul','Foul won','Yellow card','Second yellow card','Red card','Penalty awarded','Corner won','Offside','VAR','Card']);
  const PROGRESS = new Set(['Substitution','Injury','Position change','Formation change','Action sequence','Other']);
  const E = v => typeof esc === 'function' ? esc(String(v ?? '')) : String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const opt = (value,label=value) => [value,label];
  const s = (...args) => args.find(v=>v!==undefined && v!==null && v!=='') ?? '';
  const buttonGroup=(key,title,options,selected)=>`<div class="ac19-group" data-ac19-group="${E(key)}"><span class="ac19-group-label">${E(title)}</span><div class="ac19-options">${options.map(([v,l])=>`<button type="button" class="ac19-pill" data-ac19-select="${E(key)}" data-ac19-value="${E(v)}" aria-pressed="${String(selected===v)}">${E(l)}</button>`).join('')}</div><input type="hidden" name="ac19-${E(key)}" value="${E(selected)}"></div>`;
  const defs = {
    result: {shoot: ['goal','saved','off','blocked','post','bar'].map((v,i)=>opt(v,['Goal','Saved','Off target','Blocked','Post','Crossbar'][i])),
      pass: [opt('completed','Completed'),opt('inaccurate','Inaccurate'),opt('intercepted','Intercepted'),opt('out','Out')],
      duel:[opt('won','Won'),opt('lost','Lost'),opt('contested','Contested')],
      discipline:[opt('confirmed','Confirmed'),opt('overturned','Overturned after VAR')],
      progress:[opt('recorded','Recorded'),opt('continues','Continues'),opt('subbed','Substitution')]},
    preparation: {
      shoot:[opt('dribble','Dribble'),opt('firstTime','First-time'),opt('throughBall','Through ball'),opt('cross','Cross'),opt('cutback','Cutback')],
      pass:[opt('ground','Ground'),opt('lofted','Lofted'),opt('throughBall','Through ball'),opt('oneTouch','One-touch / Klepka'),opt('outsideFoot','Outside foot / Fałsz')],
      dribble:[opt('wing','Wing'),opt('centralBox','Central / box'),opt('cleanBreak','Clean break'),opt('bodyContact','Body contact')],
      duel:[opt('touch','Touch'),opt('ground','Ground'),opt('aerial','Aerial'),opt('looseBall','Loose ball')],
      defence:[opt('reading','Reading'),opt('sliding','Sliding'),opt('bodyBlock','Body block'),opt('tacticalClearance','Tactical clearance')],
      discipline:[opt('lateTackle','Late tackle'),opt('shirtPull','Shirt pulling'),opt('tactical','Tactical'),opt('dissent','Dissent / Pyskówki'),opt('timeWasting','Time wasting')],
      progress:[opt('normal','Normal'),opt('afterFoul','After foul'),opt('nonContact','Non-contact'),opt('forced','Forced')]},
    context: [opt('normal','Normal'),opt('underPressure','Under Pressure'),opt('intercepted','Intercepted'),opt('contested','Contested'),opt('crowded','Crowded Space'),opt('oneOnOne','One-on-one'),opt('counter','Counterattack'),opt('possession','Possession Play')],
    body:[opt('left','Left foot'),opt('right','Right foot'),opt('head','Head'),opt('chest','Chest'),opt('other','Other')],
    technique:{
      shoot:[opt('normal','Normal'),opt('finesse','Finesse'),opt('power','Power'),opt('outsideFoot','Outside Foot / Fałsz'),opt('volley','Volley')],
      pass:[opt('short','Short'),opt('long','Long'),opt('boxDelivery','Box Delivery'),opt('lineBreaking','Line-breaking'),opt('cutback','Cutback')],
      dribble:[opt('clean','Clean break'),opt('contested','Contested'),opt('lostControl','Lost control')],
      duel:[opt('forced','Forced error'),opt('unforced','Unforced error'),opt('dispossessed','Dispossessed')],
      defence:[opt('reading','Reading'),opt('sliding','Sliding'),opt('header','Header'),opt('standing','Standing'),opt('catch','Clean catch'),opt('parried','Parried wide'),opt('punch','Punched clear'),opt('closeDown','1v1 Close down')],
      discipline:[opt('tactical','Tactical foul'),opt('dissent','Dissent'),opt('timeWasting','Time wasting'),opt('reckless','Reckless / Brutal'),opt('var','VAR')],
      progress:[opt('playsOn','Plays on'),opt('forcedSub','Forced sub'),opt('medical','Hospital / medical care'),opt('role','New role')]}
  };
  function kind(type){return SHOTS.has(type)?'shoot':PASSES.has(type)?'pass':DRIBBLES.has(type)?'dribble':DUELS.has(type)?'duel':DEFENCE.has(type)?'defence':DISCIPLINE.has(type)?'discipline':'progress'}
  const participants={
    'Goal':[['assist','Assister / none']], 'Penalty goal':[['assist','Assister / none']],
    'Own goal':[['opponent','Deflecting opponent'],['instigator','Instigator']],
    'Goal disallowed':[['scorer','Scorer']], 'Blocked shot':[['blocker','Blocking defender']],
    'Shot on target':[['keeper','Goalkeeper']], 'Big chance missed':[['keeper','Goalkeeper']], 'Penalty missed':[['keeper','Goalkeeper']],
    'Dribble':[['opponent','Target defender']], 'Pass':[['receiver','Target player']], 'Inaccurate pass':[['receiver','Target player']], 'Cross':[['receiver','Target player']], 'Key pass':[['receiver','Target player']], 'Assist':[['receiver','Target player']],
    'Successful dribble':[['opponent','Target defender']], 'Failed dribble':[['opponent','Target defender']], 'Dribble attempt':[['opponent','Target defender']],
    'Touch':[['opponent','Target opponent']], 'Ground duel':[['opponent','Target opponent']], 'Aerial duel':[['opponent','Target opponent']],
    'Bad touch':[['opponent','Target opponent']], 'Possession lost':[['opponent','Target opponent']],
    'Tackle':[['opponent','Target opponent']], 'Interception':[['opponent','Target opponent']], 'Defensive block':[['shooter','Attacking player']],
    'Ball recovery':[['opponent','Target opponent']], 'Clearance':[['opponent','Target opponent']], 'Goal-line intervention':[['shooter','Shooter']],
    'Goalkeeper save':[['shooter','Shooter']], 'Goalkeeper intervention':[['shooter','Attacking player']],
    'Foul':[['fouled','Victim']], 'Foul won':[['offender','Offender']],
    'Substitution':[['incoming','Sub in'],['newPosition','New position']], 'Position change':[['newRole','New role']],
    'Corner':[['receiver','Target player']], 'Offside':[['passer','Passer']],
    'Penalty awarded':[['target','Target player / team']], 'Corner won':[['target','Target player / team']],
    'Free kick':[['target','Target player / team']], 'Dangerous free kick':[['target','Target player / team']],
    'VAR':[['target','Target player / team']]
  };
  function defaultResult(type){return ({Goal:'goal','Penalty goal':'goal',Shot:'', 'Shot on target':'saved','Shot off target':'off','Blocked shot':'blocked',Post:'post',Crossbar:'bar','Big chance missed':'off','Penalty missed':'off',Pass:'completed',Cross:'completed','Key pass':'completed',Assist:'completed','Inaccurate pass':'inaccurate','Successful dribble':'won','Failed dribble':'lost',Tackle:'won',Interception:'won','Ball recovery':'won','Possession lost':'lost','Bad touch':'lost','Foul won':'won',Foul:'lost'})[type]||''}
  function getSource(form) {
    const index=Number(form?.dataset.editIndex??-1), e=Number.isInteger(index)&&index>=0?db.draft?.actions?.[index]:null;
    return {e:e||null,index:e?index:-1};
  }
  function sourceValue(e,key,type) {
    const meta=e?.creatorV3719||{};
    if(Object.prototype.hasOwnProperty.call(meta,key))return meta[key];
    const c=e?.interaction||{},shot=e?.shot||{};
    switch(key){
      case 'result':return type==='Dribble'&&['Successful dribble','Failed dribble','Dribble attempt'].includes(e?.type)?s(e?.creatorV3719?.result,({'Successful dribble':'won','Failed dribble':'lost','Dribble attempt':'attempt'})[e.type]):type==='Pass'&&e?.type==='Inaccurate pass'?s(e?.creatorV3719?.result,c.passOutcome,'inaccurate'):type==='Card'?s(({'Yellow card':'yellow','Second yellow card':'secondYellow','Red card':'red'})[e?.type],e?.creatorV3719?.result,'yellow'):s(shot.outcome,c.passOutcome,c.dribbleResult,defaultResult(type));
      case 'body':return s(e?.body,shot.body);
      case 'context':return s(shot.pressure,shot.situation==='counter'?'counter':undefined,c.underPressure?'underPressure':undefined);
      case 'preparation':return s(shot.control,shot.creatorPassType,c.passType);
      case 'technique':return s(shot.technique,c.saveType);
      case 'play':return s(shot.penalty?'penalty':undefined,shot.situation,type.includes('Penalty')?'penalty':'openPlay');
      case 'possession':return c.possessionLost===true?'lost':c.possessionLost===false?'won':'';
      case 'bigChance':return shot.bigChance||type==='Big chance missed'?'yes':'no';
      default:return '';
    }
  }
  // A type-aware five-section dictionary: same compact component grid for every event,
  // but never show unrelated shooting or disciplinary choices.
  const O=(...labels)=>labels.map(label=>opt(label.toLowerCase().replace(/[^a-z0-9]+/g,''),label));
  const notApplicable='<div class="ac19-empty-option">Not applicable to this action</div>';
  const GOAL_ONLY=new Set(['Goal','Penalty goal']);
  const PRESSURE_TYPES=new Set([...SHOTS,...PASSES,...DRIBBLES,...DUELS,...DEFENCE,'Foul','Foul won','Penalty awarded','Offside']);
  function schema(type,e){
    const k=kind(type),get=key=>sourceValue(e,key,type);
    const S=(key,label,options,value=get(key))=>options?.length?buttonGroup(key,label,options,value):notApplicable;
    const shooter=SHOTS.has(type) && !['Own goal','Goal disallowed'].includes(type);
    let result=[],prep=[],context=[],body=[],technique=[],possession=false,play=false,other='';
    const commonShot=[opt('dribble','After dribble'),opt('soloDribble','Recorded solo run'),opt('firstTime','First-time'),opt('throughBall','Through ball'),opt('cross','Cross'),opt('cutback','Cutback')];
    const shotFinish=[opt('normal','Normal'),opt('finesse','Finesse'),opt('power','Power'),opt('outsideFoot','Outside foot / Fałsz'),opt('volley','Volley'),opt('bicycle','Bicycle / overhead kick'),opt('scorpion','Scorpion kick'),opt('rabona','Rabona'),opt('controlled','Exceptional controlled finish')];
    const passPrep=[opt('ground','Ground'),opt('lofted','Lofted'),opt('throughBall','Through ball'),opt('oneTouch','One-touch / Klepka'),opt('outsideFoot','Outside foot / Fałsz')];
    if(GOAL_ONLY.has(type)){
      result=[opt('goal','Goal')];prep=type==='Penalty goal'?[opt('penalty','Penalty kick')]:commonShot;
      body=defs.body;technique=shotFinish;play=type!=='Penalty goal';
      other='';
    }else if(type==='Own goal'){
      result=[opt('ownGoal','Own goal')];prep=[opt('deflection','Deflection'),opt('badBackpass','Bad backpass'),opt('keeperMistake','Keeper mistake')];
      technique=[opt('accidental','Accidental'),opt('underPressure','Under pressure')];
    }else if(type==='Goal disallowed'){
      result=[opt('offside','Offside'),opt('foul','Foul'),opt('handball','Handball'),opt('ballOut','Ball out')];
      technique=[opt('ref','On-pitch referee'),opt('var','VAR decision')];
    }else if(shooter){
      const forced={ 'Shot on target':'saved','Shot off target':'off','Blocked shot':'blocked','Post':'post','Crossbar':'bar'}[type];
      result=forced?[opt(forced,{'saved':'Saved / on target','off':'Off target','blocked':'Blocked','post':'Post','bar':'Crossbar'}[forced])]:
        type==='Penalty missed'?[opt('saved','Saved'),opt('off','Missed'),opt('bar','Woodwork')]:
        type==='Big chance missed'?[opt('off','Wide / over'),opt('saved','Saved'),opt('blocked','Blocked')]:defs.result.shoot;
      prep=['Penalty missed'].includes(type)?[opt('penalty','Penalty kick')]:commonShot;
      body=defs.body;play=!['Penalty missed'].includes(type);
      technique=['Post','Crossbar'].includes(type)?[opt('backInPlay','Back in play'),opt('out','Out of bounds'),opt('inNet','Into the net')]:
        ['Big chance missed','Penalty missed'].includes(type)?[opt('wide','Wide'),opt('over','Over the bar'),opt('saved','Saved'),opt('delay','Decision delay')]:shotFinish;
    }else if(['Pass','Inaccurate pass','Cross','Key pass','Assist','Corner','Free kick','Dangerous free kick'].includes(type)){
      result=type==='Inaccurate pass'?[opt('inaccurate','Inaccurate'),opt('intercepted','Intercepted')]:[opt('completed','Completed'),opt('inaccurate','Inaccurate'),opt('intercepted','Intercepted')];
      prep=passPrep;technique=[opt('short','Short'),opt('long','Long'),opt('boxDelivery','Box delivery'),opt('lineBreaking','Line-breaking'),opt('cutback','Cutback')];
      body=[opt('wide','Wide delivery'),opt('central','Central'),opt('intoBox','Into the box'),opt('outsideBox','Outside the box')];
    }else if(DRIBBLES.has(type)){
      result=type==='Successful dribble'?[opt('won','Successful')]:type==='Failed dribble'?[opt('lost','Failed')]:type==='Dribble'?[opt('won','Successful'),opt('lost','Failed'),opt('attempt','Attempt only')]:[opt('won','Successful'),opt('lost','Failed')];
      prep=[opt('wing','Wing'),opt('centralBox','Central / box')];
      technique=[opt('clean','Clean break'),opt('bodyContact','Contested / body contact'),opt('lostControl','Lost control')];
    }else if(DUELS.has(type)){
      result=type==='Possession lost'?[opt('lost','Lost')]:type==='Bad touch'?[opt('lost','Bad touch'),opt('won','Recovered')]:[opt('won','Won'),opt('lost','Lost'),opt('contested','Contested')];
      prep=type==='Aerial duel'?[opt('aerial','Aerial duel')]:type==='Ground duel'?[opt('ground','Ground duel')]:[opt('touch','First touch'),opt('looseBall','Loose ball'),opt('ground','Ground')];
      technique=[opt('unforced','Unforced error'),opt('forced','Forced error'),opt('dispossessed','Dispossessed')];
      possession=true;
    }else if(DEFENCE.has(type)){
      result=type==='Error leading to goal'?[opt('goal','Led to goal')]:[opt('won','Successful'),opt('lost','Unsuccessful')];
      prep=type==='Goal-line intervention'?[opt('header','Header'),opt('sliding','Sliding'),opt('standing','Standing')]:
        type.startsWith('Goalkeeper')?[opt('catch','Clean catch'),opt('parry','Parried wide'),opt('punch','Punched clear'),opt('closeDown','1v1 close down')]:
        type==='Error leading to goal'?[opt('badPass','Missed pass'),opt('lastMan','Lost possession as last man'),opt('gkBlunder','GK blunder')]:
        [opt('sliding','Sliding'),opt('reading','Reading'),opt('bodyBlock','Body block'),opt('tacticalClearance','Tactical clearance')];
      technique=type==='Goal-line intervention'?[opt('cleared','Cleared danger'),opt('deflected','Deflected')]:
        type.startsWith('Goalkeeper')?[opt('held','Held ball'),opt('out','Out of play'),opt('rebound','Rebound')]:
        [opt('reading','Anticipation'),opt('sliding','Sliding'),opt('bodyBlock','Body block'),opt('tacticalClearance','Tactical clearance')];
      possession=!['Goal-line intervention','Error leading to goal'].includes(type);
    }else if(['Foul','Foul won'].includes(type)){
      result=type==='Foul won'?[opt('won','Foul won')]:[opt('confirmed','Foul committed')];
      prep=[opt('lateTackle','Late tackle'),opt('shirtPull','Shirt pulling'),opt('tactical','Tactical foul')];
      technique=[opt('freeKick','Free kick'),opt('advantage','Advantage played'),opt('penalty','Penalty awarded')];
    }else if(type==='Card'){
      result=[opt('yellow','Yellow card'),opt('secondYellow','Second yellow'),opt('red','Direct red')];
      prep=[opt('tactical','Tactical foul'),opt('dissent','Dissent'),opt('timeWasting','Time wasting'),opt('brutal','Serious foul')];
    }else if(['Yellow card','Second yellow card','Red card'].includes(type)){
      result=[opt(type==='Yellow card'?'yellow':type==='Second yellow card'?'secondYellow':'red',type)];
      prep=[opt('tactical','Tactical foul'),opt('dissent','Dissent / Pyskówki'),opt('timeWasting','Time wasting'),opt('brutal','Serious foul')];
      technique=[opt('onPitch','On-pitch decision'),opt('var','VAR review')];
    }else if(['Penalty awarded','Corner won','Offside','VAR'].includes(type)){
      result=[opt('confirmed','Confirmed'),opt('overturned','Overturned after VAR')];
      prep=type==='VAR'?[opt('goalReview','Goal review'),opt('penaltyReview','Penalty review'),opt('redReview','Red card review')]:[];
      technique=[opt('onPitch','On-pitch decision'),opt('var','VAR decision')];
    }else if(type==='Substitution'){
      result=[opt('recorded','Substitution made')];prep=[opt('regular','Regular'),opt('halfTime','Half-time'),opt('injury','Forced / injury')];
      technique=[opt('tactical','Tactical'),opt('injury','Injury'),opt('fatigue','Fatigue')];
    }else if(type==='Injury'){
      result=[opt('playsOn','Plays on'),opt('forcedSub','Forced sub'),opt('hospital','Hospital / medical attention')];
      prep=[opt('nonContact','Non-contact'),opt('afterFoul','After foul')];
      technique=[opt('minor','Minor'),opt('assessment','Medical assessment'),opt('stoppage','Play stopped')];
    }else if(type==='Position change'){
      result=[opt('recorded','Position changed')];prep=[opt('tactical','Tactical'),opt('cover','Covering position')];
      technique=[opt('permanent','Until substituted'),opt('temporary','Temporary')];
    }else{
      result=[opt('recorded','Recorded')];
      other='Use the dedicated match tactics / sequence editor or write an event note in Advanced details.';
    }
    context=PRESSURE_TYPES.has(type)?defs.context.filter(([v])=>['normal','underPressure','intercepted','contested','crowded','oneOnOne','counter','possession'].includes(v)):[];
    if(['Penalty goal','Penalty missed','Free kick','Dangerous free kick','Corner','Corner won'].includes(type)) context=context.filter(([v])=>!['oneOnOne','counter','possession'].includes(v));
    if(!shooter && !GOAL_ONLY.has(type))context=context.filter(([v])=>v!=='oneOnOne');
    const blocks=[
      ['RESULT',S('result','Outcome',result),possession?S('possession','Possession',[opt('won','Possession won'),opt('lost','Possession lost')]):''],
      ['PREPARATION / TOUCH TYPE',S('preparation','Preparation',prep)],
      ['MATCH CONTEXT',S('context','Match context',context)],
      [shooter||GOAL_ONLY.has(type)?'FINISHING FOOT / BODY':body.length?'TARGET AREA / DIRECTION':'BODY / AREA',S('body','Foot / target area',body)],
      ['FINISH TECHNIQUE / PLAY TYPE',S('technique','Technique',technique),play?S('play','Play type',[opt('openPlay','Open play'),opt('counter','Counterattack'),opt('directFreeKick','Direct free kick'),opt('penalty','Penalty')],get('play')||'openPlay'):'']
    ];
    if(other) blocks[4].push(`<span class="ac19-block-hint">${E(other)}</span>`);
    return blocks.map(([title,...parts],i)=>`<section class="ac19-block" data-ac19-block="${i+1}"><header><b>${String(i+1).padStart(2,'0')}</b><h4>${E(title)}</h4></header><div class="ac19-block-body">${parts.filter(Boolean).join('')}</div></section>`).join('');
  }
  function radarSVG(actions=[],shootout=false){
    const source=actions.filter(a=>a?.location&&Number.isFinite(Number(a.location.x))&&Number.isFinite(Number(a.location.y))).slice(-55);
    return `<svg class="ac19-radar" viewBox="0 0 100 66" role="img" aria-label="Dark tactical radar with stored event coordinates"><defs><pattern id="ac19-grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="#244050" stroke-width=".3"/></pattern></defs><rect width="100" height="66" rx="3" fill="#0a151d"/><rect width="100" height="66" rx="3" fill="url(#ac19-grid)"/><g stroke="#274655" fill="none" stroke-width=".65"><rect x="2" y="2" width="96" height="62"/><path d="M50 2V64 M2 17h16V49H2 M98 17H82V49h16"/><circle cx="50" cy="33" r="9"/><path d="M2 25h7v16H2 M98 25h-7v16h7"/></g>${source.map(a=>`<circle cx="${(2+Number(a.location.x)*.96).toFixed(1)}" cy="${(64-Number(a.location.y)*.62).toFixed(1)}" r="${SHOTS.has(a.type)?1.4:.85}" fill="${SHOTS.has(a.type)?'#ebc86d':'#59dbe9'}" opacity=".83"/>`).join('')}${!source.length?'<text x="50" y="35" text-anchor="middle" fill="#577789" font-size="4">RECORDED POSITIONS APPEAR HERE</text>':''}</svg>`;
  }
  function elementFor(form,name){return form?.elements?.namedItem(name)}
  function setNative(form,name,value){let field=elementFor(form,name);if(!field){field=document.createElement('input');field.type='hidden';field.name=name;field.dataset.ac19Synthetic='yes';const target=form.querySelector('.ac19-controls')||form;target.append(field)}if('value'in field){if(field.tagName==='SELECT' && value && !Array.from(field.options).some(o=>o.value===String(value))){const option=document.createElement('option');option.value=String(value);option.textContent=String(value);field.add(option)}field.value=String(value);return field}return null}
  function synchroniseOption(form,key,value,type){
    const k=kind(type),isShot=k==='shoot',isPass=k==='pass';
    if(key==='result'){
      if(isShot){const valid=['goal','saved','off','blocked','post','bar'].includes(value);if(valid)setNative(form,'outcome',value)}
      else if(isPass)setNative(form,'rel-passOutcome',value);
      else if(k==='dribble')setNative(form,'rel-dribbleResult',value==='lost'?'lost':value==='won'?'won':'');
    }
    if(key==='possession')setNative(form,'rel-possessionLost',value==='lost'?'yes':value==='won'?'no':'');
    if(key==='body'&&isShot)setNative(form,'body',value);
    if(key==='bigChance'&&isShot)setNative(form,'bigChance',value);
    if(key==='play'&&isShot){setNative(form,'situation',value);setNative(form,'penalty',value==='penalty'?'yes':'no');setNative(form,'rel-directFreeKick',value==='directFreeKick'?'yes':'no')}
    if(key==='context'){
      setNative(form,'rel-underPressure',value==='underPressure'?'yes':'no');
      if(isShot && value==='oneOnOne')setNative(form,'ac19-pressure','oneOnOne');
      if(isShot && ['counter','possession'].includes(value))setNative(form,'situation',value==='counter'?'counter':'openPlay');
      if(isPass&&value==='intercepted')setNative(form,'rel-passOutcome','intercepted');
    }
    if(key==='preparation'){
      if(type==='Card'){const reasons={tactical:'foul',dissent:'dissent',timeWasting:'timeWasting',brutal:'foul'};setNative(form,'rel-cardReason',reasons[value]||'')}
      if(isPass){const conversion={ground:'normal',lofted:'longBall',throughBall:'throughBall',oneTouch:'normal',outsideFoot:'other'};setNative(form,'rel-passType',conversion[value]||value)}
      if(isShot){setNative(form,'ac-creatorPassType',value==='throughBall'?'throughBall':value==='cross'?'cross':value==='cutback'?'cutback':'unknown');setNative(form,'ac-control',value==='firstTime'?'firstTime':'afterTouch')}
    }
    if(key==='technique'&&isShot)setNative(form,'ac-technique',value);
  }
  function applyConstraints(form){
    const context=form.querySelector('[name="ac19-context"]'),play=form.querySelector('[name="ac19-play"]'),type=elementFor(form,'type')?.value||'';
    const fixed=['Penalty goal','Penalty missed'].includes(type)||['penalty','directFreeKick'].includes(play?.value);
    form.querySelectorAll('[data-ac19-select="context"]').forEach(b=>{const off=fixed&&['oneOnOne','counter','possession'].includes(b.dataset.ac19Value);b.disabled=off;b.hidden=off});
    if(fixed && ['oneOnOne','counter','possession'].includes(context?.value||'')){context.value='normal';form.querySelectorAll('[data-ac19-select="context"]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.ac19Value==='normal')));synchroniseOption(form,'context','normal',type)}
    if(fixed && ['directFreeKick','penalty'].includes(play?.value||'')){
      const assist=elementFor(form,'assist');if(assist&&type==='Goal'&&['directFreeKick','penalty'].includes(play.value))assist.value='';
    }
  }
  function showDetails(form,open=true){const drawer=form.querySelector('.ac19-details');if(!drawer)return;drawer.classList.toggle('is-open',open);drawer.setAttribute('aria-hidden',String(!open));if(open){const picker=drawer.querySelector('.location-input');if(picker && typeof syncLocationFields==='function')syncLocationFields(drawer)}}
  function configureParticipants(form,type,e){const wrapper=form.querySelector('.ac19-participant');if(!wrapper)return;
    const roles=participants[type]||[];wrapper.innerHTML='';
    roles.forEach(([role,label])=>{
      const name=role==='assist'?'assist':role==='incoming'?'incoming':'ac19-person-'+role;
      const original=elementFor(form,name);
      const value=String(original?.value??e?.creatorV3719?.['person-'+role]??(role==='assist'?e?.assist:role==='incoming'?e?.incoming:e?.participants?.[role])??'');
      const field=document.createElement('label');field.className='ac19-participant-field';field.innerHTML=`<span>${E(label)}</span><input class="ac19-participant-input" value="${E(value)}" placeholder="${role==='assist'?'None / player name':'Name / team'}" autocomplete="off" aria-label="${E(label)}">`;
      wrapper.append(field);field.querySelector('input').addEventListener('input',ev=>setNative(form,name,ev.target.value));
      if(value)setNative(form,name,value);
    });
    // User-driven xG override. Merely opening a shot does not generate xG.
    if(['Big chance missed','Penalty missed'].includes(type)){
      const originalXG=e?.shot?.xgSource==='external'&&Number.isFinite(Number(e.shot.xG))?Number(e.shot.xG):null;
      const current=originalXG!==null?Math.min(.99,Math.max(.01,originalXG)):.2;
      const field=document.createElement('div');field.className='ac19-xg-field';
      field.innerHTML=`<label>Manual xG <output data-ac19-xg-label>${originalXG===null?'unset':current.toFixed(2)}</output></label><input type="range" data-ac19-xg-slider min="0.01" max="0.99" step="0.01" value="${current.toFixed(2)}" aria-label="Manual xG value"><input type="hidden" name="ac19-xg" value="${originalXG===null?'':current.toFixed(2)}">`;
      wrapper.append(field);const slider=field.querySelector('[data-ac19-xg-slider]');slider.addEventListener('input',()=>{const value=Number(slider.value).toFixed(2);field.querySelector('[name="ac19-xg"]').value=value;field.querySelector('[data-ac19-xg-label]').textContent=value});
    }
  }
  function rebuildBlocks(form,force=false){const type=elementFor(form,'type')?.value||'Goal',root=form.querySelector('.ac19-controls');if(!root)return;
    const {e,index}=getSource(form),prevIndex=form.dataset.ac19LoadedIndex??'',prevId=form.dataset.ac19LoadedId??'';
    const identity=`${index}:${e?.id||''}`;
    if(!force&&root.dataset.type===type&&prevIndex===String(index)&&prevId===identity)return;
    const source=e&&(e.type===type||(type==='Card'&&['Yellow card','Second yellow card','Red card'].includes(e.type))||(type==='Dribble'&&['Successful dribble','Failed dribble','Dribble attempt'].includes(e.type))||(type==='Pass'&&e.type==='Inaccurate pass')||(type==='Goal'&&e.type==='Penalty goal')||(type==='Shot off target'&&e.type==='Penalty missed'&&e.shot?.outcome==='off')||(type==='Shot on target'&&e.type==='Penalty missed'&&e.shot?.outcome==='saved'))?e:null;
    form.querySelectorAll('[data-ac19-synthetic]').forEach(n=>n.remove());
    root.innerHTML=schema(type,source);root.dataset.type=type;form.dataset.ac19LoadedIndex=String(index);form.dataset.ac19LoadedId=identity;
    form.dataset.ac19EditMode=String(index>=0);form.dataset.ac19OriginalEventId=e?.id||'';
    const badge=form.querySelector('.ac19-edit-label');if(badge)badge.textContent=index>=0?`EDITING · ${E(e?.minute)}′ · original ID retained`:'NEW ACTION';
    configureParticipants(form,type,source);
    const drawerTitle=form.querySelector('.ac19-details-title');if(drawerTitle)drawerTitle.textContent=SHOTS.has(type)?'Shot location, goal finish and detailed properties':'Advanced event details & relationships';
    const more=form.querySelector('.ac19-more');if(more)more.textContent=SHOTS.has(type)?'↗ Shot map, goal location & advanced details':'↗ Advanced details, players & match notes';
    root.querySelectorAll('[name^="ac19-"]').forEach(input=>synchroniseOption(form,input.name.slice(5),input.value,type));
    applyConstraints(form);
    if(typeof syncLocationFields==='function')syncLocationFields(form);
  }
  function mount(){const form=document.querySelector('#form'),builder=form?.querySelector('.event-builder'),live=form?.querySelector('.live-workspace'),main=form?.querySelector('.live-main');if(!form||!builder||!live||!main)return;
    if(!main.querySelector('.ac19-shell')){
      form.closest('#modal')?.classList.remove('ac19-shootout-mode');form.closest('#modal')?.classList.add('ac19-mode');document.body.classList.add('ac19-viewport-locked');
      const shell=document.createElement('div');shell.className='ac19-shell';shell.innerHTML=`<section class="ac19-left"><div class="ac19-heading"><span>01 / MATCH HISTORY</span><strong>Visual Log <em>&</em> Radar</strong><small>Confirmed actions · select an entry to edit</small></div><div class="ac19-radar-host"></div><div class="ac19-timeline-heading"><b>EVENT TIMELINE</b><span></span></div></section><section class="ac19-right"><div class="ac19-right-heading"><div><small>02 / LIVE WORKSPACE</small><h2>Action Creator</h2></div><span class="ac19-edit-label">NEW ACTION</span></div></section>`;
      const bar=document.createElement('div');bar.className='ac19-global-bar';bar.innerHTML=`<div class="ac19-brand">MATCHBOOK <span> / LIVE</span></div><div class="ac19-global-buttons"><button type="button" data-ac19-global="extra">EXTRA TIME</button><button type="button" data-ac19-global="penalties">PENALTY SHOOTOUT</button></div>`;
      main.prepend(bar);main.append(shell);
      const left=shell.querySelector('.ac19-left'),right=shell.querySelector('.ac19-right');
      const feed=main.querySelector('.event-feed');if(feed)left.append(feed);
      const matchActions=main.querySelector('.match-bottom');if(matchActions){right.append(matchActions);
        const shortened={finish:'Finish match','copy-live':'Copy report',pause:'Save & close','cancel-live-match':'Cancel match'};
        Object.entries(shortened).forEach(([id,label])=>{const btn=matchActions.querySelector('#'+id);if(btn){btn.textContent=label;btn.title=label}});
      }
      const score=main.querySelector('.scoreboard');if(score){
        const line=document.createElement('div');line.className='ac19-scoreline';
        const d=db.draft||{},home=d.home||'Home',away=d.away||'Away';
        const result=score.querySelector('.live-score')?.textContent?.trim()||'0:0';
        const minute=score.querySelector('.match-clock b')?.textContent?.trim()||'';
        line.innerHTML=`<span class="ac19-team">${E(home)}</span><strong>${E(result)}</strong><span class="ac19-team">${E(away)}</span><span class="ac19-time">${E(minute)}</span>`;
        bar.insertBefore(line,bar.querySelector('.ac19-global-buttons'));
        score.remove();
      }
      right.insertBefore(builder,right.querySelector('.match-bottom'));
      builder.classList.add('ac19-builder');
      const compact=document.createElement('div');compact.className='ac19-main-fields';
      const baseFields=builder.querySelector('.fields');if(baseFields){for(const n of ['minute','added','type','side','player']){const field=elementFor(form,n);if(field){const label=field.closest('label');if(label)compact.append(label)}}builder.insertBefore(compact,baseFields);baseFields.classList.add('ac19-base-fields')}
      const actionArea=[...builder.children].find(el=>el.classList?.contains('actions'));const controls=document.createElement('div');controls.className='ac19-controls';if(actionArea)builder.insertBefore(controls,actionArea);else builder.append(controls);
      const person=document.createElement('div');person.className='ac19-participant';controls.before(person);
      const details=document.createElement('div');details.className='ac19-details';details.setAttribute('aria-hidden','true');details.innerHTML=`<div class="ac19-details-top"><strong class="ac19-details-title">Advanced event details</strong><button type="button" data-ac19-close-details>Close ×</button></div>`;if(baseFields){details.append(baseFields);builder.append(details)}
      const more=document.createElement('button');more.className='ac19-more';more.type='button';more.dataset.ac19OpenDetails='advanced';more.textContent='Advanced: locations, links and match notes';if(actionArea)builder.insertBefore(more,actionArea);else builder.append(more);
      const nav=builder.querySelector('.quick-events');if(nav)nav.hidden=true;
      const toolbar=main.querySelector('.live-toolbar');if(toolbar)left.insertBefore(toolbar,left.querySelector('.event-feed'));
      const radar=left.querySelector('.ac19-radar-host');if(radar)radar.innerHTML=radarSVG(db.draft?.actions||[]);
      const count=left.querySelector('.ac19-timeline-heading span');if(count)count.textContent=`${db.draft?.actions?.length||0} recorded`;
      main.querySelectorAll('[data-ac19-global]').forEach(btn=>{const on=btn.dataset.ac19Global==='extra'?(typeof extraTimeActive==='function'&&extraTimeActive(db.draft)):!!db.draft?.shootout;btn.setAttribute('aria-pressed',String(!!on))});
    }
    rebuildBlocks(form);
  }
  function refreshSoon(){queueMicrotask(()=>{try{mount();const form=document.querySelector('#form');if(form?.querySelector('.ac19-controls'))rebuildBlocks(form)}catch(err){console.error('[V37.19] mount',err)}})}
  // Serialize only user-confirmed metadata. The existing shot/interaction engines continue to own statistical meaning.
  const originalEnrich=typeof enrichEvent==='function'?enrichEvent:null;
  if(originalEnrich)enrichEvent=function(event,values){
    const oldId=event.id;
    const restored=originalEnrich(event,values);
    const source=restored||event;
    const raw=Object.fromEntries(Object.entries(values).filter(([name])=>name.startsWith('ac19-')).map(([name,val])=>[name.slice(5),String(val)]));
    if(Object.keys(raw).length){source.creatorV3719=raw;
      if(SHOTS.has(source.type)){
        source.shot??={};
        if(raw.preparation)source.shot.preparation=raw.preparation;
        if(raw.technique)source.shot.technique=raw.technique;
        if(raw.context)source.shot.pressure=raw.context;
        if(raw.play)source.shot.situation=raw.play;
      }
      if(values.type==='Big chance missed' && source.shot)source.shot.bigChance=true;
      if(values.type==='Penalty missed' && source.shot){source.shot.penalty=true;source.shot.situation='penalty'}
      if(raw.xg!==undefined && raw.xg!=='' && ['Big chance missed','Penalty missed'].includes(values.type)){
        const manual=Number(raw.xg);
        if(Number.isFinite(manual)&&manual>=0&&manual<=1){source.shot??={};source.shot.xG=Math.round(manual*100)/100;source.shot.xgSource='external';delete source.shot.xgModelVersion}
      }
      if(raw.possession==='lost'){source.interaction??={};source.interaction.possessionLost=true}
      if(raw.possession==='won'){source.interaction??={};source.interaction.possessionLost=false}
    }
    if(oldId)source.id=oldId;
    if(SHOTS.has(source.type)&&typeof materializeShotXG==='function')materializeShotXG(source);
    return source;
  };
  const originalBoard=typeof liveBoard==='function'?liveBoard:null;
  if(originalBoard)liveBoard=function(){const result=originalBoard();refreshSoon();return result};
  // The original listener performs authoritative edit initialization; refresh after it completes.
  document.addEventListener('click',event=>{
    const action=event.target.closest?.('[data-ac19-select]');if(action){event.preventDefault();const form=action.closest('form');if(!form||action.disabled)return;const key=action.dataset.ac19Select,val=action.dataset.ac19Value;const field=elementFor(form,'ac19-'+key);if(!field)return;
      field.value=val;form.querySelectorAll(`[data-ac19-select="${key}"]`).forEach(b=>b.setAttribute('aria-pressed',String(b===action)));
      synchroniseOption(form,key,val,elementFor(form,'type')?.value||'');
      applyConstraints(form);if(typeof syncLocationFields==='function')syncLocationFields(form);return;
    }
    const more=event.target.closest?.('[data-ac19-open-details]');if(more){event.preventDefault();showDetails(more.closest('form'),true);return}
    const close=event.target.closest?.('[data-ac19-close-details]');if(close){event.preventDefault();showDetails(close.closest('form'),false);return}
    const global=event.target.closest?.('[data-ac19-global]');if(global){event.preventDefault();if(!db.draft)return; if(global.dataset.ac19Global==='extra'){if(typeof beginExtraTime==='function')beginExtraTime();else toast('Extra time controls unavailable');return}if(typeof startShootout==='function')startShootout();return}
    const row=event.target.closest?.('.ac19-left article.event-card');if(row&&!event.target.closest('button,a,input,select')){row.querySelector('[data-event-edit]')?.click();return}
    if(event.target.closest?.('[data-event-edit]'))refreshSoon();
    if(event.target.closest?.('[data-event-delete]'))refreshSoon();
    if(event.target.closest?.('#cancel-edit'))refreshSoon();
  });
  document.addEventListener('change',e=>{
    const form=e.target.closest?.('form');if(!form?.querySelector('.ac19-controls'))return;
    if(e.target.name==='type'){const controls=form.querySelector('.ac19-controls');if(controls)controls.dataset.type='';form.dataset.ac19LoadedId='';refreshSoon()}
    else if(e.target.name==='side'||e.target.name==='player')refreshSoon();
    else if(/(delivery|firstTime|defenderDistanceMeters|keeperPosition|ballHeight|clearSight|dominantFoot|xG)$/.test(e.target.name||'') && typeof syncLocationFields==='function')syncLocationFields(form);
  });
  document.addEventListener('input',e=>{
    const form=e.target.closest?.('form');
    if(form?.querySelector('.ac19-controls')&&/(delivery|firstTime|defenderDistanceMeters|keeperPosition|ballHeight|clearSight|dominantFoot|xG)$/.test(e.target.name||'')&&typeof syncLocationFields==='function')syncLocationFields(form);
  });
  document.addEventListener('click',e=>{if(!e.target.closest?.('#add-event'))return;const form=e.target.closest('form');if(!form?.querySelector('.ac19-controls'))return;
    const i=Number(form.dataset.editIndex??-1),id=form.dataset.ac19OriginalEventId;
    if(i>=0 && (!id || db.draft?.actions?.[i]?.id!==id)){
      e.preventDefault();e.stopImmediatePropagation();toast('Original event changed. Reopen it from the timeline before saving.');
    }
  },true);
  function dressShootout(){const form=document.querySelector('#form'),modal=document.querySelector('#modal');if(!form||!modal)return;
    modal.classList.remove('ac19-mode');modal.classList.add('ac19-shootout-mode');if(form.querySelector('.ac19-shootout-shell'))return;
    const shell=document.createElement('div');shell.className='ac19-shootout-shell';shell.innerHTML=`<section class="ac19-left ac19-shootout-left"><div class="ac19-heading"><span>GLOBAL MATCH STATE</span><strong>PENALTY SHOOTOUT</strong><small>Close-up penalty area radar</small></div><div class="ac19-shootout-radar"><svg viewBox="0 0 100 78" role="img" aria-label="Penalty area radar"><rect width="100" height="78" fill="#0b151d"/><g fill="none" stroke="#376073" stroke-width="1.2"><rect x="6" y="5" width="88" height="68"/><path d="M20 5V39H80V5 M36 5V18H64V5 M42 4v-4h16v4"/><circle cx="50" cy="52" r="2"/><path d="M35 39 Q50 55 65 39"/></g></svg></div><p class="ac19-shootout-caption">The shootout is separate from match goals, xG and player ratings.</p></section><section class="ac19-shootout-right"><div class="ac19-right-heading"><div><small>FAST KICK ENTRY</small><h2>Taker · Target · Result</h2></div></div></section>`;
    const right=shell.querySelector('.ac19-shootout-right');while(form.firstChild)right.append(form.firstChild);form.append(shell);
  }
  const originalModal=typeof modal==='function'?modal:null;
  if(originalModal)modal=function(...args){const answer=originalModal(...args);document.querySelector('#modal')?.classList.remove('ac19-mode','ac19-shootout-mode');document.body.classList.remove('ac19-viewport-locked');return answer};
  document.querySelector('#modal')?.addEventListener('close',()=>document.body.classList.remove('ac19-viewport-locked'));
  const originalOpenShootout=typeof openShootout==='function'?openShootout:null;
  if(originalOpenShootout)openShootout=function(...args){const result=originalOpenShootout(...args);dressShootout();return result};
  const originalKickEditor=typeof openShootoutKickEditor==='function'?openShootoutKickEditor:null;
  if(originalKickEditor)openShootoutKickEditor=function(...args){const result=originalKickEditor(...args);dressShootout();return result};
  const originalStartShootout=typeof startShootout==='function'?startShootout:null;
  if(originalStartShootout)startShootout=function(...args){const result=originalStartShootout(...args);dressShootout();return result};
  // Exposed for isolated browser regression tests.
  window.matchbookActionCreatorV3719={schema,kind,sourceValue,radarSVG,rebuildBlocks,applyConstraints,mount};
  if(document.querySelector('#form .event-builder'))refreshSoon();
})();
