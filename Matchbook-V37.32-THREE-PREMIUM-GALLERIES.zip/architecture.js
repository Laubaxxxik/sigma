/* Matchbook V32 — lightweight extension hooks, derived-data cache and explicit schema migrations. */
const Matchbook=window.Matchbook||(window.Matchbook={});
Matchbook.hooks=Matchbook.hooks||Object.create(null);
function registerHook(name,fn,priority=0){if(typeof fn!=='function')return()=>{};const list=Matchbook.hooks[name]??=[];const row={fn,priority:Number(priority)||0,id:Symbol(name)};list.push(row);list.sort((a,b)=>b.priority-a.priority);return()=>{const i=list.findIndex(x=>x.id===row.id);if(i>=0)list.splice(i,1)}}
function runHooks(name,...args){const out=[];for(const row of [...(Matchbook.hooks[name]||[])]){try{out.push(row.fn(...args))}catch(error){console.error('[Matchbook hook]',name,error)}}return out}
function collectHooks(name,...args){return runHooks(name,...args).flatMap(x=>Array.isArray(x)?x:x==null?[]:[x])}
function firstHook(name,...args){for(const row of [...(Matchbook.hooks[name]||[])]){try{const value=row.fn(...args);if(value!==undefined&&value!==false)return value}catch(error){console.error('[Matchbook hook]',name,error)}}return undefined}
Matchbook.registerHook=registerHook;Matchbook.runHooks=runHooks;Matchbook.collectHooks=collectHooks;Matchbook.firstHook=firstHook;

Matchbook.cache=Matchbook.cache||{revision:0,items:new Map(),invalidate(){this.revision++;this.items.clear()},memo(key,builder){const hit=this.items.get(key);if(hit&&hit.revision===this.revision)return hit.value;const value=builder();this.items.set(key,{revision:this.revision,value});return value}};

const MATCHBOOK_SCHEMA_VERSION=5;
function mbValidPoint(p){return !!p&&Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y))&&Number(p.x)>=0&&Number(p.x)<=100&&Number(p.y)>=0&&Number(p.y)<=100}
function migrateSchema0to1(data){data.availability=Array.isArray(data.availability)?data.availability:[];data.schemaVersion=1;return data}
function migrateSchema1to2(data){
 const rows=[...(Array.isArray(data.matches)?data.matches:[]),...(data.draft?[data.draft]:[])];
 for(const m of rows)for(const e of Array.isArray(m?.actions)?m.actions:[]){
  if(!e||typeof e!=='object')continue;
  // Only migrate an explicitly stored legacy destination. Never invent coordinates.
  const legacy=e.passDestination||e.interaction?.passDestination;
  if(!mbValidPoint(e.pass?.destination)&&mbValidPoint(legacy)){e.pass={...(e.pass||{}),destination:{x:Number(legacy.x),y:Number(legacy.y)}}}
 }
 data.schemaVersion=2;return data
}
function migrateSchema2to3(data){data.availability=Array.isArray(data.availability)?data.availability:[];data.schemaVersion=3;data.schemaMeta={...(data.schemaMeta||{}),name:'Matchbook career',version:3};return data}
function migrateSchema3to4(data){ensureSeasonProfiles(data);data.schemaVersion=4;data.schemaMeta={...(data.schemaMeta||{}),name:'Matchbook career',version:4};return data}
/* V37.15: historical shooting classifications and box-entry routes.
   Schema migration is one-time, deterministic and operates on an in-memory clone.
   The original local backup is preserved by persistCareer() when the migrated save is written. */
function mbStatNum(v){return v!==''&&v!=null&&Number.isFinite(Number(v))?Number(v):null}
function mbShotForV3715(e){return !!e&&['Goal','Penalty goal','Shot','Shot on target','Shot off target','Blocked shot','Post','Crossbar','Big chance missed','Penalty missed'].includes(e.type)}
function mbBlockedEvidence(e){
 if(!mbShotForV3715(e)||['Goal','Penalty goal','Post','Crossbar','Penalty missed'].includes(e.type))return false;
 if(e.type==='Blocked shot')return true;
 const tokens=[e.shot?.outcome,e.shot?.result,e.outcome,e.result,e.shot?.blocked===true?'blocked':'',e.blocked===true?'blocked':''];
 if(tokens.some(t=>/^(blocked|block|blocked shot|zablokowany|zablokowane)$/i.test(String(t||'').trim())))return true;
 const detail=String(e.detail||e.shot?.detail||e.description||'').toLowerCase();
 if(/\b(not blocked|unblocked|wasn.t blocked|niezablokowan|nie zablokowan)\b/.test(detail))return false;
 return /(?:\bblocked (?:shot|attempt|by defender|by [a-z]+)\b|\b(?:shot|attempt) (?:was |got )?blocked\b|\bstrzał(?:em)? zablokowan|\bzablokowan(?:y|e|a) strzał\b)/i.test(detail)
}
function mbPointV3715(p){const x=mbStatNum(p?.x),y=mbStatNum(p?.y);return x!==null&&y!==null&&x>=0&&x<=100&&y>=0&&y<=100?{x,y}:null}
function mbInsideOppositionBox(p){return !!p&&p.x>=84.3&&p.y>=20.4&&p.y<=79.6}
function mbPassCoordinates(e){
 const origin=mbPointV3715(e.location)||mbPointV3715(e.pass?.origin)||mbPointV3715(e.interaction?.origin);
 const to=mbPointV3715(e.interaction?.destination)||mbPointV3715(e.pass?.destination)||mbPointV3715(e.passDestination);
 return origin&&to?{origin,to}:null
}
function mbShotPassCoordinates(e){
 const shooter=mbPointV3715(e.location),passer=mbPointV3715(e.shot?.passerLocation)||mbPointV3715(e.shot?.creatorLocation)||mbPointV3715(e.interaction?.passerLocation);
 return shooter&&passer?{origin:passer,to:shooter}:null
}
function migrateSchema4to5(data){
 const audit={reclassifiedBlocked:0, correctedOffTargetManual:0, recalculatedBoxFlags:0, historicalMatches:0, uncertainShots:0};
 const all=[...(Array.isArray(data.matches)?data.matches:[]),...(data.draft?[data.draft]:[])];
 for(const m of all){
  if(!m||!Array.isArray(m.actions))continue;
  let convertedOff=0,convertedToBlocked=0;
  for(const e of m.actions){
   if(!e||typeof e!=='object')continue;
   if(mbShotForV3715(e)&&mbBlockedEvidence(e)){
    const wasBlocked=e.type==='Blocked shot'&&String(e.shot?.outcome||'blocked')==='blocked';
    if(!wasBlocked){
     e.shot=(e.shot&&typeof e.shot==='object'&&!Array.isArray(e.shot))?e.shot:{};
     if(e.type==='Shot off target')convertedOff++;
     if(e.type!=='Blocked shot')convertedToBlocked++;
     e.shot.outcome='blocked';e.type='Blocked shot';audit.reclassifiedBlocked++;
    }
   }
   let points=null;
   if(['Pass','Key pass','Cross','Assist','Inaccurate pass'].includes(e.type))points=mbPassCoordinates(e);
   else if(mbShotForV3715(e))points=mbShotPassCoordinates(e);
   if(points){
    const value=!mbInsideOppositionBox(points.origin)&&mbInsideOppositionBox(points.to);
    e.interaction=(e.interaction&&typeof e.interaction==='object')?e.interaction:{};
    if(e.interaction.passesIntoOppositionBox!==value||e.interaction.passes_into_opposition_box!==value)audit.recalculatedBoxFlags++;
    e.interaction.passesIntoOppositionBox=value;
    e.interaction.passes_into_opposition_box=value;
   }
  }
  // Manual summaries can include off-target attempts that were mislabelled in the log.
  // Only subtract explicitly reclassified OFF-target events; never infer missing totals.
  if(convertedOff>0&&m.manualStats&&typeof m.manualStats==='object'){
   const old=mbStatNum(m.manualStats.offTarget);
   if(old!==null&&old>=convertedOff){m.manualStats.offTarget=old-convertedOff;audit.correctedOffTargetManual+=convertedOff;
    const prior=mbStatNum(m.manualStats.blocked);if(prior!==null)m.manualStats.blocked=prior+convertedOff;
   }
  }
  if(convertedToBlocked)audit.historicalMatches++;
 }
 data.schemaVersion=5;
 data.schemaMeta={...(data.schemaMeta||{}),name:'Matchbook career',version:5};
 data.analyticsMigrationV3715={version:1,summary:audit,method:'event-evidence-only',accuracy:'onTarget / (shots - blocked)'};
 return data
}
const MATCHBOOK_MIGRATIONS={0:migrateSchema0to1,1:migrateSchema1to2,2:migrateSchema2to3,3:migrateSchema3to4,4:migrateSchema4to5};
function runMatchbookMigrations(source){
 const data=structuredClone(source||{}),from=Number.isInteger(Number(data.schemaVersion))?Number(data.schemaVersion):0,applied=[];
 if(from>MATCHBOOK_SCHEMA_VERSION)throw Error(`This career uses newer schema ${from}; this build supports ${MATCHBOOK_SCHEMA_VERSION}.`);
 let version=from;
 while(version<MATCHBOOK_SCHEMA_VERSION){const migration=MATCHBOOK_MIGRATIONS[version];if(typeof migration!=='function')throw Error(`Missing schema migration ${version} → ${version+1}.`);migration(data);applied.push(`${version}→${version+1}`);version=Number(data.schemaVersion)}
 return {data,changed:applied.length>0,from,to:version,applied}
}
Matchbook.schemaVersion=MATCHBOOK_SCHEMA_VERSION;Matchbook.runMigrations=runMatchbookMigrations;
