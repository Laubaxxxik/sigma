/* Matchbook V37.24.1 — weighted awards: strict snapshot isolation and deterministic ranks.
 * Simulation model, NOT official Ballon d'Or voting or verified rival statistics.
 * Keeps archived season reviews immutable apart from delayed award decisions.
 */
(function (root) {
'use strict';
const EVENTS = Object.freeze({
  ballon_dor: {name:"Ballon d'Or", month:10, day:28, noticeDays:5, minWinScore:255},
  fifa_the_best: {name:'FIFA The Best',month:1,day:18,noticeDays:5,minWinScore:270},
  kopa_trophy: {name:'Kopa Trophy',month:10,day:28,noticeDays:5},
  european_golden_shoe: {name:'European Golden Shoe',month:10,day:28,noticeDays:5},
  ucl_player_of_season: {name:'UCL Player of the Season',month:10,day:28,noticeDays:5},
  playmaker_of_year: {name:'Playmaker of the Year',month:10,day:28,noticeDays:5}
});
// Number() || 0 is unsafe: it silently accepts Infinity and turns invalid ratings into 0.
const finite = value => {
 if(value===null||value===undefined||typeof value==='boolean')return null;
 const raw=typeof value==='string'?value.trim().replace(',', '.'):value;
 if(raw==='')return null;
 const n=Number(raw);return Number.isFinite(n)?n:null;
};
const positive = v => Math.max(0,finite(v)??0);
const round = n => Number.isFinite(n)?Math.round((n+Number.EPSILON)*10)/10:0;
const cleanRating = value => {const n=finite(value);return n!==null&&n>=1&&n<=10?n:null;};
const safeCopy = value => JSON.parse(JSON.stringify(value));
const iso = v => {const s=String(v||'').slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return '';const d=new Date(s+'T00:00:00.000Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===s?s:''};
const normalize = s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').toLowerCase();
const escText = s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function yearOfSeason(season,matches=[]){
 const label=String(season?.awardsV3717?.seasonSnapshot?.seasonLabel||season?.awardsV3717?.year||season?.year||'');
 const pair=label.match(/(20\d{2})\s*[\/\-–]\s*(\d{2,4})/);
 if(pair){const start=Number(pair[1]),end=Number(pair[2]);return end<100?Math.floor(start/100)*100+end:end;}
 const dated=matches.filter(m=>m?.season===season?.id).map(m=>iso(m.date)).filter(Boolean).sort();
 if(dated.length){const latest=dated.at(-1),y=Number(latest.slice(0,4));return Number(latest.slice(5,7))>=7?y+1:y;}
 const single=label.match(/(?:19|20)\d{2}/);return single?Number(single[0]):null;
}
function dateFor(year,award){if(!Number.isInteger(year)||year<2000||year>2099)return '';const yy=award==='fifa_the_best'?year+1:year;const c=EVENTS[award];return c?`${yy}-${String(c.month).padStart(2,'0')}-${String(c.day).padStart(2,'0')}`:'';}
function noticeDate(gala,days){const d=new Date(gala+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-days);return d.toISOString().slice(0,10)}
function careerDate(data){const candidates=(Array.isArray(data?.matches)?data.matches:[]).filter(m=>m?.count!==false).map(m=>iso(m.date)).filter(Boolean);const manual=iso(data.awardsCareerDateV3722);if(manual)candidates.push(manual);return candidates.sort().at(-1)||'';}
function hasType(t,type){const code=normalize(t?.rankId||t?.type||t?.competitionType||'');const n=normalize(t?.name||'');if(type==='ucl')return /champions league|liga mistrzow|\bucl\b/.test(code+' '+n);if(type==='international')return /world cup|fifa world cup|euro 20|european championship|copa america|afcon|africa cup of nations|asian cup/.test(n);if(type==='league'){
  // 'Champions League' and 'League Cup' are NOT domestic league titles.
  // This previously granted an erroneous +50 league-title bonus to UCL winners.
  if(/champions league|europa league|conference league|league cup|super.?cup|\bucl\b|\buel\b|\buecl\b/.test(code+' '+n))return false;
  return /domestic_league|laliga|la liga|premier league|bundesliga|serie a|ligue 1|ekstraklasa|eredivisie|primeira liga|liga portugal|(?:^| )league(?: |$)|liga /i.test(code+' '+n);
 }if(type==='uel')return /europa league|conference league|\buel\b|\buecl\b/.test(code+' '+n);return false;}
function wonTrophies(r){return (Array.isArray(r?.trophies)?r.trophies:[]).filter(t=>String(t?.status||'won').toLowerCase()==='won');}
function externalInternational(data,season,endYear){
 // Only confirmed trophy evidence; never assume a national team won a tournament.
 return (Array.isArray(data?.internationalMilestones)?data.internationalMilestones:[]).some(m=>/^champ:/.test(String(m.key||''))&&iso(m.date).slice(0,4)===String(endYear)&&/world cup|euro|copa america|afcon|africa cup|asian cup/i.test(String(m.label||'')))||
 (Array.isArray(data?.internationalTournaments)?data.internationalTournaments:[]).some(t=>t?.seasonId===season.id&&String(t.manualTeamStatus||t.status||'').toLowerCase()==='champion'&&hasType(t,'international'));
}
function trophyEvidence(data,s,r,year){
 const snapshot=r?.seasonSnapshot,source=snapshot?{trophies:snapshot.trophies}:r;
 const wins=wonTrophies(source);
 const ucl=wins.some(t=>hasType(t,'ucl'));
 const international=wins.some(t=>hasType(t,'international'))||(snapshot?snapshot.confirmedInternational===true:externalInternational(data,s,year));
 const league=wins.some(t=>hasType(t,'league')),uel=wins.some(t=>hasType(t,'uel'));
 return {ucl,international,league,uel,major:ucl||international,any:wins.length>0||international};
}
// Model coefficients are GAME BALANCE parameters, NOT official Ballon d'Or points.
// League tiers use UEFA association standings as a reference; the multipliers are ours.
const WEIGHTED_MODEL='weighted-2025-uefa-v3-six-awards-verified';
const ASSESSMENT_VERSION=6;
const LEAGUE_RANK_SOURCE='https://www.uefa.com/uefachampionsleague/news/02a0-1f8b9164ba92-1dd42564c706-1000--uefa-rankings-2025-which-teams-and-nations-are-on-top/';
const CLUB_RANK_SOURCE='https://kassiesa.net/uefa/data/method5/trank2025.html';
// UEFA top 25 (2025 final 5-year coefficients); used as a European-proxy list,
// not falsely represented as an official worldwide top 25.
const EUROPEAN_TOP_25_2025=Object.freeze([
 'Real Madrid','Manchester City','Bayern München','Liverpool','Paris Saint-Germain',
 'Internazionale','Chelsea','Borussia Dortmund','AS Roma','FC Barcelona',
 'Manchester United','Arsenal','Bayer Leverkusen','Atlético Madrid','Benfica',
 'Atalanta','Villarreal','FC Porto','AC Milan','RB Leipzig',
 'Lazio','Juventus','Eintracht Frankfurt','Club Brugge','Glasgow Rangers'
]);
const CLUB_ALIASES=Object.freeze({
 'real madrid':['real madrid cf','real madryt'],
 'manchester city':['man city','manchester city fc'],
 'bayern munchen':['bayern munich','fc bayern','bayern'],
 'paris saint germain':['psg','paris sg','paris saint germain fc'],
 'internazionale':['inter','inter milan','inter mediolan'],
 'fc barcelona':['barcelona','barca','fc barca'],
 'atletico madrid':['atleti','atletico de madrid'],
 'fc porto':['porto','fc port'],
 'borussia dortmund':['dortmund','bvb'],
 'bayer leverkusen':['leverkusen'],
 'rb leipzig':['leipzig'],
 'glasgow rangers':['rangers','rangers fc'],
 'club brugge':['club brugge kv','club bruges'],
 'as roma':['roma'],
 'ac milan':['milan'],
 'villarreal':['villarreal cf'],
 'eintracht frankfurt':['eintracht'],
 'manchester united':['man united','man utd'],
 'liverpool':['liverpool fc'],
 'chelsea':['chelsea fc'],
 'arsenal':['arsenal fc'],
 'benfica':['sl benfica','benfica lisbon']
});
const cleanClub=s=>normalize(s).replace(/[^a-z0-9]+/g,' ').trim();
const ELITE_CLUBS=new Set(EUROPEAN_TOP_25_2025.map(cleanClub).flatMap(n=>[n,...(CLUB_ALIASES[n]||[]).map(cleanClub)]));
function eliteOpponent(value){return !!value&&ELITE_CLUBS.has(cleanClub(value));}
function leagueTier(label){const n=normalize(label).replace(/[^a-z0-9]+/g,' ').trim();
 if(!n||['league','domestic league','liga'].includes(n))return {tier:'unknown',multiplier:1,source:'unspecified; neutral assumption'};
 const premier=/(?:^| )premier league(?:$| )/.test(n)&&!/scottish|welsh|indian|northern ireland|irish|russian|ukrainian/.test(n);
 const top5=/(laliga|la liga|primera division|serie a|bundesliga|ligue 1)/.test(n)||premier;
 if(top5)return {tier:'top-5',multiplier:1,source:'UEFA 2025 association top five'};
 if(/eredivisie|primeira liga|liga portugal|portuguese.*league/.test(n))return {tier:'strong',multiplier:.75,source:'UEFA 2025 association ranking: Netherlands/Portugal'};
 if(/champions league|europa league|conference league|world cup|international/.test(n))return {tier:'unknown',multiplier:1,source:'no domestic league identified'};
 return {tier:'other',multiplier:.5,source:'other domestic competition tier'};
}
function leagueForReview(review){
 // After season closure, never fall back to mutable review competitions.
 // An incomplete snapshot must remain incomplete, not silently acquire
 // achievements from a later edit to the same season record.
 const snap=review?.seasonSnapshot;
 const comps=snap ? (Array.isArray(snap.competitions)?snap.competitions:[])
  : (Array.isArray(review?.competitions)?review.competitions:[]);
 const name=(snap ? snap.leagueName : review?.leagueName)||comps.find(c=>hasType(c,'league'))?.name||'';
 return String(name);
}
function positionGroup(value){const codes=normalize(value).toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean);
 if(codes.some(c=>['RW','LW','RM','LM','PP','LP','PS','LS','WINGER'].includes(c)))return 'winger';
 if(codes.some(c=>['ST','CF','FW','NAPASTNIK'].includes(c)))return 'striker';
 if(codes.some(c=>['CAM','AM','CM','CDM','8','10','MIDFIELDER'].includes(c)))return 'midfielder';
 if(codes.some(c=>['GK','GOALKEEPER'].includes(c)))return 'goalkeeper';
 if(codes.some(c=>['CB','RB','LB','DEFENDER'].includes(c)))return 'defender';
 return 'general';
}
function metrics(stats){
 const st=stats&&typeof stats==='object'?stats:{};
 const minutes=finite(st.minutes);
 const bounded=(value,limit)=>{const n=finite(value);return n!==null&&Number.isInteger(n)&&n>=0&&n<=limit?n:0;};
 return {matches:bounded(st.matches,200),goals:bounded(st.goals,200),assists:bounded(st.assists,200),
  keyPasses:bounded(st.keyPasses,1000),rating:cleanRating(st.rating),
  minutes:minutes!==null&&minutes>=0&&minutes<=25000?minutes:null};
}
function ratingBonus(r){if(r===null)return 0;return r>=8.5?90:r>=8?50:r>=7.5?20:0;}
const POSITION_WEIGHTS=Object.freeze({
 winger:{goals:2,assists:2.6,keyPasses:.16},striker:{goals:2.6,assists:1.3,keyPasses:.05},
 midfielder:{goals:2.1,assists:2.1,keyPasses:.14},defender:{goals:2.2,assists:1.9,keyPasses:.12},
 goalkeeper:{goals:2.1,assists:1.8,keyPasses:.04},general:{goals:2.2,assists:1.8,keyPasses:.10}
});
function performance(raw,position='general',leagueMult=1){const m=metrics(raw),weights=POSITION_WEIGHTS[position]||POSITION_WEIGHTS.general;
 const mul=Math.max(.5,Math.min(1,finite(leagueMult)??1));
 const attack=(m.goals*weights.goals+m.assists*weights.assists+Math.min(150,m.keyPasses)*weights.keyPasses)*mul;
 const appearance=Math.min(m.matches,55)*.45;
 const rating=ratingBonus(m.rating);
 return {total:round(attack+appearance+rating),attack:round(attack),appearance:round(appearance),rating,position};
}
const UCL_STAGE_POINTS=Object.freeze({winner:100,final:75,semi:55,quarter:35,round16:15,leaguePhase:5,group:0,unknown:0});
function uclStage(competitions=[],trophies=[]){
 if(trophies.some(t=>hasType(t,'ucl')&&String(t.status||'won').toLowerCase()==='won'))return 'winner';
 const rows=(Array.isArray(competitions)?competitions:[]).filter(t=>hasType(t,'ucl'));
 if(!rows.length)return 'unknown';
 if(rows.some(t=>/^(won|winner|champion)$/i.test(String(t.status||''))))return 'winner';
 const joined=rows.map(t=>normalize([t.finish,t.phaseStatus,t.stage,t.round,t.placement].join(' '))).join(' | ');
 if(/finalist|runner.?up|runners.?up|final (lost|defeat)|przegrany final|final match/.test(joined))return 'final';
 if(/semi.?final|polfinal|1\/2 final/.test(joined))return 'semi';
 if(/quarter.?final|cwiercfinal|1\/4 final/.test(joined))return 'quarter';
 if(/round of 16|last 16|1\/8|r16|16 final/.test(joined))return 'round16';
 if(/league phase|league stage|phase league/.test(joined))return 'leaguePhase';
 if(/group stage|group phase|faza grup/.test(joined))return 'group';
 return 'unknown';
}
function competitionEvidence(review,titles){const comps=review?.seasonSnapshot ? (Array.isArray(review.seasonSnapshot.competitions)?review.seasonSnapshot.competitions:[]) : (Array.isArray(review?.competitions)?review.competitions:[]);
 const trophies=wonTrophies(review?.seasonSnapshot||review);
 const league=leagueTier(leagueForReview(review));
 const domesticCup=trophies.some(t=>/domestic.?cup|copa del rey|copa de espa|fa cup|coppa italia|dfb pokal|coupe de france|taca de portugal|knvb|puchar polski/i.test([t.rankId,t.type,t.name].join(' ')));
 const superCup=trophies.some(t=>/super.?cup|supercopa|community shield|superpuchar/i.test([t.rankId,t.type,t.name].join(' ')));
 const stage=uclStage(comps,trophies);
 const ucl=UCL_STAGE_POINTS[stage];
 const leaguePoints=titles.league?round(50*league.multiplier):0;
 const cupPoints=domesticCup?round(20*league.multiplier):0;
 const superCupPoints=superCup?round(8*league.multiplier):0;
 return {uclStage:stage,uclPoints:ucl,leaguePoints,cupPoints,superCupPoints,domesticCup,superCup,
  leagueName:leagueForReview(review),leagueTier:league.tier,leagueMultiplier:league.multiplier,
  internationalPoints:titles.international?95:0,otherEuropeanPoints:titles.uel?28:0};
}
function bigGameEvidence(value){const g=finite(value?.goals),a=finite(value?.assists);
 return {goals:g!==null&&g>=0&&g<=200?g:0,assists:a!==null&&a>=0&&a<=200?a:0,
 source:value?.source||'not-recorded',rankingYear:value?.rankingYear||2025};
}
function bigGameScore(g,position){const goalBonus=3.5,assistBonus=position==='winger'?2:1.5;
 return round(g.goals*goalBonus+g.assists*assistBonus);
}
function capturedBigGames(data,season){const rows=(Array.isArray(data?.matches)?data.matches:[]).filter(m=>m&&String(m.season)===String(season.id)&&m.count===true&&eliteOpponent(m.opponent));
 // Match totals count the tracked player only. Deduplicate by saved match ID.
 const seen=new Set();let goals=0,assists=0,matches=0;
 for(const m of rows){const id=m.id??`${m.date}|${m.opponent}|${m.competition||''}`;if(seen.has(id))continue;seen.add(id);
  const g=finite(m.goals),a=finite(m.assists);goals+=g!==null&&g>=0&&g<=20?g:0;assists+=a!==null&&a>=0&&a<=20?a:0;matches++;
 }
 return {goals,assists,matches,source:'recorded-matches-at-closure',rankingYear:2025,rankingSource:CLUB_RANK_SOURCE};
}
function snapshotKeyPasses(data,season){const player=cleanClub(season?.playerProfile?.name||data?.profile?.name||'');if(!player)return null;
 let total=0,recorded=false;
 for(const m of Array.isArray(data?.matches)?data.matches:[]){if(String(m?.season)!==String(season.id)||m?.count!==true||!Array.isArray(m.actions))continue;
  recorded=true;for(const e of m.actions){if(e?.type==='Key pass'&&cleanClub(e.player)===player&&(!m.playerSide||!e.side||e.side===m.playerSide))total++;}
 }
 return recorded?Math.min(total,1000):null;
}
function measuredRival(s){
 const snap=s?.awardsV3717?.seasonSnapshot;
 const r=snap?snap.teammate:s?.awardsRivalV3722;
 if(!r||!String(r.name||'').trim())return null;
 const g=finite(r.goals),a=finite(r.assists),rating=cleanRating(r.rating);
 if(g===null||a===null||g<0||a<0||g>200||a>200||rating===null)return null;
 return {name:String(r.name).trim().slice(0,90),goals:g,assists:a,rating,source:'user-recorded'};
}
function rivalBenchmark(season,trophies,st,context={}){
 const verified=measuredRival(season),rival=verified||{name:'Simulated team-leader benchmark',goals:trophies.major?28:23,assists:trophies.major?14:11,rating:trophies.major?7.9:7.8,source:'benchmark'};
 const m={...rival,matches:Math.max(35,st.matches)};
 // Intra-team comparator assumes a striker when no teammate role has been recorded.
 const pos=verified?(context.position||'general'):'striker',points=performance(m,pos,context.leagueMultiplier??1);
 const teamPoints=(context.uclPoints||0)+(context.leaguePoints||0)+(context.cupPoints||0)+(context.superCupPoints||0)+(context.internationalPoints||0)+(context.otherEuropeanPoints||0);
 return {...rival,matches:m.matches,performance:points.total,score:round(points.total+teamPoints),
  description:verified?'Teammate statistics entered in Seasons; assumed ST role if unspecified':'Modelled comparator, not a real player or official award leaderboard'};
}
// Freeze from the ARCHIVED review only. Never recompute a historical snapshot
// using current-season matches or today's seasonTotals.
// V37.24: only archived, competition-specific evidence may feed specialized awards.
// Missing historical match breakdowns remain null, never a made-up zero or a total-goals proxy.
const validCount=(v,max=300,integer=true)=>{const n=finite(v);return n!==null&&n>=0&&n<=max&&(!integer||Number.isInteger(n))?n:null;};
const positiveOrNull=(v,max=300)=>validCount(v,max);
const ageAtEndOfSeason=(birthDate,year)=>{
 const b=iso(birthDate);if(!b||!Number.isInteger(year))return null;
 const age=year-Number(b.slice(0,4))-(b.slice(5)> '06-30'?1:0);
 return age>=0&&age<=80?age:null;
};
function classOfMatch(m){
 const typ=normalize(m?.competitionType||m?.type||'');
 if(/champions league|\bucl\b/.test(typ))return 'ucl';
 if(/^(league|domestic league)$/.test(typ))return 'league';
 if(typ&&/cup|europa|conference|friendly|national team/.test(typ))return 'other';
 const name=normalize(m?.competitionName||m?.leagueName||m?.competition||'');
 if(/champions league|liga mistrzow|\bucl\b/.test(name))return 'ucl';
 if(/laliga|la liga|premier league|serie a|bundesliga|ligue 1|eredivisie|primeira liga|liga portugal|ekstraklasa|primera division/.test(name))return 'league';
 return 'unknown';
}
function captureCompetitionStats(data,season){
 const manual=season?.awardsCompetitionStatsV3724||{};
 const rows=(Array.isArray(data?.matches)?data.matches:[]).filter(m=>String(m?.season)===String(season.id)&&m?.count===true);
 const seen=new Set();const groups={league:[],ucl:[]};let untyped=0;
 for(const m of rows){const id=m.id??`${m.date}|${m.opponent}|${m.competitionName||m.competition||''}`;if(seen.has(id))continue;seen.add(id);
  const typ=classOfMatch(m);if(groups[typ])groups[typ].push(m);else if(typ==='unknown')untyped++;
 }
 const sum=(list,key)=>list.reduce((total,m)=>total+(validCount(m?.[key],20)??0),0);
 const u=groups.ucl,l=groups.league;
 const rated=u.map(m=>cleanRating(m?.rating)).filter(v=>v!==null);
 const knockout=u.filter(m=>/round.?of.?16|knockout|quarter|semi|final|1\/8|1\/4|1\/2/i.test([m.round,m.stage,m.phase,m.roundName,m.fixtureRound].filter(Boolean).join(' ')));
 // Historical base figures and unidentified competition matches make a strict derivation incomplete.
 const historical=positive(season?.baseM)>0 || untyped>0;
 const auto=historical?{}:{leagueGoals:rows.length?sum(l,'goals'):null,leagueMatches:rows.length?l.length:null,
  uclMatches:rows.length?u.length:null,uclGoals:rows.length?sum(u,'goals'):null,uclAssists:rows.length?sum(u,'assists'):null,
  uclRating:rated.length?round(rated.reduce((a,b)=>a+b,0)/rated.length):null,
  uclKnockoutGoals:rows.length?sum(knockout,'goals'):null,
  uclKnockoutAssists:rows.length?sum(knockout,'assists'):null};
 // Explicit manual evidence has precedence, but every field is independently checked.
 const spec={leagueGoals:200,leagueMatches:100,uclMatches:25,uclGoals:100,uclAssists:100,
  uclRating:10,uclKeyPasses:250,uclKnockoutGoals:100,uclKnockoutAssists:100};
 const value={};const sources={};
 for(const [key,max] of Object.entries(spec)){
  const user=validCount(manual[key],max,key!=='uclRating');
  const automatic=validCount(auto[key],max,key!=='uclRating');
  value[key]=user!==null?user:automatic;
  sources[key]=user!==null?'manual-at-season-closure':automatic!==null?'recorded-season-matches':'unavailable';
 }
 if(value.uclKeyPasses===null){let keyPasses=0,seenActions=false;
  for(const m of u){if(!Array.isArray(m.actions))continue;seenActions=true;for(const event of m.actions){if(normalize(event?.type)==='key pass'&&event?.side!== 'opponent')keyPasses++;}}
  if(!historical&&seenActions){value.uclKeyPasses=Math.min(250,keyPasses);sources.uclKeyPasses='recorded-ucl-actions';}
 }
 return {...value,sources,source:'season-closure-v3724',coverage:{recordedMatches:rows.length,untyped,historical}};
}
const GOLDEN_SHOE_MULTIPLIERS=Object.freeze({'top-5':2,'strong':1.5,other:1});
function goldenShoeMultiplier(tier){return GOLDEN_SHOE_MULTIPLIERS[tier]??null;}
function positionSlot(raw){
 const codes=normalize(raw).toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean);
 for(const code of codes){if(['LW','LP','LM','LS'].includes(code))return 'LW';if(['RW','PP','RM','PS'].includes(code))return 'RW';
  if(['ST','CF','FW'].includes(code))return 'ST';if(['CAM','CM','AM','CDM','MID'].includes(code))return 'CM';
  if(code==='LB')return 'LB';if(code==='RB')return 'RB';if(code==='CB')return 'CB';if(code==='GK')return 'GK';}
 return null;
}
const WORLD_XI_SLOTS=Object.freeze(['GK','RB','CB','CB','LB','CM','CM','CM','RW','ST','LW']);
// Deterministic 4-3-3 selection. Empty slots stay unknown, not fictional player names.
function selectWorldXI(candidates){
 const contestants=(Array.isArray(candidates)?candidates:[]).filter(c=>c&&typeof c==='object').map((c,i)=>({
  id:String(c.id??`candidate-${i}`),name:String(c.name||'').slice(0,90),slot:positionSlot(c.position||c.slot),
  score:validCount(c.score,10000,false)??0,rating:cleanRating(c.rating),matches:validCount(c.matches,200)??0
 })).filter(c=>c.slot&&c.matches>=20&&c.rating!==null);
 contestants.sort((a,b)=>b.score-a.score||b.rating-a.rating||a.id.localeCompare(b.id));
 const used=new Set();const selected=WORLD_XI_SLOTS.map(slot=>{
  const next=contestants.find(c=>c.slot===slot&&!used.has(c.id));if(!next)return {slot,player:null};used.add(next.id);return {slot,player:next};
 });
 return {formation:'4-3-3',selected,complete:selected.every(x=>x.player!==null)};
}
function rankLinear(score,minimum,maximum,bottom,top){
 const s=finite(score);
 if(s===null||!Number.isFinite(minimum)||!Number.isFinite(maximum)||
    !Number.isFinite(bottom)||!Number.isFinite(top)||maximum<=minimum)return null;
 if(s<minimum)return null;
 if(s>=maximum)return top;
 return Math.min(bottom,Math.max(top,Math.round(bottom-(s-minimum)*(bottom-top)/(maximum-minimum))));
}
function thresholdRank(score,cutLow,cutMid,winCut,bottom,midRank){
 const s=finite(score);
 if(s===null||![cutLow,cutMid,winCut,bottom,midRank].every(Number.isFinite)||
    !(cutLow<cutMid&&cutMid<=winCut&&bottom>midRank&&midRank>=2))return null;
 if(s<cutLow)return null;
 if(s<cutMid)return rankLinear(s,cutLow,cutMid-1,bottom,midRank+1);
 if(s<=winCut)return rankLinear(s,cutMid,winCut,midRank,2);
 return 1;
}
function evaluateSpecial(data,season,id,details){
 const {snapshot,st,yr,ceremonyDate,context,pos,baseScore,rawStats}=details;
 const age=positiveOrNull(snapshot?.ageAtSeasonEnd,80);
 const cs=snapshot?.competitionStats||{};
 const finiteMetric=(key,max=500)=>positiveOrNull(cs[key],max);
 const uclMatches=finiteMetric('uclMatches',25),leagueGoals=finiteMetric('leagueGoals',200);
 const uclGoals=finiteMetric('uclGoals'),uclAssists=finiteMetric('uclAssists'),uclRating=cleanRating(cs.uclRating);
 const kp=finiteMetric('uclKeyPasses'),kGoals=finiteMetric('uclKnockoutGoals'),kAssists=finiteMetric('uclKnockoutAssists');
 let score=0,rank=null,eligible=false,why='',breakdown={},unknown=[],contextExtra={};
 if(id==='kopa_trophy'){
  eligible=age!==null&&age<=21&&st.matches>=15;
  score=baseScore;rank=eligible?thresholdRank(score,80,120,150,10,5):null;
  why=age===null?'Age at season end was not recorded in the locked snapshot.':!eligible?'Kopa requires age 21 or under and 15 appearances.':'U21 contribution evaluated on the frozen weighted season score.';
  breakdown={weightedSeason:baseScore,ageAtSeasonEnd:age};
 }else if(id==='european_golden_shoe'){
  const multiplier=goldenShoeMultiplier(context.leagueTier);
  eligible=leagueGoals!==null&&multiplier!==null;
  score=eligible?round(leagueGoals*multiplier):0;
  // Sole measure: league goals × fixed domestic league coefficient.
  // Exactly 45 is 2nd; strictly greater than 45 is projected 1st.
  rank=eligible?(score>45?1:rankLinear(score,35,45,10,2)):null;
  why=multiplier===null?'Unknown domestic league tier: cannot award Golden Shoe points.':leagueGoals===null?'League-only goal total unavailable: overall season goals are not substituted.':'Only domestic league goals are counted.';
  breakdown={leagueGoals,multiplier};
 }else if(id==='ucl_player_of_season'){
  eligible=uclMatches!==null&&uclMatches>=6&&uclGoals!==null&&uclAssists!==null;
  // Dedicated Champions League output: no domestic stats, no domestic trophies.
  const uclR=ratingBonus(uclRating);
  score=eligible?round(uclGoals*5+uclAssists*3+(kp??0)*.24+uclR*.55+
   context.uclPoints*.47+(kGoals??0)*2.5+(kAssists??0)*1.5):0;
  rank=eligible?(score>130?1:rankLinear(score,90,130,10,2)):null;
  why=uclMatches===null?'UCL match breakdown missing.':uclMatches<6?'At least six UCL appearances are required.':!eligible?'UCL goals and assists are required for an evidence-based score.':'Only UEFA Champions League appearances, performance and advancement are counted.';
  breakdown={uclMatches,uclGoals,uclAssists,uclRating,uclKeyPasses:kp,knockoutGoals:kGoals,knockoutAssists:kAssists,stagePoints:context.uclPoints};
 }else if(id==='playmaker_of_year'){
  eligible=['winger','midfielder'].includes(pos)&&st.matches>=20;
  const keyPass=positiveOrNull(rawStats?.keyPasses,1000);
  score=round(st.assists+(keyPass??0)*.06);
  rank=eligible?(score>26&&st.rating!==null&&st.rating>=8?1:rankLinear(score,20,26,10,2)):null;
  why=!eligible?'Requires LW/RW/CAM/CM (or midfield equivalent) and at least 20 matches.':'Assist-equivalent creation points: assists plus 0.06 per recorded key pass.';
  breakdown={assists:st.assists,keyPasses:keyPass,averageRating:st.rating};
 }else if(id==='fifpro_world_xi'){
  const slot=positionSlot(snapshot?.playerPosition||'');
  // A complete positional XI needs candidate data; absent that, only a projection.
  eligible=!!slot&&st.matches>=20&&st.rating!==null;
  score=baseScore;
  const comparisons=Array.isArray(snapshot?.worldXICompetitors)?snapshot.worldXICompetitors:[];
  const team=selectWorldXI([...comparisons,{id:'player',name:String(snapshot?.playerName||data?.profile?.name||'Your player'),position:slot,score,rating:st.rating,matches:st.matches}]);
  const selected=team.selected.some(x=>x.player?.id==='player');
  // Unknown rivals are not treated as beaten by default.
  const benchmark=pos==='goalkeeper'?190:pos==='defender'?200:pos==='midfielder'?225:245;
  rank=eligible&&selected&&score>=benchmark&&st.rating>=7.8?1:null;
  why=!eligible?'Position, rating and 20 appearances are required.':rank===1?'Projected 4-3-3 position; incomplete competitor data is not an official World XI.':'The positional model threshold or available competitor ranking was not met.';
  contextExtra={slot,formation:'4-3-3',worldXI:team,provisional:!team.complete};
  breakdown={seasonScore:score,slot,benchmark,averageRating:st.rating,availableCompetitors:comparisons.length};
 }
 const canWin=eligible&&rank===1;
 const nominated=eligible&&rank!==null;
 return {version:ASSESSMENT_VERSION,awardId:id,sourceSeasonId:season.id,seasonYear:yr,ceremonyDate,
  noticeDate:noticeDate(ceremonyDate,EVENTS[id].noticeDays),score:round(score),performance:round(score),trophyPoints:0,
  titles:{},stats:st,rival:{name:'Not applicable',source:'not-applicable',goals:0,assists:0},
  rank,nominated,canWin,eligible,explanation:why,breakdown,
  context:{...context,...contextExtra,age,position:pos,source:'locked-seasonSnapshot',competitionSources:cs.sources||{}},
  model:WEIGHTED_MODEL+' (deterministic projection; not official voting)'};
}
function createSeasonSnapshot(data,season){
 const r=season?.awardsV3717;if(!r?.closed)return null;
 const year=yearOfSeason({...season,awardsV3717:{...r,seasonSnapshot:null}},Array.isArray(data?.matches)?data.matches:[]);
 return {version:2,snapshotLocked:true,sourceSeasonId:season.id,seasonLabel:String(r.year||season.year||''),endYear:year,
  frozenAt:r.closedAt||null,stats:safeCopy(r.stats||{}),trophies:safeCopy(r.trophies||[]),
  competitions:safeCopy(r.competitions||[]),confirmedInternational:externalInternational(data,season,year),
  teammate:safeCopy(season.awardsRivalV3722||null),leagueName:String(r.leagueName||r.competitions?.find(c=>hasType(c,'league'))?.name||''),playerPosition:String(r.playerPosition||''),bigGames:{goals:0,assists:0,source:'unavailable-in-legacy-archive',rankingYear:2025},
  competitionStats:safeCopy(r.competitionStats||{}),ageAtSeasonEnd:validCount(r.ageAtSeasonEnd,80),
  playerBirthDate:String(r.playerBirthDate||''),playerName:String(r.playerName||''),
  worldXICompetitors:safeCopy(r.worldXICompetitors||[]),migrationSource:'archived-review'};
}
function ensureSnapshot(data,season){
 const r=season?.awardsV3717;
 if(!r?.closed)return false;
 let dirty=false;
 // Existing snapshot content is authoritative. Migration can ADD a lock,
 // but must never rebuild stats from newer seasons or the mutable review.
 if(r.seasonSnapshot&&typeof r.seasonSnapshot==='object'&&!Array.isArray(r.seasonSnapshot)){
  if(r.seasonSnapshot.snapshotLocked!==true){r.seasonSnapshot.snapshotLocked=true;dirty=true;}
  if(r.snapshotLocked!==true){r.snapshotLocked=true;dirty=true;}
  return dirty;
 }
 // If an invalid non-null snapshot is present, do not overwrite damaged evidence.
 // A separate user-initiated repair is needed; this is safer than fabricating data.
 if(r.seasonSnapshot!=null)return false;
 const snapshot=createSeasonSnapshot(data,season);
 if(!snapshot)return false;
 r.seasonSnapshot=snapshot;r.snapshotLocked=true;
 return true;
}
// Only an intentional teammate comparison edit may change this single field.
// It cannot alter archived goals, assists, ratings, trophies, or season year.
function reviseSnapshotTeammate(season,teammate,{explicit=false}={}){
 const r=season?.awardsV3717;
 if(!r?.closed||!r.seasonSnapshot||typeof r.seasonSnapshot!=='object'||Array.isArray(r.seasonSnapshot))return false;
 if(explicit!==true)throw Error('Season snapshot locked. An explicit teammate correction is required.');
 if(Object.values(r.global||{}).some(g=>g?.stage==='resolved'))throw Error('This review is locked after a global awards ceremony.');
 const next=teammate==null?null:safeCopy(teammate);
 const current=JSON.stringify(r.seasonSnapshot.teammate??null);
 if(current===JSON.stringify(next))return false;
 r.seasonSnapshot.teammate=next;
 r.seasonSnapshot.snapshotLocked=true;
 r.snapshotLocked=true;
 r.awardsEngineV3722={}; // Re-evaluate only pending ceremonies, never a resolved result.
 return true;
}
// Numeric tie-breaks are deterministic; exact statistical ties are deliberately
// unresolved rather than awarding the Ballon d'Or arbitrarily.
function comparePerformance(a,b){
 for(const k of ['score','performance','goals','assists','rating','matches']){
  const av=finite(a?.[k])??0,bv=finite(b?.[k])??0;
  if(Math.abs(av-bv)>1e-9)return av>bv?-1:1;
 }
 return 0;
}
function compareCandidates(a,b){
 const result=comparePerformance(a,b);if(result)return result;
 return String(a?.id??'').localeCompare(String(b?.id??''),'en');
}
function evaluate(data,season,awardId){
 const def=EVENTS[awardId];if(!def)return null;
 const r=season?.awardsV3717;if(!r?.closed)return null;
 // Ensure legacy closed reviews are migrated exactly once from their archived
 // values; never evaluate six awards against mutable live season totals.
 ensureSnapshot(data,season);
 const snap=r.seasonSnapshot&&typeof r.seasonSnapshot==='object'&&!Array.isArray(r.seasonSnapshot)?r.seasonSnapshot:null;
 if(!snap||snap.snapshotLocked!==true||
    (snap.sourceSeasonId!=null&&String(snap.sourceSeasonId)!==String(season.id)))return null;
 // Gala year is also frozen: never infer it from current matches or an
 // editable season name once a snapshot exists.
 const yr=Number.isInteger(snap.endYear)?snap.endYear:
  yearOfSeason({id:season.id,year:snap.seasonLabel,awardsV3717:{seasonSnapshot:{seasonLabel:snap.seasonLabel}}},[]);
 const ceremonyDate=dateFor(yr,awardId);if(!ceremonyDate)return null;
 const st=metrics(snap.stats),titles=trophyEvidence(data,season,r,yr);
 // Position, Big Games and specialized competition figures use the SAME snapshot.
 const pos=positionGroup(snap.playerPosition||'');
 const context=competitionEvidence(r,titles);
 const games=bigGameEvidence(snap.bigGames);
 const parts=performance(st,pos,context.leagueMultiplier);
 const bgPoints=bigGameScore(games,pos);
 const trophyPoints=round(context.uclPoints+context.leaguePoints+context.cupPoints+context.superCupPoints+context.internationalPoints+context.otherEuropeanPoints);
 const score=round(parts.total+trophyPoints+bgPoints),ga=st.goals+st.assists;
 if(!['ballon_dor','fifa_the_best'].includes(awardId))return evaluateSpecial(data,season,awardId,{snapshot:snap,st,yr,ceremonyDate,context,pos,baseScore:score,rawStats:snap.stats});
 const rival=rivalBenchmark(season,titles,st,{...context,position:pos});
 const domesticDouble=titles.league&&context.domesticCup;
 const deepUcl=context.uclPoints>=35;
 const standoutDomestic=domesticDouble&&deepUcl&&st.matches>=30&&st.goals>=20&&st.assists>=18&&ga>=52&&st.rating!==null&&st.rating>=8;
 const extraordinary=!titles.major&&((st.goals>=55&&ga>=70&&st.rating!==null&&st.rating>=8.3)||(ga>=85&&st.rating!==null&&st.rating>=8.2));
 const elite=st.matches>=30&&ga>=30&&st.rating!==null&&st.rating>=7.65;
 const evidenceForWin=(titles.major&&elite)||standoutDomestic||extraordinary;
 const playerCandidate={id:'player',score,performance:parts.total,...st};
 const rivalCandidate={id:'rival',score:rival.score,performance:rival.performance,goals:rival.goals,assists:rival.assists,rating:rival.rating,matches:rival.matches};
 const comparison=comparePerformance(playerCandidate,rivalCandidate);
 const rivalAhead=comparison>0&&(titles.major||domesticDouble);
 const tiedWithTeammate=comparison===0&&(titles.major||domesticDouble);
 const oldMode=awardId==='fifa_the_best';
 const eligible=st.matches>=20;
 const scoreRank=thresholdRank(score,150,250,320,30,10);
 const canWin=eligible&&evidenceForWin&&(oldMode?score>=def.minWinScore:score>320)&&!rivalAhead&&!tiedWithTeammate;
 const nominated=eligible&&(oldMode?(canWin||score>=165||(titles.major&&ga>=12)||(deepUcl&&ga>=25)):scoreRank!==null);
 // In 150..320, rank is determined ONLY by the explicit score bands:
 // 250 = 10th and 320 = 2nd. A better teammate can veto a *win* (>320),
 // but cannot arbitrarily turn a 250-point season into 5th place.
 const rank=!eligible?null:oldMode?(canWin?1:score>=220&&!rivalAhead?3:score>=135||titles.major&&ga>=12?5:null)
  :canWin?1:scoreRank===1?(rivalAhead?5:tiedWithTeammate?3:2):scoreRank;
 const explanation=!eligible?'At least 20 season appearances are required.':canWin?'Elite individual season, weighted competition success and no stronger team leader.'
  :rivalAhead?'A stronger teammate ranks ahead on contribution; shared club trophies do not guarantee an individual prize.'
  :tiedWithTeammate?'Exact statistical tie with the club leader; automatic victory is withheld.'
  :!titles.major&&!standoutDomestic&&!extraordinary?'Without a UCL/international title, winning requires extraordinary output or an elite domestic double with a deep UCL run.'
  :!elite&&!standoutDomestic?'Individual contribution has not reached the elite threshold.'
  :'The simulated worldwide award threshold was not reached.';
 const breakdown={attacking:parts.attack,appearances:parts.appearance,rating:parts.rating,
  bigGames:bgPoints,ucl:context.uclPoints,league:context.leaguePoints,
  domesticCup:context.cupPoints,superCup:context.superCupPoints,
  international:context.internationalPoints,otherEurope:context.otherEuropeanPoints};
 return {version:ASSESSMENT_VERSION,awardId,sourceSeasonId:season.id,seasonYear:yr,ceremonyDate,
  noticeDate:noticeDate(ceremonyDate,def.noticeDays),score,performance:parts.total,trophyPoints,
  titles,stats:st,rival,rank,eligible,nominated,canWin,tiedWithTeammate,explanation,breakdown,
  context:{...context,position:pos,bigGames:games,rankingYear:2025},
  model:WEIGHTED_MODEL+' (simulation, historical 2025 UEFA proxy, no official votes)'};
}
function sync(data){if(!data||typeof data!=='object')return false;let dirty=false;for(const s of Array.isArray(data.seasons)?data.seasons:[])if(ensureSnapshot(data,s))dirty=true;const now=careerDate(data);if(!now)return dirty;data.awardsInboxV3722=Array.isArray(data.awardsInboxV3722)?data.awardsInboxV3722:[];
 const notify=(id,date,title,body,seasonId,awardId,type)=>{if(data.awardsInboxV3722.some(m=>m.id===id))return;data.awardsInboxV3722.push({id,date,title,body,seasonId,awardId,type,read:false});dirty=true;};
 for(const s of Array.isArray(data.seasons)?data.seasons:[]){const review=s?.awardsV3717;if(!review?.closed)continue;review.awardsEngineV3722??={};for(const awardId of Object.keys(EVENTS)){
  const existing=review.global?.[awardId];if(existing?.manuallyDecided||existing?.stage==='resolved')continue;
  // Legacy manually verified Golden Shoe result is authoritative, not a new simulated loss.
  if(awardId==='european_golden_shoe'&&Array.isArray(review.manualAwards)&&review.manualAwards.some(a=>a?.type==='european_golden_shoe'&&String(a.status||'Won').toLowerCase()==='won')){
   review.global??={};review.global[awardId]={status:'Won',stage:'resolved',manuallyDecided:true,decidedAt:'Archived verified Golden Shoe'};dirty=true;continue;
  }
  const oldEval=review.awardsEngineV3722[awardId];const v=oldEval?.version===ASSESSMENT_VERSION?oldEval:evaluate(data,s,awardId);if(!v)continue;
  if(oldEval!==v){review.awardsEngineV3722[awardId]=v;dirty=true;}
  review.global??={};review.global[awardId]??={};const g=review.global[awardId];
  if(now<v.noticeDate){if(g.automaticallyDecided||g.manuallyDecided)continue;if(g.stage!=='pending_date'||g.status!==null){g.stage='pending_date';g.status=null;dirty=true;}continue;}
  if(now>=v.noticeDate && v.nominated){const id=`award-v3722:${s.id}:${awardId}:nomination`;notify(id,v.noticeDate,`${EVENTS[awardId].name} — nomination`,`${s.year||s.name}: ${String(data.profile?.name||'Your player')} has been nominated. The gala is scheduled for ${v.ceremonyDate}.`,s.id,awardId,'nomination');}
  if(now<v.ceremonyDate){const status=v.nominated?'Nominated':null,stage=v.nominated?'nominated':'not_eligible';if(g.status!==status||g.stage!==stage){g.status=status;g.stage=stage;dirty=true;}continue;}
  if(g.stage==='resolved'&&g.automaticallyDecided)continue;
  const status=v.canWin?'Won':v.nominated?'Lost':null;
  const stage='resolved';Object.assign(g,{status,stage,automaticallyDecided:true,manuallyDecided:false,decidedAt:v.ceremonyDate,decidedInSeasonId:(data.seasons||[]).find(x=>x.id!==s.id&&String(x.year||'').includes(String(v.seasonYear)))?.id||null,ceremonyDate:v.ceremonyDate,modelRank:v.rank});dirty=true;
  if(v.nominated||v.canWin)notify(`award-v3722:${s.id}:${awardId}:ceremony`,v.ceremonyDate,`${EVENTS[awardId].name} — results`,`${s.year||s.name}: ${status==='Won'?'Projected winner in Matchbook simulation':status==='Lost'?`Nominated · projected rank ${v.rank||'unknown'}`:'Not nominated'}. ${v.explanation}`,s.id,awardId,'result');
 }
 }
 return dirty;
}
const api={EVENTS,yearOfSeason,careerDate,dateFor,evaluate,sync,rivalBenchmark,createSeasonSnapshot,ensureSnapshot,reviseSnapshotTeammate,comparePerformance,compareCandidates,WEIGHTED_MODEL,EUROPEAN_TOP_25_2025,leagueTier,eliteOpponent,positionGroup,performance,uclStage,competitionEvidence,capturedBigGames,snapshotKeyPasses,bigGameScore,LEAGUE_RANK_SOURCE,CLUB_RANK_SOURCE,captureCompetitionStats,ageAtEndOfSeason,selectWorldXI,WORLD_XI_SLOTS,thresholdRank,goldenShoeMultiplier,ASSESSMENT_VERSION};
root.MatchbookAwardsV3722=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;

// Node tests import the pure model without the browser globals.
if(typeof document==='undefined'||typeof db==='undefined')return;
const saved=typeof save==='function'?save:null;const drawn=typeof render==='function'?render:null;const previousManagement=typeof managementView==='function'?managementView:null;
function safeSync(){if(typeof storageState!=='undefined'&&(storageState?.blocked||storageState?.conflict))return false;try{return sync(db)}catch(e){console.error('Awards engine sync',e);return false;}}
if(saved)save=function(){const before=structuredClone({seasons:db.seasons,awardsInboxV3722:db.awardsInboxV3722});safeSync();const ok=saved();if(!ok){db.seasons=before.seasons;db.awardsInboxV3722=before.awardsInboxV3722;}return ok;};
function inbox(){const list=(db.awardsInboxV3722||[]).slice().sort((a,b)=>b.date.localeCompare(a.date)),unread=list.filter(x=>!x.read).length,at=careerDate(db);return `<section class="aw22-inbox"><div class="aw22-inbox-title"><div><small>CAREER NOTIFICATIONS · OCTOBER CEREMONIES</small><h1>Inbox</h1><p>New messages arrive when the recorded career date crosses a nomination or ceremony date. Planned fixtures do not advance the clock.</p></div><span class="aw22-unread">${unread} UNREAD</span></div><div class="aw22-clock"><b>Career date: ${escText(at||'unknown')}</b><label>Simulated career date <input type="date" id="aw22-career-date" value="${escText(iso(db.awardsCareerDateV3722)||at)}"></label><button type="button" data-aw22-advance>Advance date</button></div>${list.length?list.map(m=>`<article class="aw22-mail ${m.read?'is-read':''}"><div><small>${escText(m.date)} · ${escText(m.type==='nomination'?'NOMINATION':'CEREMONY')}</small><h3>${escText(m.title)}</h3><p>${escText(m.body)}</p></div>${m.read?'<span class="aw22-read-tag">READ</span>':`<button type="button" data-aw22-read="${escText(m.id)}">Mark read</button>`}</article>`).join(''):'<div class="aw22-empty">No messages yet. Finish a season review and advance to the following autumn to receive award updates.</div>'}</section>`;}
function rivalPanel(s){
 const r=s.awardsRivalV3722||{},closed=s.awardsV3717?.closed,resolved=closed&&Object.values(s.awardsV3717.global||{}).some(g=>g?.stage==='resolved'),locked=!!resolved;
 return `<section class="aw22-rival-panel" data-aw22-rival-form="${escText(s.id)}"><small>AWARDS · TEAMMATE CONTRIBUTION CHECK</small><h3>Club's strongest individual competitor</h3><p>Optional verified statistics. If left blank, Matchbook uses a labelled simulated benchmark; it never invents a real player. ${closed?'These figures are used only for the later global award evaluation.':''}</p><div class="aw22-rival-inputs"><label>Teammate name<input data-aw22-rival-field="name" value="${escText(r.name||'')}" ${locked?'disabled':''} placeholder="Known club leader"></label><label>Goals<input data-aw22-rival-field="goals" type="number" min="0" max="200" value="${escText(r.goals??'')}" ${locked?'disabled':''}></label><label>Assists<input data-aw22-rival-field="assists" type="number" min="0" max="200" value="${escText(r.assists??'')}" ${locked?'disabled':''}></label><label>Rating<input data-aw22-rival-field="rating" type="number" min="1" max="10" step="0.1" value="${escText(r.rating??'')}" ${locked?'disabled':''}></label></div>${locked?'<small>Locked after global ceremony.</small>':'<button type="button" data-aw22-save-rival>Save teammate comparison</button>'}</section>`;}
function dossier(){const reviews=(db.seasons||[]).filter(s=>s.awardsV3717?.closed).slice().reverse(),rows=reviews.flatMap(s=>Object.keys(EVENTS).map(id=>{const r=s.awardsV3717,v=r.awardsEngineV3722?.[id],g=r.global?.[id];if(!v)return '';const status=g?.status||((careerDate(db)<v.noticeDate)?'Scheduled':'No nomination');return `<article class="aw22-dossier"><div class="aw22-dossier-head"><div><small>${escText(s.year||s.name)} · ${escText(v.ceremonyDate)}</small><h3>${escText(EVENTS[id].name)}</h3></div><span>${escText(status)}</span></div><div class="aw22-stats"><span><b>${escText(v.score)}</b> MODEL POINTS</span><span><b>${escText(v.stats.goals)} G / ${escText(v.stats.assists)} A</b> CONTRIBUTION</span><span><b>${escText(v.rank?`TOP ${v.rank}`:'—')}</b> PROJECTED RANK</span></div><p>${escText(v.explanation)}</p>${v.breakdown?`<p class="aw23-breakdown">Score breakdown · Attack ${escText(v.breakdown.attacking)} · Rating ${escText(v.breakdown.rating)} · UCL ${escText(v.breakdown.ucl)} · League ${escText(v.breakdown.league)} · Cup ${escText(v.breakdown.domesticCup)} · Big games ${escText(v.breakdown.bigGames)} · ${escText(v.context?.position||"general")} / ${escText(v.context?.leagueTier||"unknown")} · UEFA 2025 reference</p>`:""}<small>${v.rival.source==='not-applicable'?'Evidence and eligibility use the locked season snapshot.':v.rival.source==='benchmark'?'Intra-squad comparison uses a simulated benchmark (no verified teammate totals).':`Teammate comparison: ${escText(v.rival.name)} · ${escText(v.rival.goals)} G / ${escText(v.rival.assists)} A`}</small></article>`})).filter(Boolean);return `<section class="aw22-dossiers"><div class="aw22-dossier-top"><h2>Season award assessments</h2><button type="button" data-aw22-open>Open Awards Inbox ✉</button></div><p>Model assessments are simulations, not official shortlists or certified votes. The season snapshot is preserved until the gala.</p>${rows.join('')||'<p>No archived seasons yet.</p>'}</section>`;}
if(previousManagement)managementView=function(){return page==='Inbox'?inbox():previousManagement();};
if(drawn)render=function(){const changed=safeSync();if(changed&&saved)saved();const value=drawn();const nav=document.querySelector('#nav');if(nav&&!nav.querySelector('[data-page="Inbox"]')){const b=document.createElement('button');b.type='button';b.dataset.page='Inbox';b.className=page==='Inbox'?'active':'';b.innerHTML='<span class="aw22-nav-icon">✉</span><span>Inbox</span>';const awards=nav.querySelector('[data-page="Awards"]');if(awards)awards.after(b);else nav.append(b);}
 if(page==='Seasons')document.querySelectorAll('.season-card').forEach((card,i)=>{const s=db.seasons[i];if(s&&!card.querySelector('.aw22-rival-panel'))card.insertAdjacentHTML('beforeend',rivalPanel(s));});
 if(page==='Seasons')document.querySelectorAll('.season-card').forEach((card,i)=>{
 const s=db.seasons[i];if(!s||card.querySelector('.aw24-inputs'))return;
 const closed=!!s.awardsV3717?.closed,values=s.awardsCompetitionStatsV3724||{},fields=[
 ['leagueGoals','League goals'],['uclMatches','UCL appearances'],['uclGoals','UCL goals'],
 ['uclAssists','UCL assists'],['uclRating','UCL average rating'],['uclKeyPasses','UCL key passes'],
 ['uclKnockoutGoals','UCL knockout goals'],['uclKnockoutAssists','UCL knockout assists']];
 const markup=`<section class="aw24-inputs" data-aw24-season="${escText(s.id)}"><small>AWARDS · VERIFIED COMPETITION STATS</small><h3>League / UCL award evidence</h3><p>Optional figures for incomplete match reports. Save BEFORE confirming season closure; results are frozen for the autumn ceremony. Leave unknown fields empty, not zero.</p><div class="aw24-fields">${fields.map(([k,label])=>`<label>${label}<input type="number" min="0" max="${k==='uclRating'?10:k==='uclMatches'?25:k==='leagueMatches'?100:k==='uclKeyPasses'?250:200}" step="${k==='uclRating'?'0.1':'1'}" data-aw24-field="${k}" value="${escText(values[k]??'')}" ${closed?'disabled':''}></label>`).join('')}</div>${closed?'<small>Locked in the archived seasonSnapshot.</small>':'<button type="button" data-aw24-save>Save verified figures</button>'}</section>`;
 card.insertAdjacentHTML('beforeend',markup);
});
 if(page==='Awards'){const room=document.querySelector('.aw19-room');if(room&&!room.querySelector('.aw22-dossiers'))room.insertAdjacentHTML('beforeend',dossier());}
 if(page==='Dashboard'){const content=document.querySelector('#content'),unread=(db.awardsInboxV3722||[]).filter(n=>!n.read).length;if(content&&unread&&!content.querySelector('.aw22-dashboard-notice'))content.insertAdjacentHTML('afterbegin',`<button class="aw22-dashboard-notice" type="button" data-aw22-open>✉ ${unread} new Awards Inbox ${unread===1?'message':'messages'}</button>`);}
 return value;};
document.addEventListener('click',e=>{const saveRival=e.target.closest?.('[data-aw22-save-rival]');if(saveRival){const host=saveRival.closest('[data-aw22-rival-form]'),s=(db.seasons||[]).find(x=>String(x.id)===String(host?.dataset.aw22RivalForm));if(!s)return;const inputs=Object.fromEntries([...host.querySelectorAll('[data-aw22-rival-field]')].map(el=>[el.dataset.aw22RivalField,String(el.value||'').trim()]));const empty=Object.values(inputs).every(v=>!v);let next=null;
 if(!empty){const g=finite(inputs.goals),a=finite(inputs.assists),r=finite(inputs.rating);if(!inputs.name||g===null||a===null||r===null||g<0||a<0||g>200||a>200||r<1||r>10){if(typeof toast==='function')toast('Enter teammate name, goals, assists, and rating (1–10).');return;}next={name:inputs.name.slice(0,90),goals:g,assists:a,rating:r};}
 if(s.awardsV3717?.closed&&Object.values(s.awardsV3717.global||{}).some(g=>g?.stage==='resolved')){if(typeof toast==='function')toast('This season is locked after the ceremony.');return;}
 if(typeof createRestorePoint==='function'&&!createRestorePoint('Before editing teammate award comparator'))return;
 const before=structuredClone({rival:s.awardsRivalV3722,assessment:s.awardsV3717?.awardsEngineV3722,snapshot:s.awardsV3717?.seasonSnapshot});
 if(next)s.awardsRivalV3722=next;else delete s.awardsRivalV3722;
 if(s.awardsV3717?.closed){ensureSnapshot(db,s);reviseSnapshotTeammate(s,next,{explicit:true});}
 if(!save()){
  if(before.rival)s.awardsRivalV3722=before.rival;else delete s.awardsRivalV3722;
  if(s.awardsV3717?.closed){s.awardsV3717.awardsEngineV3722=before.assessment||{};if(before.snapshot)s.awardsV3717.seasonSnapshot=before.snapshot;else delete s.awardsV3717.seasonSnapshot;}
  return;
 }render();if(typeof toast==='function')toast('Teammate comparison saved');return;}
 const read=e.target.closest?.('[data-aw22-read]');if(read){const m=(db.awardsInboxV3722||[]).find(x=>x.id===read.dataset.aw22Read);if(m&&!m.read){const old=m.read;m.read=true;if(!save())m.read=old;render();}return;}
 if(e.target.closest?.('[data-aw22-open]')){page='Inbox';render();return;}
 if(e.target.closest?.('[data-aw22-advance]')){const field=document.querySelector('#aw22-career-date'),v=iso(field?.value),before=db.awardsCareerDateV3722||'',now=careerDate(db);if(!v||v<now){if(typeof toast==='function')toast('Choose a valid date no earlier than the recorded career date.');return;}if(typeof createRestorePoint==='function'&&!createRestorePoint('Before changing awards career date'))return;db.awardsCareerDateV3722=v;if(!save()){db.awardsCareerDateV3722=before;return;}render();return;}
});
try{if(safeSync()&&saved)saved();if(drawn)render();}catch(e){console.error('Awards engine startup',e)}

// Saves optional evidence BEFORE a season is archived; never changes an already locked snapshot.
document.addEventListener('click',function(e){
 const btn=e.target.closest('[data-aw24-save]');if(!btn)return;
 const panel=btn.closest('[data-aw24-season]'),s=(db.seasons||[]).find(x=>String(x.id)===String(panel?.dataset.aw24Season));
 if(!s||s.awardsV3717?.closed)return;
 const next={};for(const el of panel.querySelectorAll('[data-aw24-field]')){
  if(el.value.trim()==='')continue;
  const key=el.dataset.aw24Field;const max=key==='uclRating'?10:key==='uclMatches'?25:key==='leagueMatches'?100:key==='uclKeyPasses'?250:200;
  const val=finite(el.value);if(val===null||val<0||val>max||(key!=='uclRating'&&!Number.isInteger(val))){if(typeof toast==='function')toast('Enter valid nonnegative statistics.');return;}
  next[el.dataset.aw24Field]=val;
 }
 const prev=s.awardsCompetitionStatsV3724;
 s.awardsCompetitionStatsV3724=next;
 if(typeof save==='function'&&!save()){s.awardsCompetitionStatsV3724=prev;return;}
 if(typeof toast==='function')toast('Competition statistics saved for season closure.');
 if(typeof render==='function')render();
});
})(typeof window!=='undefined'?window:globalThis);
