/* Matchbook V37.7 — competition identity + automatic career pulse. */
(function(){
'use strict';
const safe=v=>typeof esc==='function'?esc(v):String(v??'');
const norm=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ł/g,'l').replace(/[^a-z0-9]+/g,' ').trim();
const logoDefs=[
 {id:87,key:'LAL',label:'LaLiga',test:/\b(la ?liga|laliga|primera division)\b/},
 {id:42,key:'UCL',label:'Champions League',test:/\b(champions league|ucl|liga mistrzow)\b/},
 {id:73,key:'UEL',label:'Europa League',test:/\b(europa league|uel|liga europy)\b/},
 {id:10216,key:'UECL',label:'Conference League',test:/\b(conference league|uecl|liga konferencji)\b/},
 {id:138,key:'CDR',label:'Copa del Rey',test:/\b(copa del rey|copa de espana|copa de españa)\b/},
 {id:47,key:'EPL',label:'Premier League',test:/\b(premier league|epl)\b/},
 {id:54,key:'BUN',label:'Bundesliga',test:/\bbundesliga\b/},
 {id:55,key:'SA',label:'Serie A',test:/\bserie a\b/},
 {id:53,key:'L1',label:'Ligue 1',test:/\bligue 1\b/},
 {id:57,key:'ERE',label:'Eredivisie',test:/\beredivisie\b/}
];
function competitionText(item){
 if(!item)return 'Match';
 if(typeof item==='string')return item;
 let name=String(item.competitionName||item.leagueName||item.competition||item.competitionType||'').trim();
 if((!name||['League','Domestic cup','League cup','Super cup'].includes(name))&&typeof calendarCompetitionName==='function'){
  try{name=calendarCompetitionName(item)||name}catch{}
 }
 return name||String(item.competitionType||'Match');
}
function fallbackKey(name,item){
 const category=typeof competitionCategory==='function'?competitionCategory(item||{competition:name}):String(item?.competitionType||'');
 if(category==='League')return 'LG';
 if(category==='Domestic cup')return 'CUP';
 if(category==='League cup')return 'LC';
 if(category==='Super cup')return 'SC';
 if(category==='National team')return 'INT';
 if(category==='Friendly')return 'FR';
 const words=String(name||'Match').split(/\s+/).filter(Boolean);
 return (words.length>1?words.slice(0,3).map(x=>x[0]).join(''):words[0]?.slice(0,3)||'M').toUpperCase();
}
function competitionIdentity(item){
 const name=competitionText(item),n=norm(name),def=logoDefs.find(x=>x.test.test(n));
 return {name,label:def?.label||name,key:def?.key||fallbackKey(name,item),id:def?.id||null,url:def?`https://images.fotmob.com/image_resources/logo/leaguelogo/${def.id}.png`:''};
}
function competitionBadge(item,size='small'){
 const c=competitionIdentity(item),cls=size==='tiny'?' tiny':size==='large'?' large':'';
 const img=c.url?`<img src="${safe(c.url)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.hidden=true;this.nextElementSibling.hidden=false">`:'';
 return `<span class="mb-competition-logo${cls}" title="${safe(c.name)}" aria-label="${safe(c.name)}">${img}<span class="mb-competition-fallback" ${c.url?'hidden':''}>${safe(c.key)}</span></span>`;
}
window.matchbookCompetitionIdentity=competitionIdentity;
window.matchbookCompetitionBadge=competitionBadge;

function day(v){
 if(typeof mediaDay==='function')return mediaDay(v);
 const s=String(v||'');return /^\d{4}-\d{2}-\d{2}/.test(s)?s.slice(0,10):'';
}
function seasonRows(id=season){
 const rows=(typeof allMatchViews==='function'?allMatchViews():db.matches||[]).filter(m=>m&&m.count!==false&&(id==='@career'||m.season===id));
 return rows.map((m,i)=>({m,i,d:day(m.date)})).sort((a,b)=>a.d&&b.d?b.d.localeCompare(a.d)||b.i-a.i:a.d?-1:b.d?1:b.i-a.i).map(x=>x.m);
}
function matchOutcomeSafe(m,club){try{return typeof matchOutcome==='function'?matchOutcome(m,club):''}catch{return ''}}
function consecutive(rows,test){let n=0;for(const m of rows){if(!test(m))break;n++}return n}
function average(nums){const a=nums.filter(Number.isFinite);return a.length?a.reduce((x,y)=>x+y,0)/a.length:null}
function competitionNameOf(m){return competitionText(m)}
function latestGoalEvent(rows,name){const same=(a,b)=>String(a||'').trim().toLowerCase()===String(b||'').trim().toLowerCase();for(const m of rows){const actions=Array.isArray(m.actions)?m.actions:[];for(let i=actions.length-1;i>=0;i--){const e=actions[i];if(!e||!['Goal','Penalty goal'].includes(e.type))continue;if(name&&e.player&&!same(e.player,name))continue;return {match:m,event:e}}}return null}
function finishStyleLine(goal){const e=goal?.event,s=e?.shot||{},gm=s.goalMouth;if(!gm)return '';const x=Number(gm.x),y=Number(gm.y),low=y<28,high=y>76,centre=Math.abs(x-50)<=10,left=x<25,right=x>75,corner=(left||right)&&(low||high);if(centre&&!low&&!high)return 'the latest one went almost straight down the middle — a goalkeeper mistake feeling more than a worldie';if(corner&&low)return `the latest one was a beautiful low-driven finish into the ${left?'bottom-left':'bottom-right'} corner`;if(corner&&high)return `the latest one was lashed into the ${left?'top-left':'top-right'} corner`;if(high&&centre)return 'the latest one flew high under the bar';if(low&&centre)return 'the latest one was a neat low finish through the middle';if(left||right)return `the latest one nestled inside the ${left?'left':'right'} side-netting`;return ''}
function leagueCompetitionForSeason(scopeSeason,rows){const fromSeason=(scopeSeason?.competitions||[]).find(c=>/league/i.test(String(c.competitionType||c.type||''))||/laliga|premier league|bundesliga|serie a|ligue 1|eredivisie/i.test(String(c.name||c.competitionName||c.competition||'')));if(fromSeason)return competitionText(fromSeason);const fromRows=rows.find(m=>/laliga|premier league|bundesliga|serie a|ligue 1|eredivisie/i.test(competitionNameOf(m)));return fromRows?competitionNameOf(fromRows):''}
function competitionTotals(rows,name){const hit=rows.filter(m=>competitionNameOf(m)===name);return {matches:hit.length,goals:hit.reduce((n,m)=>n+Number(m.goals||0),0),assists:hit.reduce((n,m)=>n+Number(m.assists||0),0)}}
function seasonHonours(scopeSeason,rows,p){
 if(typeof window.matchbookHonoursForSeason==='function')return window.matchbookHonoursForSeason(scopeSeason,rows,p);
 const honours=(scopeSeason?.competitions||[]).filter(c=>String(c.status||'').toLowerCase()==='won').map(c=>({status:'Won',tone:'won',label:competitionText(c),detail:'Team trophy won'}));
 return {honours,awardWatch:[],items:honours.slice(0,5),summary:honours.length?`${honours.length} team trophies recorded`:'No official awards recorded'};
}
function formInfo(rows){
 const rated=rows.filter(m=>Number(m.rating)>0).slice(0,5),avg=average(rated.map(m=>Number(m.rating)));
 if(avg==null||rated.length<2)return {label:'Form building',tone:'neutral',avg:null,count:rated.length,trend:''};
 let label='Difficult form',tone='low';
 if(avg>=7.8){label='Excellent form';tone='excellent'}
 else if(avg>=7.25){label='Strong form';tone='strong'}
 else if(avg>=6.8){label='Solid form';tone='good'}
 else if(avg>=6.4){label='Mixed form';tone='mixed'}
 const first=average(rated.slice(0,Math.min(3,rated.length)).map(m=>Number(m.rating))),prev=average(rated.slice(3,5).map(m=>Number(m.rating)));
 const trend=prev==null||first==null?'':first>prev+.18?'up':first<prev-.18?'down':'steady';
 return {label,tone,avg,count:rated.length,trend};
}
function careerPulseData(id=season){
 const rows=seasonRows(id),p=typeof playerProfile==='function'?playerProfile(id):db.profile||{},name=String(p?.name||'Player').trim(),first=name.split(/\s+/)[0]||'Player',scopeSeason=db.seasons?.find(s=>s.id===id)||(typeof latestPlayerProfileSeason==='function'?latestPlayerProfileSeason():null),club=scopeSeason?.club||p?.club||'';
 const form=formInfo(rows),goalStreak=consecutive(rows,m=>Number(m.goals)>0),assistStreak=consecutive(rows,m=>Number(m.assists)>0),gaStreak=consecutive(rows,m=>Number(m.goals)+Number(m.assists)>0),unbeaten=consecutive(rows,m=>['W','R'].includes(matchOutcomeSafe(m,club))),rated7=consecutive(rows,m=>Number(m.rating)>=7),latestGoal=latestGoalEvent(rows,p?.name),goalStyle=finishStyleLine(latestGoal);
 const last5=rows.slice(0,5),last5G=last5.reduce((n,m)=>n+Number(m.goals||0),0),last5A=last5.reduce((n,m)=>n+Number(m.assists||0),0),last5GA=last5G+last5A,honours=seasonHonours(scopeSeason,rows,p);
 const insights=[];
 if(goalStreak>=2)insights.push({kind:'hot',text:`${first} has scored in ${goalStreak} consecutive matches${goalStyle?` — ${goalStyle}.`:'.'}`});
 if(assistStreak>=2)insights.push({kind:'create',text:`${first} has assisted in ${assistStreak} consecutive matches.`});
 if(gaStreak>=3&&!goalStreak&&!assistStreak)insights.push({kind:'hot',text:`${first} has a goal contribution in ${gaStreak} straight matches.`});
 if(unbeaten>=4)insights.push({kind:'team',text:`${club||'The team'} are unbeaten in ${unbeaten} consecutive ${first} appearances.`});
 if(rated7>=3)insights.push({kind:'form',text:`${first} has been rated 7.0+ in ${rated7} straight matches.`});
 if(last5.length>=3&&last5GA>=3)insights.push({kind:'output',text:`${first} has ${last5GA} G/A in the last ${last5.length} matches.`});
 if(form.avg!=null)insights.push({kind:'form',text:`${form.label} · ${form.avg.toFixed(1)} average rating across the last ${form.count} rated matches.`});
 if(!insights.length&&rows.length)insights.push({kind:'neutral',text:`${first}'s latest ${Math.min(5,rows.length)} appearances are ready to review.`});
 return {rows,p,first,club,form,insights:insights.slice(0,4),goalStreak,assistStreak,gaStreak,unbeaten,rated7,last5GA,honours};
}
window.matchbookCareerPulseData=careerPulseData;
function pulseIcon(kind){return ({hot:'●',create:'↗',team:'◆',form:'▲',output:'＋',neutral:'•'})[kind]||'•'}
function careerPulseMarkup(id=season){
 const d=careerPulseData(id),f=d.form,formText=f.avg==null?f.label:`${f.label} · ${f.avg.toFixed(1)}`;
 const insights=d.insights.filter(x=>!x.text.startsWith(f.label));
 const honourItems=(d.honours?.items||[]).slice(0,4);
 const honoursMarkup=`<section class="career-awards-strip" aria-label="Honours and awards"><div class="career-awards-head"><small>HONOURS & AWARDS</small><b>${safe(d.honours?.summary||'Season honours and award races will appear here')}</b></div><div class="career-awards-list">${honourItems.length?honourItems.map(x=>`<span class="career-award-chip ${safe(x.tone)}" data-award-status="${safe(x.status||'')}"><strong>${safe(x.label)}</strong><small>${safe(x.detail)}</small></span>`).join(''):`<span class="career-award-chip empty"><strong>No honours yet</strong><small>Strong form and competition wins will appear here.</small></span>`}</div></section>`;
 return `<section class="career-pulse" aria-label="Current player form and streaks"><div class="career-pulse-form ${safe(f.tone)}"><span class="career-pulse-dot"></span><div><small>PLAYER FORM</small><b>${safe(formText)}</b></div>${f.trend?`<i class="career-form-trend ${safe(f.trend)}" title="Recent rating trend">${f.trend==='up'?'↗':f.trend==='down'?'↘':'→'}</i>`:''}</div><div class="career-pulse-insights">${(insights.length?insights:d.insights).slice(0,3).map(x=>`<span class="career-pulse-insight ${safe(x.kind)}"><i>${pulseIcon(x.kind)}</i>${safe(x.text)}</span>`).join('')}</div></section>${honoursMarkup}`;
}
window.matchbookCareerPulseMarkup=careerPulseMarkup;
function sidebarMarkup(id=season){
 const d=careerPulseData(id),p=d.p||{},s=db.seasons?.find(x=>x.id===id)||(typeof latestPlayerProfileSeason==='function'?latestPlayerProfileSeason():null)||{},t=id==='@career'?{m:d.rows.length,g:d.rows.reduce((n,m)=>n+Number(m.goals||0),0),a:d.rows.reduce((n,m)=>n+Number(m.assists||0),0)}:(typeof seasonTotals==='function'?seasonTotals(s):{m:d.rows.length,g:d.rows.reduce((n,m)=>n+Number(m.goals||0),0),a:d.rows.reduce((n,m)=>n+Number(m.assists||0),0)}),photo=typeof playerPhotoMarkup==='function'?playerPhotoMarkup('sidebar'):`<div class="sidebar-avatar">${safe(String(p.name||'P').split(/\s+/).map(w=>w[0]).slice(0,2).join(''))}</div>`;
 return `<div class="sidebar-career-card">${photo}<div class="sidebar-career-copy"><strong>${safe(p.name||'Player')}</strong><small>${safe([s.club||p.club,p.number?'#'+p.number:'',s.year||''].filter(Boolean).join(' · '))}</small><span>${t.m} apps · ${t.g}G · ${t.a}A</span></div></div>`;
}
window.matchbookSidebarMarkup=sidebarMarkup;
})();
