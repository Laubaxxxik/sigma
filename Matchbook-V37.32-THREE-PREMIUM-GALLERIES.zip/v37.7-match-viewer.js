/* Matchbook V37.7 — unified football match viewer.
   One recap surface for Matches, Records, Player, Statistics, Timeline and played Calendar fixtures.
   Uses recorded match/fixture/event data only. */
(function(){
  const VERSION='v37.7';

  function seasonYear(m){
    return String((db.seasons||[]).find(s=>s.id===m?.season)?.year||'').trim();
  }
  function linkedFixture(m){
    if(!m)return null;
    const fixtures=Array.isArray(db.calendarFixtures)?db.calendarFixtures:[];
    return fixtures.find(f=>f.id===m.calendarFixtureId||f.matchId===m.id)||null;
  }
  function careerClub(m){
    if(typeof v32CareerClub==='function')return v32CareerClub(m)||'';
    return String((db.seasons||[]).find(s=>s.id===m?.season)?.club||playerProfile?.().club||'').trim();
  }
  function teams(m){
    let home=String(m?.home||'').trim(),away=String(m?.away||'').trim();
    const club=careerClub(m),opponent=String(m?.opponent||'').trim();
    if(!home&&!away&&opponent){
      if((m.playerSide||m.venueType)==='away'){home=opponent;away=club}
      else{home=club;away=opponent}
    }
    return {home:home||'Home',away:away||'Away'};
  }
  function score(m){
    if(typeof calendarMatchScore==='function'){
      const s=calendarMatchScore(m);
      if(s)return {home:s.home,away:s.away,label:`${s.home}–${s.away}`};
    }
    const raw=String(m?.score||'').trim(),hit=raw.match(/(\d+)\s*[:–-]\s*(\d+)/);
    return hit?{home:Number(hit[1]),away:Number(hit[2]),label:`${hit[1]}–${hit[2]}`}:{home:'',away:'',label:raw||'—'};
  }
  function competition(m,f){
    const raw=String(m?.competitionName||m?.leagueName||m?.competitionType||m?.competition||f?.competitionName||f?.competitionType||'Match').trim();
    const parts=raw.split(/\s+·\s+/).filter(Boolean),name=parts[0]||'Match';
    const detail=String(m?.competitionDetail||f?.roundLabel||parts.slice(1).join(' · ')||'').trim();
    const year=seasonYear(m);
    return [name,detail,year].filter((x,i,a)=>x&&a.indexOf(x)===i).join(' · ');
  }
  function dateLabel(m,f){
    const raw=String(m?.date||f?.date||'').trim();
    if(!raw)return '';
    if(typeof v32DateLabel==='function')return v32DateLabel(raw);
    return raw;
  }
  function phase(m){
    const pens=typeof calendarShootout==='function'?calendarShootout(m):null;
    if(pens)return {label:'After penalties',detail:`Pens ${pens.home}–${pens.away}`};
    const aet=typeof calendarExtraTime==='function'&&calendarExtraTime(m);
    if(aet)return {label:'After extra time',detail:'AET'};
    return {label:'Full time',detail:'FT'};
  }
  function aggregate(m){
    const raw=typeof calendarMatchAggregateLabel==='function'?String(calendarMatchAggregateLabel(m)||'').trim():'';
    return raw?raw.replace(/^AGG\s*/i,'Agg '):'';
  }
  function tieOutcome(m){
    return typeof calendarMatchTieOutcomeLabel==='function'?String(calendarMatchTieOutcomeLabel(m)||'').trim():'';
  }
  function actionList(m){
    try{return typeof effectiveActions==='function'?effectiveActions(m?.actions||[]):(m?.actions||[])}catch{return m?.actions||[]}
  }
  function minute(e){
    const base=e?.minute??'';
    return `${base}${num(e?.added)?'+'+num(e.added):''}′`;
  }
  function scorerList(m,side){
    const goals=actionList(m).filter(e=>{
      try{return typeof isScoringEvent==='function'?isScoringEvent(e):['Goal','Penalty goal','Own goal'].includes(e?.type)}catch{return ['Goal','Penalty goal','Own goal'].includes(e?.type)}
    }).filter(e=>e.side===side);
    if(!goals.length)return '';
    return `<div class="v377-scorers">${goals.map(e=>`<span>${esc(e.player||'Scorer not specified')} <b>${esc(minute(e))}</b>${e.type==='Own goal'?'<em>(OG)</em>':''}</span>`).join('')}</div>`;
  }
  function matchMeta(m,f){
    const date=dateLabel(m,f),kickoff=String(f?.kickoff||m?.kickoff||'').trim(),venue=String(f?.venueName||m?.venueName||m?.stadium||'').trim();
    const parts=[];
    if(date)parts.push(`<span class="v377-meta-item"><i aria-hidden="true">▣</i>${esc(date)}${kickoff?`, ${esc(kickoff)}`:''}</span>`);
    if(venue)parts.push(`<span class="v377-meta-item"><i aria-hidden="true">⌂</i>${esc(venue)}</span>`);
    return parts.length?`<div class="v377-meta">${parts.join('')}</div>`:'';
  }
  function sourceLabel(){
    const labels={Matches:'Matches',Records:'Records',Calendar:'Calendar',Statistics:'Statistics','Player':'Player',Timeline:'Timeline',Media:'Media',International:'International'};
    return labels[typeof page!=='undefined'?page:'']||'Back';
  }
  function heroHtml(m){
    const f=linkedFixture(m),t=teams(m),s=score(m),p=phase(m),agg=aggregate(m),outcome=tieOutcome(m),comp=competition(m,f),back=sourceLabel();
    return `<section class="v377-match-hero" data-v377-match-hero data-match-id="${esc(m.id||'')}">
      <header class="v377-match-topbar">
        <button type="button" class="v377-back" data-v377-close aria-label="Close match"><span aria-hidden="true">‹</span><b>${esc(back)}</b></button>
        <div class="v377-competition">${typeof matchbookCompetitionBadge==='function'?matchbookCompetitionBadge(f||m,'tiny'):'<span class="v377-ball" aria-hidden="true">✦</span>'}<strong>${esc(comp)}</strong></div>
        <button type="button" class="v377-edit" data-v377-edit>Edit match</button>
      </header>
      ${matchMeta(m,f)}
      <div class="v377-scoreboard">
        <div class="v377-team v377-team-home">
          <div class="v377-team-line"><strong>${esc(t.home)}</strong>${clubBadge(t.home,'large')}</div>
          ${scorerList(m,'home')}
        </div>
        <div class="v377-score-centre">
          ${agg?`<span class="v377-aggregate">${esc(agg)}</span>`:''}
          <strong class="v377-score">${esc(s.label)}</strong>
          <span class="v377-phase">${esc(p.label)}</span>
          ${p.detail&&p.detail!=='FT'?`<small>${esc(p.detail)}</small>`:''}
          ${outcome?`<em class="v377-tie-outcome">${esc(outcome)}</em>`:''}
        </div>
        <div class="v377-team v377-team-away">
          <div class="v377-team-line">${clubBadge(t.away,'large')}<strong>${esc(t.away)}</strong></div>
          ${scorerList(m,'away')}
        </div>
      </div>
    </section>`;
  }
  function cleanupDuplicateHeader(form){
    form.querySelector('.v32-match-summary-score')?.remove();
    const hero=form.querySelector('[data-v377-match-hero]');
    form.querySelectorAll('.broadcast-fulltime .int-recap-context').forEach(node=>hero?.insertAdjacentElement('afterend',node));
    form.querySelectorAll('.broadcast-fulltime,.venue-banner').forEach(n=>n.remove());
  }
  function clearViewerClasses(){
    const modal=document.querySelector('#modal'),form=document.querySelector('#form');
    modal?.classList.remove('v377-match-view-modal');
    form?.classList.remove('v377-match-view-form');
  }
  function bindHero(form,m){
    const modal=document.querySelector('#modal');
    form.querySelector('[data-v377-close]')?.addEventListener('click',()=>{clearViewerClasses();modal?.close()});
    form.querySelector('[data-v377-edit]')?.addEventListener('click',()=>{clearViewerClasses();modal?.close();if(typeof editMatch==='function')editMatch(m)});
    modal?.addEventListener('close',clearViewerClasses,{once:true});
  }
  function enhanceMatchRecap(m){
    const form=document.querySelector('#form'),modal=document.querySelector('#modal');
    if(!form||!modal||!m)return;
    form.querySelector('[data-v377-match-hero]')?.remove();
    const centre=form.querySelector('.v32-match-centre');
    const anchor=form.querySelector('.match-top')||form.firstElementChild;
    if(!centre||!anchor)return;
    anchor.insertAdjacentHTML('beforebegin',heroHtml(m));
    cleanupDuplicateHeader(form);
    modal.classList.add('v377-match-view-modal');
    form.classList.add('v377-match-view-form');
    bindHero(form,m);
  }

  function calendarEntryFromKey(key){
    if(typeof calendarEntries!=='function')return null;
    return calendarEntries(season).find(e=>`${e.kind}:${e.id}`===key)||null;
  }
  function openCalendarEntry(key){
    const entry=calendarEntryFromKey(key);
    if(entry?.match&&typeof calendarEntryStatus==='function'&&calendarEntryStatus(entry)==='completed')return matchRecap(entry.match);
    if(typeof window.calendarOpenPreview==='function')return window.calendarOpenPreview(key);
  }
  function patchCalendarBinding(){
    if(typeof bindCalendarView!=='function'||bindCalendarView.__v377)return;
    const previous=bindCalendarView;
    const patched=function(root=document){
      previous(root);
      root.querySelectorAll?.('[data-calendar-preview]').forEach(button=>{
        button.onclick=()=>openCalendarEntry(button.dataset.calendarPreview);
      });
    };
    patched.__v377=true;
    bindCalendarView=patched;
    window.bindCalendarView=patched;
  }
  function polishCalendarCopy(){
    if(typeof page==='undefined'||page!=='Calendar')return;
    const p=document.querySelector('.calendar-v376-summary p');
    if(p)p.textContent='Played matches open Match Centre. Upcoming fixtures open the fixture sheet.';
  }
  function resetViewerClass(){
    const modal=document.querySelector('#modal');
    if(!modal?.open)clearViewerClasses();
  }

  function installMatchViewerV377(){
    if(window.MatchbookMatchViewerV377)return;
    window.MatchbookMatchViewerV377={version:VERSION,enhanceMatchRecap,openCalendarEntry};
    if(typeof registerHook==='function'){
      registerHook('afterMatchRecap',enhanceMatchRecap,80);
      registerHook('afterRenderComplete',()=>{polishCalendarCopy();resetViewerClass()},10);
    }
    patchCalendarBinding();
  }

  installMatchViewerV377();
  if(typeof page!=='undefined'&&page==='Calendar'&&typeof render==='function')render();
})();
