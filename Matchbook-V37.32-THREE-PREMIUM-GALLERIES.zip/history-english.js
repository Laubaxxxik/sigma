/* Standard football names and recognised dates in historical text.
   Presentation only: career records, IDs, backups and form values stay original. */
(function(root){
  'use strict';
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const monthAliases = [
    ['stycznia','styczeń','styczen','sty'], ['lutego','luty','lut'], ['marca','marzec','mar'],
    ['kwietnia','kwiecień','kwiecien','kwi'], ['maja','maj'], ['czerwca','czerwiec','cze'],
    ['lipca','lipiec','lip'], ['sierpnia','sierpień','sierpien','sie'],
    ['września','wrzesnia','wrzesień','wrzesien','wrz'],
    ['października','pazdziernika','październik','pazdziernik','paź','paz'],
    ['listopada','listopad','lis'], ['grudnia','grudzień','grudzien','gru']
  ];
  const monthIndex = new Map(monthAliases.flatMap((aliases,index)=>aliases.map(alias=>[alias,index+1])));
  const league = '(?:liga|ligi|ligę|lige|lidze|ligą)';
  const competitions = [
    [league+'\\s+konferencji(?:\\s+europy)?', 'Conference League'],
    [league+'\\s+mistrz(?:ów|ow)', 'Champions League'],
    [league+'\\s+europy', 'Europa League'],
    [league+'\\s+narod(?:ów|ow)', 'Nations League'],
    ['superpuchar(?:u|ze|em)?\\s+europy', 'UEFA Super Cup'],
    ['superpuchar(?:u|ze|em)?\\s+polski', 'Polish Super Cup'],
    ['superpuchar(?:u|ze|em)?\\s+krajow(?:y|ego|ym)', 'Domestic Super Cup'],
    ['puchar(?:u|ze|em)?\\s+polski', 'Polish Cup'],
    ['puchar(?:u|ze|em)?\\s+ligi', 'League cup'],
    ['puchary\\s+krajowe', 'Domestic cups'],
    ['puchar(?:u|ze|em)?\\s+krajow(?:y|ego|ym)', 'Domestic cup'],
    ['mistrzostw(?:a|ach|om)?\\s+świata', 'World Cup'],
    ['mistrzostw(?:a|ach|om)?\\s+swiata', 'World Cup'],
    ['mistrzostw(?:a|ach|om)?\\s+europy', 'European Championship']
  ].map(([pattern,name])=>({pattern:new RegExp('(^|[^\\p{L}\\p{N}_])(?:(UEFA)\\s+)?'+pattern+'(?=$|[^\\p{L}\\p{N}_])','giu'),name}));
  const writtenDate = new RegExp('(^|[^\\p{L}\\p{N}])(\\d{1,2})\\.?\\s+('+[...monthIndex.keys()].join('|')+')\\.?\\s+(\\d{4})(?:\\s+(?:r\\.?|roku))?(?=$|[^\\p{L}\\p{N}])','giu');
  const dayFirstDate = /(^|[^\p{L}\p{N}])(\d{1,2})([./])(\d{1,2})\3(\d{4})(?=$|[^\p{L}\p{N}])/gu;
  const isoDate = /(^|[^\p{L}\p{N}])(\d{4})-(\d{2})-(\d{2})(?=$|[^\p{L}\p{N}])/gu;

  function dateText(year,month,day,compact=false){
    year=Number(year);month=Number(month);day=Number(day);
    if(year<1000||year>9999||month<1||month>12||day<1||day>31)return null;
    const date=new Date(Date.UTC(year,month-1,day));
    if(date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return null;
    return `${day} ${compact?months[month-1].slice(0,3):months[month-1]} ${year}`;
  }

  function translatePart(text,compact){
    for(const {pattern,name} of competitions){
      text=text.replace(pattern,(_match,prefix,uefa)=>prefix+(uefa&&!name.startsWith('UEFA ')?'UEFA ':'')+name);
    }
    text=text.replace(writtenDate,(original,prefix,day,month,year)=>{
      const value=dateText(year,monthIndex.get(month.toLowerCase()),day,compact);
      return value?prefix+value:original;
    });
    text=text.replace(dayFirstDate,(original,prefix,day,_separator,month,year)=>{
      const value=dateText(year,month,day,compact);return value?prefix+value:original;
    });
    return text.replace(isoDate,(original,prefix,year,month,day)=>{
      const value=dateText(year,month,day,compact);return value?prefix+value:original;
    });
  }

  function text(value,{compact=false}={}){
    if(typeof value!=='string')return value;
    // Clip links and other URLs must stay byte-for-byte unchanged.
    return value.split(/((?:https?:\/\/|www\.)[^\s<>"']+)/gi).map((part,index)=>index%2?part:translatePart(part,compact)).join('');
  }

  function localiseElement(element){
    if(!element)return;
    const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);
    const nodes=[];
    for(let node=walker.nextNode();node;node=walker.nextNode())nodes.push(node);
    for(const node of nodes){
      const parent=node.parentElement;
      if(!parent||parent.closest('input,textarea,select,option,script,style,code,pre,[contenteditable]'))continue;
      const compact=!!parent.closest('time,.fm-match-date,.calendar-date,.calendar-meta-line,.shot-detail-date,.v34-match-main small');
      const translated=text(node.nodeValue,{compact});
      if(translated!==node.nodeValue)node.nodeValue=translated;
    }
    // Translating an option's label must not change the value used by filters/forms.
    for(const option of element.querySelectorAll('option')){
      const translated=text(option.textContent,{compact:true});
      if(translated!==option.textContent){const value=option.value;option.value=value;option.textContent=translated;}
    }
  }

  function localiseRenderedText(){
    for(const selector of ['#content','#modal','#player-search-dialog'])localiseElement(document.querySelector(selector));
  }

  function install(){
    for(const name of ['render','modal','matchRecap','liveBoard','liveSetup','openSequenceEditor','openStoryStudio','openPlayerPicker']){
      const previous=root[name];
      if(typeof previous!=='function')continue;
      root[name]=function(...args){const result=previous.apply(this,args);localiseRenderedText();return result;};
    }
    for(const name of ['context','liveReport']){
      const previous=root[name];
      if(typeof previous==='function')root[name]=function(...args){return text(previous.apply(this,args));};
    }
    const previousCopy=root.copy;
    if(typeof previousCopy==='function')root.copy=function(value){return previousCopy.call(this,text(value));};
    const pretty=root.fmPrettyDate;
    if(typeof pretty==='function')root.fmPrettyDate=function(value){return text(pretty(value),{compact:true});};
    let queued=false;
    function scheduleLocalisation(event){
      if(!event.target.closest?.('#content,#modal,#player-search-dialog')||queued)return;
      queued=true;queueMicrotask(()=>{queued=false;localiseRenderedText();});
    }
    document.addEventListener('click',scheduleLocalisation);
    document.addEventListener('keydown',event=>{
      if(!['Enter','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key)||event.target.closest?.('input,textarea,select,[contenteditable]'))return;
      scheduleLocalisation(event);
    });
    localiseRenderedText();
  }

  root.MatchbookEnglish={text,dateText,localiseRenderedText};
  if(typeof module!=='undefined'&&module.exports)module.exports={text,dateText};
  if(typeof document!=='undefined')install();
})(typeof window!=='undefined'?window:globalThis);
