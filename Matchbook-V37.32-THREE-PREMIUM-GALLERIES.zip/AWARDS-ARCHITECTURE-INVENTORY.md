# Awards architecture inventory

Inspected before implementation: the supplied ZIP contains a static, global-script application, not a React project. `index.html` determines extension order. No package manifest or external test runner was supplied.

| Area | Existing implementation | V4 treatment |
|---|---|---|
| Award definitions, season review, closing | `awards-v3717.js` | Retained; no new competing ceremony registry |
| Award room, nominations and controls | `awards-v3719.js` | Retained behind Individual Awards |
| Ceremony evaluation and snapshots | `awards-v3722.js` | Retained; score/rank/canWin outcomes are legacy simulation records, not new V4 assessment results |
| Existing analytical model | `awards-outlook-v3726.js` | Reuse canonical rows, deduplication, season totals, snapshots, consistency, team and European evidence; replace coarse analytical award scoring with the V4 engine |
| Previous Trophy Room | `awards-trophy-room-v3726.js`, `matchbook-trophy-v3730.js` | Retain navigation/history/cabinet; use two-organization V4 overview |
| Evidence modal | `matchbook-awards-evidence-v3728.js` | Same report as gallery; add bounded score, components, gates, thresholds, scoped totals |
| Big Matches | `matchbook-big-matches-v3728.js` | Shared classifier reused; appearing in an important game is distinct from performing well |
| Seasons | `matchbook-seasons-v3728.js` | Preserve existing management; add independent per-competition ranking editing |
| Match statistics | `quality.js`, `engine.js`, `statistics-plus.js`, `tracking.js`, `analytics.js` | Reuse match views, player matcher and action statistics; respect metric observation coverage |
| Shot coordinates / attributes | `statistics-plus.js`, `tracking.js`, `action-creator-v3719.js` | Reuse markers and saved geometry; extend technique choices additively |
| Save / import / recovery | `quality.js`, `architecture.js`, `season-profiles.js` | Keep authorized local storage, safety snapshots and migrations; validate additive V4 fields |
| Durable device mirror | `matchbook-persistence-v3729.js` | Retained unchanged |
| Cloud synchronization | `cloud.js` | Retained unchanged; V4 fields travel in the same career JSON |
| Other career systems | calendar, international, profile, squads, history, transfers, match workspace | All JavaScript checked for syntax; existing regression suite and relevant browser flows executed |

Existing awards included Ballon d'Or, FIFA The Best, Kopa, European Golden Shoe, domestic and UCL Player of the Season, and Playmaker of the Year. Gerd Müller, Yashin and Puskás lacked these dedicated V4 analytical views/models.

The old read-only outlook used small integer evidence counts and coarse appearance/rating bands, rather than the requested 0–100 component model. That analytical code has been removed in favor of the V4 implementation. The legacy ceremony engine remains separate because it owns existing nominations, inbox notifications, snapshots and resolved results. Its threshold-generated ranks cannot establish an official worldwide result.

Available evidence includes counted match IDs, dates, competition names/types, goals, assists, ratings, minutes, player-attributed action events, observed chance/defensive metrics, explicit competition results and locked historical snapshots. Missing comparative world leaderboards, edition rules, historical competition splits and goalkeeper coverage are not fabricated.

New fields belong to the existing season object: `competitionRankingsV4`, `awardRulesV4`, `awardResultsV4`. They do not replace `awardsV3717`, snapshots, match/event IDs or any ceremony result.
