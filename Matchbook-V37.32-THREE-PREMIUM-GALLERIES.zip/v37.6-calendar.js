/* Matchbook V37.6 — calendar month redesign + fixture preview sheet.
   Presentation only: existing fixtures, matches and actions remain the source of truth. */
(function(){
  const entryKey=e=>`${e.kind}:${e.id}`;
  const findEntry=key=>calendarEntries(season).find(e=>entryKey(e)===key)||null;
  const teamName=(e,side)=>String(e?.[side]||e?.fixture?.[side]||e?.match?.[side]||'').trim();
  const matchScore=e=>{
    const status=calendarEntryStatus(e);
    if(status==='completed'&&e.match)return calendarMatchScoreDisplay(e.match)||calendarScoreText(e)||'—';
    if(status==='in_progress'&&e.fixture&&db.draft?.calendarFixtureId===e.fixture.id){const s=liveScore(db.draft);return `${s[0]}–${s[1]}`}
    return '';
  };
  const shortCompetition=e=>{
    const name=String(e.competitionName||e.competitionType||'Match').trim();
    const aliases={'Champions League':'UCL','Europa League':'UEL','Conference League':'UECL','Domestic cup':'Cup','League cup':'League Cup','Super cup':'Super Cup'};
    return aliases[name]||name;
  };
  const perspective=e=>{
    const club=calendarSeasonClub(e.fixture?.season||e.match?.season||season);
    if(!club)return '';
    if(sameClub(teamName(e,'home'),club))return 'Home';
    if(sameClub(teamName(e,'away'),club))return 'Away';
    return e.fixture?.fixtureVenue==='neutral'||e.match?.venueType==='neutral'?'Neutral':'';
  };
  const fixtureVenue=e=>{
    const f=e.fixture||{},m=e.match||{};
    return String(f.venueName||m.venueName||m.stadium||'').trim();
  };
  const playerPerformance=e=>{
    const m=e.match;if(!m)return '';
    const rating=suppliedNumber(m.rating),mins=suppliedNumber(m.minutes),pos=m.position||m.playerPosition||m.role||'—';
    return `<section class="calendar-preview-performance"><div><small>MINUTES</small><b>${mins===null?'—':Math.round(mins)+'′'}</b></div><div><small>GOALS</small><b>${num(m.goals)}</b></div><div><small>ASSISTS</small><b>${num(m.assists)}</b></div><div><small>RATING</small><b class="${rating!==null&&rating>=8?'excellent':rating!==null&&rating>=7?'good':rating!==null&&rating<6.5?'low':''}">${rating===null?'—':rating.toFixed(1)}</b></div><div><small>POSITION</small><b>${esc(pos)}</b></div></section>`;
  };
  function tiePreview(e){
    if(!e.tieId)return '';
    const state=calendarTieState(e,{includeLive:true});
    if(!state)return '';
    const rows=state.rows||[];
    const cards=rows.map(r=>{const m=calendarDirectMatch(r)||calendarLinkedMatch(r),score=m?calendarMatchScoreDisplay(m):'',label=r.leg==='first'?'1ST LEG':r.leg==='second'?'2ND LEG':'LEG';return `<div class="calendar-preview-leg ${r.id===e.fixture?.id?'current':''}"><span>${label}</span><b>${esc(r.home)} ${score?`<strong>${esc(score)}</strong>`:'<em>vs</em>'} ${esc(r.away)}</b></div>`}).join('');
    const agg=calendarTieAggregateLabel(e),outcome=calendarTieOutcomeLabel(e);
    return `<section class="calendar-preview-tie"><header><span>TWO-LEG TIE</span>${agg?`<b>${esc(agg)}</b>`:''}</header>${cards}${outcome?`<p>${esc(outcome)}</p>`:''}</section>`;
  }
  function previewActions(e){
    const status=calendarEntryStatus(e),f=e.fixture,m=e.match;
    const rows=[];
    if(status==='scheduled'&&f){rows.push(['Start match',`calendar-start:${f.id}`,'primary'],['Enter result',`calendar-result:${f.id}`,''],['Edit fixture',`calendar-edit:${f.id}`,'']);}
    else if(status==='in_progress'&&f){rows.push(['Continue match','live','primary'],['Edit fixture',`calendar-edit:${f.id}`,'']);}
    else if(status==='completed'&&m){rows.push(['Match summary',`recap:${m.id}`,'primary']);if(f)rows.push(['Edit fixture',`calendar-edit:${f.id}`,'']);}
    else if(f){rows.push([status==='postponed'?'Reschedule':'Fixture details',`calendar-edit:${f.id}`,'primary']);}
    return rows.map(([label,action,cls])=>`<button type="button" class="${cls}" data-calendar-preview-action="${esc(action)}">${esc(label)}</button>`).join('');
  }
  function calendarOpenPreviewV376(key){
    const e=findEntry(key);if(!e)return toast('Calendar entry not found');
    const f=e.fixture||{},m=e.match||{},status=calendarEntryStatus(e),home=teamName(e,'home')||'Home',away=teamName(e,'away')||'Away',score=matchScore(e),rawDate=calendarStoredDate(e.date)||calendarDate(e.date)||'',compact=calendarCompactDate(rawDate),date=rawDate?`${compact.day} ${compact.rest}`:'Date TBC',competition=e.competitionName||e.competitionType||'Match',round=calendarDenseRoundV27(e)||calendarRoundMeta(e)||'',venue=fixtureVenue(e),view=perspective(e),agg=calendarTieAggregateLabel(e),outcome=e.leg==='second'?calendarTieOutcomeLabel(e):'',kickoff=f.kickoff||'',shoot=m?calendarShootout(m):null,extra=m?calendarExtraTime(m):false;
    const middle=status==='scheduled'?`<strong>${esc(kickoff||'VS')}</strong><small>${esc(calendarStatusLabel(status))}</small>`:`<strong>${esc(score||'—')}</strong><small>${shoot?`PENS ${shoot.home}–${shoot.away}`:extra?'AET':esc(calendarStatusLabel(status))}</small>`;
    const details=[
      ['Date',date],['Kick-off',kickoff||'—'],['Venue',venue||'—'],['Player side',view||'—'],['Competition',competition],['Stage',round||'—']
    ];
    if(e.leg)details.push(['Tie leg',e.leg==='first'?'1st leg':'2nd leg']);
    if(agg)details.push(['Aggregate',agg.replace(/^AGG\s*/i,'')]);
    if((f.specialTags||m.specialTags||[]).length)details.push(['Context',(f.specialTags||m.specialTags||[]).join(' · ')]);
    const modal=document.querySelector('#modal'),form=document.querySelector('#form');
    modal.classList.remove('match-modal','recap-modal','squad-modal','sequence-modal','v34-setup-modal','v34-live-modal');
    modal.classList.add('calendar-preview-modal');
    form.oninput=form.onchange=form.onkeydown=form.onsubmit=null;
    form.innerHTML=`<section class="calendar-preview-sheet">
      <header class="calendar-preview-header"><div><span class="calendar-preview-kicker">${typeof matchbookCompetitionBadge==='function'?matchbookCompetitionBadge(e,'small'):''}<span>${esc(competition)}</span></span><h2>${esc(round||'Fixture')}</h2></div><button type="button" class="calendar-preview-close" aria-label="Close">×</button></header>
      <div class="calendar-preview-statusline"><span class="calendar-preview-date">${esc(date)}${kickoff?' · '+esc(kickoff):''}</span>${calendarStatusBadge(status)}</div>
      <section class="calendar-preview-scoreboard">
        <div class="calendar-preview-team">${clubBadge(home,'large')}<b>${esc(home)}</b><small>HOME</small></div>
        <div class="calendar-preview-centre">${agg?`<span>${esc(agg)}</span>`:''}${middle}${outcome?`<p>${esc(outcome)}</p>`:''}</div>
        <div class="calendar-preview-team">${clubBadge(away,'large')}<b>${esc(away)}</b><small>AWAY</small></div>
      </section>
      <section class="calendar-preview-details">${details.map(([k,v])=>`<div><small>${esc(k)}</small><b>${esc(v)}</b></div>`).join('')}</section>
      ${tiePreview(e)}
      ${playerPerformance(e)}
      ${f.note?`<section class="calendar-preview-note"><small>FIXTURE NOTE</small><p>${esc(f.note)}</p></section>`:''}
      <footer class="calendar-preview-actions"><button type="button" data-calendar-preview-close>Close</button>${previewActions(e)}</footer>
    </section>`;
    const close=()=>{modal.close();modal.classList.remove('calendar-preview-modal')};
    form.querySelector('.calendar-preview-close').onclick=close;
    form.querySelector('[data-calendar-preview-close]').onclick=close;
    form.querySelectorAll('[data-calendar-preview-action]').forEach(b=>b.onclick=()=>{const a=b.dataset.calendarPreviewAction;close();act(a)});
    modal.showModal();
  }
  window.calendarOpenPreview=calendarOpenPreviewV376;

  calendarMonthGrid=function(key,entries){
    if(key==='unknown')return `<section class="calendar-month calendar-month-v376"><div class="calendar-month-nav"><span></span><h2>Date TBC</h2><span></span></div><div class="calendar-list">${entries.map(calendarRow).join('')}</div></section>`;
    const [year,month]=key.split('-').map(Number),days=new Date(Date.UTC(year,month,0)).getUTCDate(),first=new Date(Date.UTC(year,month-1,1)).getUTCDay(),offset=(first+6)%7,byDay=new Map();
    for(const e of entries){const d=calendarStoredDate(e.date);if(!d)continue;const day=Number(d.slice(8,10));if(!byDay.has(day))byDay.set(day,[]);byDay.get(day).push(e)}
    let cells='';
    for(let i=0;i<offset;i++)cells+='<div class="calendar-cell outside" aria-hidden="true"></div>';
    for(let day=1;day<=days;day++){
      const rows=byDay.get(day)||[],more=Math.max(0,rows.length-3),visible=rows.slice(0,3);
      cells+=`<div class="calendar-cell ${rows.length?'has-match':''}"><div class="calendar-day-head"><span class="calendar-day">${day}</span>${rows.length?`<small>${rows.length} match${rows.length===1?'':'es'}</small>`:''}</div>${visible.map(e=>{
        const status=calendarEntryStatus(e),opp=calendarOpponent(e),score=matchScore(e),meta=calendarDenseRoundV27(e),aggregate=calendarTieAggregateLabel(e),outcome=e.match?calendarOutcome(e.match,calendarSeasonClub(e.match.season)):'';
        return `<button type="button" class="calendar-event-tile status-${esc(status)} ${calendarResultClass(outcome)} ${e.tieId?'two-leg-tie':''}" data-calendar-preview="${esc(entryKey(e))}" title="${esc(calendarFixtureLabel(e.fixture||e))}"><span class="calendar-event-crest">${clubBadge(opp)}</span><span class="calendar-event-copy"><b>${esc(opp)}</b><small>${typeof matchbookCompetitionBadge==='function'?matchbookCompetitionBadge(e,'tiny'):''}<span>${esc(shortCompetition(e))}${meta?' · '+esc(meta):''}</span></small></span><span class="calendar-event-result">${aggregate?`<i>${esc(aggregate)}</i>`:''}${score?`<strong>${esc(score)}</strong>`:`<em>${esc((e.fixture?.kickoff||calendarStatusLabel(status)).toUpperCase())}</em>`}</span></button>`;
      }).join('')}${more?`<button type="button" class="calendar-more-day" data-calendar-day-list="${day}">+${more} more</button>`:''}</div>`;
    }
    return `<section class="calendar-month calendar-month-v376"><div class="calendar-month-top"><div class="calendar-month-nav"><button type="button" data-calendar-month="-1" aria-label="Previous month">←</button><div><span>SEASON CALENDAR</span><h2>${esc(calendarMonthName(key))}</h2></div><button type="button" data-calendar-month="1" aria-label="Next month">→</button></div><div class="calendar-month-legend"><span><i class="scheduled"></i>Scheduled</span><span><i class="completed"></i>Played</span><span><i class="tie"></i>Two-leg tie</span></div></div><div class="calendar-weekdays">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<span>${x}</span>`).join('')}</div><div class="calendar-grid">${cells}</div></section>`;
  };

  calendarRow=function(e){
    const status=calendarEntryStatus(e),date=calendarCompactDate(e.date),opponent=calendarOpponent(e),venue=e.fixture?calendarFixtureVenueLabel(e.fixture,e):(e.match?.venueType==='neutral'?'Neutral':e.match?.playerSide==='away'?'Away':'Home'),score=matchScore(e),round=calendarDenseRoundV27(e),aggregate=calendarTieAggregateLabel(e),outcome=e.match?calendarOutcome(e.match,calendarSeasonClub(e.match.season)):'';
    return `<button type="button" data-calendar-key="${esc(entryKey(e))}" data-calendar-preview="${esc(entryKey(e))}" class="calendar-row calendar-row-v376 status-${esc(status)} ${calendarResultClass(outcome)} ${e.tieId?'two-leg-tie':''}"><span class="calendar-date"><b>${esc(date.day)}</b><small>${esc(date.rest)}</small>${e.fixture?.kickoff?`<em>${esc(e.fixture.kickoff)}</em>`:''}</span><span class="calendar-opponent-crest">${clubBadge(opponent)}</span><span class="calendar-main"><span class="calendar-opponent-line"><strong>${esc(opponent)}</strong>${outcome?`<i class="calendar-outcome ${calendarResultClass(outcome)}">${esc(outcome)}</i>`:''}</span><small>${esc(e.competitionName||e.competitionType||'Match')}${round?' · '+esc(round):''} · ${esc(venue)}</small></span><span class="calendar-state">${aggregate?`<small class="calendar-aggregate">${esc(aggregate)}</small>`:''}${score?`<strong class="calendar-score">${esc(score)}</strong>`:calendarStatusBadge(status)}<i>›</i></span></button>`;
  };

  calendarView=function(){
    const entries=calendarEntries(),sum=calendarSummary(entries),key=calendarMonthCursorBySeason[season]||calendarDefaultMonth(entries);calendarMonthCursorBySeason[season]=key;
    const visible=entries.filter(e=>calendarStoredDate(e.date)?.slice(0,7)===key),undated=entries.filter(e=>!calendarStoredDate(e.date));
    const upcoming=visible.filter(e=>calendarEntryStatus(e)==='scheduled').length,played=visible.filter(e=>calendarEntryStatus(e)==='completed').length;
    return title('Calendar',selectSeason()+btn('+ Add fixture','calendar-new','primary')+btn('+ Two-leg tie','calendar-tie')+btn('Bulk add','calendar-bulk'))+
      `<section class="calendar-v376-summary"><div><span>THIS MONTH</span><b>${visible.length}</b><small>fixtures</small></div><div><span>PLAYED</span><b>${played}</b><small>completed</small></div><div><span>UPCOMING</span><b>${upcoming}</b><small>scheduled</small></div><div><span>SEASON</span><b>${sum.W}-${sum.D}-${sum.L}</b><small>W-D-L</small></div><p>Click any match in the calendar to open its fixture sheet.</p></section>`+
      calendarMonthGrid(key,visible)+
      `<section class="calendar-month-fixtures"><div class="section-heading"><div><span class="overline">${esc(calendarMonthName(key).toUpperCase())}</span><h2>Month fixtures</h2></div><small>Open a match for full details</small></div>${visible.length?visible.map(calendarRow).join(''):'<div class="panel empty">No matches in this month.</div>'}</section>`+
      (undated.length?`<section class="calendar-month-fixtures"><div class="section-heading"><div><span class="overline">DATE TBC</span><h2>Unscheduled fixtures</h2></div></div>${undated.map(calendarRow).join('')}</section>`:'');
  };

  bindCalendarView=function(root=document){
    root.querySelectorAll?.('[data-calendar-month]').forEach(b=>b.onclick=()=>{calendarMonthCursorBySeason[season]=calendarShiftMonth(calendarMonthCursorBySeason[season]||calendarDefaultMonth(calendarEntries()),num(b.dataset.calendarMonth));render()});
    root.querySelectorAll?.('[data-calendar-preview]').forEach(b=>b.onclick=()=>calendarOpenPreviewV376(b.dataset.calendarPreview));
    root.querySelectorAll?.('[data-calendar-day-list]').forEach(b=>b.onclick=()=>{const day=Number(b.dataset.calendarDayList),prefix=(calendarMonthCursorBySeason[season]||'')+'-'+String(day).padStart(2,'0'),match=calendarEntries().find(e=>calendarStoredDate(e.date)===prefix);if(!match)return;const row=root.querySelector(`[data-calendar-key="${entryKey(match)}"]`);row?.scrollIntoView?.({behavior:'smooth',block:'center'});row?.classList.add('calendar-flash');setTimeout(()=>row?.classList.remove('calendar-flash'),900)});
  };

  // V34/V35 may already have rendered before this file loads.
  if(typeof page!=='undefined'&&page==='Calendar'&&typeof render==='function')render();
})();
