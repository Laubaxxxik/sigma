/* V37.29 — Durable, additive IndexedDB career mirror.
   Existing verified local save remains authoritative. Never silently overwrite it.
   A valid IndexedDB copy restores a lost/empty local save before the UI starts.
   This is device-local only; cloud.js remains responsible for cross-device sync. */
(function(root,factory){
 const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.MatchbookPersistenceV3729=api;
})(typeof window!=='undefined'?window:globalThis,function(root){
 'use strict';
 const DB='matchbook-career-durable-v3729',STORE='snapshots',SEASON='matchbook-selected-season-v3729';
 function open(){return new Promise((resolve,reject)=>{
  if(!root?.indexedDB)return reject(Error('IndexedDB is unavailable'));
  let request;try{request=root.indexedDB.open(DB,1);}catch(err){return reject(err)}
  request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains(STORE))request.result.createObjectStore(STORE,{keyPath:'id'})};
  request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||Error('Cannot open IndexedDB'));
 });}
 async function read(){const db=await open();try{return await new Promise((resolve,reject)=>{
  const tx=db.transaction(STORE,'readonly'),req=tx.objectStore(STORE).get('primary');
  req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error||Error('Cannot read saved career'));
 });}finally{db.close()}}
 async function write(career,season){
  if(!career||!Array.isArray(career.matches)||!Array.isArray(career.seasons))throw Error('Invalid career mirror input');
  // Serialize before opening a transaction so the saved data cannot change halfway through.
  const payload=JSON.stringify(career),row={id:'primary',at:new Date().toISOString(),payload,season:season||''};
  const db=await open();try{await new Promise((resolve,reject)=>{
   const tx=db.transaction(STORE,'readwrite');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('IndexedDB write failed'));
   tx.onabort=()=>reject(tx.error||Error('IndexedDB write aborted'));
   tx.objectStore(STORE).put(row);
  });return {savedAt:row.at,bytes:payload.length}}
  finally{db.close()}
 }
 function hasCareer(c){return !!(c&&Array.isArray(c.seasons)&&Array.isArray(c.matches)&&(c.seasons.length||c.matches.length||c.profile?.name&&c.profile.name!=='My player'));}
 function savedSeason(){try{return root.localStorage?.getItem(SEASON)||''}catch{return ''}}
 function saveSelection(s){if(!s||s==='@career')return;try{root.localStorage?.setItem(SEASON,String(s))}catch{/* Keep in-memory selection. */}}
 async function restoreIfNeeded(local,validate){
  try{
   const entry=await read();if(!entry?.payload)return {status:'no-mirror'};
   let parsed;try{parsed=JSON.parse(entry.payload)}catch{return {status:'corrupt-mirror'}}
   if(!hasCareer(parsed)||typeof validate==='function'&&!validate(parsed))return {status:'invalid-mirror'};
   if(hasCareer(local))return {status:'local-preferred'};
   return {status:'restored',career:parsed,season:entry.season||savedSeason()};
  }catch(err){return {status:'unavailable',error:String(err?.message||err)}}
 }
 return Object.freeze({read,write,restoreIfNeeded,savedSeason,saveSelection,hasCareer});
});
