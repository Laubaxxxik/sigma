# Matchbook V37.27 — Simplified Event Creator

**What changed:** The light Match History / Maker now uses one primary action selector; penalties use the automatic 11m spot with the original interactive goal-mouth, and unnecessary shortcut buttons were removed. Goals and penalty outcomes use normal event types plus contextual attributes. Existing event IDs and backwards-compatible statistical semantics are preserved.

**Upgrade:** First export the career JSON. Deploy this ZIP to a Vercel Preview, verify a new penalty and an older saved match, then switch to production. Historical legacy penalty conversion is optional and must be confirmed; it creates an application restore point. Do not rely on that restore point as the sole external backup.

**Tests:** Production ZIP does not contain development tests. See the companion `Matchbook-V37.27-QA.md` for executed test scope and limitations.
