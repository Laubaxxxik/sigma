# Matchbook V37.31 · Awards V4

This is a complete static application update over the supplied V37.30 ZIP. Keep all files together and serve the directory over HTTP, or deploy the root to your existing Vercel project. The existing `api/` routes are retained. No new backend or account is required.

## Use

- Open **Awards → Overview**, then **France Football** or **FIFA**.
- **View Analysis** opens the score, components, gates, thresholds, supporting matches and limitations.
- **Edition rules** records the actual edition's eligibility dates, age cutoff where applicable, rule source and voting metadata. Unverified editions remain explicitly marked.
- **Record result** stores an official/manual confirmation or explicitly simulated outcome independently of the internal assessment and old ceremonies.
- In **Your Seasons → Season details → Competition Rankings**, edit each competition's Top Scorers and Top Assists positions. Blank means not recorded. Unranked and current/final are explicit.
- Golden Shoe requires a season-specific, sourced coefficient. Its points include only recorded domestic league goals.
- **FIFA → Puskás Goal Analysis** explains recorded goal candidates and reuses the saved Shot Map / Goal Mouth markers. Add unusual techniques through the existing Action Creator.
- Download a JSON backup before updating your deployed files. The update does not replace career data or rewrite saved award results.

## Verification

Run the pure-engine and data regression suite with Node 20+:

```sh
node --test tests/awards-v4.test.cjs
```

The browser integration test starts its own temporary HTTP server. Install Playwright in your development environment, then run:

```sh
node tests/ui-flow.cjs
```

It uses `/usr/bin/chromium` if available. Set `CHROMIUM_PATH` to another installed Chromium binary, or use Playwright's installed browser. Screenshots are written to `/tmp` by default; set `SCREENSHOT_DIR` to an existing directory to retain them elsewhere.

See `IMPLEMENTATION-REPORT-V4.md` for models, audit findings, test results and limitations.
