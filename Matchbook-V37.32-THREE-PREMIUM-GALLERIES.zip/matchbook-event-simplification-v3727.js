/* Matchbook V37.27 — simplified event input, with a backward-compatible event engine.
 * No new database, no inferred historical coordinates, and no duplicate actions.
 * 'Card' is a UI category; cards are persisted under existing disciplinary types.
 * Goal + Penalty and Goal + Direct Free Kick are canonical shot event records.
 */
(function(){
'use strict';
const HIDDEN_LEGACY = new Set(['Penalty goal','Penalty missed','Yellow card','Second yellow card','Red card','Inaccurate pass','Successful dribble','Failed dribble','Dribble attempt']);
const SHOT = new Set(['Goal','Penalty goal','Shot','Shot on target','Shot off target','Blocked shot','Post','Crossbar','Big chance missed','Penalty missed']);
const PEN_X = Number((100*(105-11)/105).toFixed(6)); // x: attacking progress %, opponent goal at 100.
const PEN_Y = 50;                                 // y: lateral %, centre of the pitch.
const modal = ()=>document.querySelector('#modal');
const form = ()=>document.querySelector('#form');
const editable = ()=>form()?.querySelector('.mh-stage');
const value = (name)=>form()?.elements.namedItem(name)?.value||'';
const storedEvent = ()=>{const i=Number(form()?.dataset.editIndex??-1);return Number.isInteger(i)&&i>=0?(db.draft?.actions||[])[i]||null:null};
const equivalent = (e)=>{
 if(!e) return null;
 if(e.type==='Penalty goal')return 'Goal';
 if(e.type==='Penalty missed') {
   if(e.shot?.outcome==='saved'||e.shot?.outcome==='target')return 'Shot on target';
   if(e.shot?.outcome==='off')return 'Shot off target';
   if(e.shot?.outcome==='post')return 'Post';
   if(e.shot?.outcome==='bar')return 'Crossbar';
   return null; // Ambiguous historical outcome: keep editable legacy entry.
 }
 if(['Yellow card','Second yellow card','Red card'].includes(e.type))return 'Card';
 if(e.type==='Inaccurate pass')return 'Pass';
 if(['Successful dribble','Failed dribble','Dribble attempt'].includes(e.type))return 'Dribble';
 return null;
};
// Keep legacy select options in the DOM for old records and plugins, but do not
// offer them as NEW events. Their values remain recognized by all old readers.
if(typeof eventChoices==='function'){
 const oldChoices=eventChoices;
 eventChoices=function(...args){
  let html=oldChoices(...args);
  for(const type of HIDDEN_LEGACY){
    const token=`<option value="${type}">`;
    html=html.replace(token,`<option value="${type}" hidden data-mb-legacy="true">`);
  }
  html=html.replace('<option value="Successful dribble"','<option value="Dribble">Dribble</option><option value="Successful dribble"');
  html=html.replace('<option value="Yellow card"', '<option value="Card">Card</option><option value="Yellow card"');
  // Set-piece AWARDING is a different action from actually TAKING the kick.
  html=html.replace('<option value="Penalty awarded">Penalty awarded</option>','<option value="Penalty awarded">Penalty awarded (decision)</option>');
  html=html.replace('<option value="Free kick">Free kick</option>','<option value="Free kick">Free kick (taken / pass)</option>');
  html=html.replace('<option value="Dangerous free kick">Dangerous free kick</option>','<option value="Dangerous free kick">Dangerous free kick (taken)</option>');
  return html;
 };
}
// The underlying event serializer still expects legacy names for disciplinary
// cards, so 'Card + Yellow/Second yellow/Red' maps at SAVE (same event ID).
// Penalty goal uses canonical Goal + shot.penalty, not a special event type.
function syncEditedLegacy(){
 const f=form(),e=storedEvent(),type=f?.elements.namedItem('type');
 if(!editable()||!e||!type)return;
 const mapped=equivalent(e);
 if(mapped && type.value===e.type){
   // The legacy core rebuilds player choices on type changes; restore the
   // original player after that rebuild so edit/save never drops the actor.
   type.value=mapped;
   type.dispatchEvent(new Event('change',{bubbles:true}));
   const player=f.elements.namedItem('player');
   if(player && e.player){
     if(player.tagName!=='SELECT'||[...player.options].some(o=>o.value===e.player)){
       player.value=e.player;
       player.dispatchEvent(new Event('input',{bubbles:true}));
     }
   }
 }
}
function applyPenaltyWorkspace(){
 const f=form(),stage=editable(),origin=f?.querySelector('.mh-shot-visual .location-input');
 if(!f||!stage||!origin||!SHOT.has(value('type'))){
   stage?.classList.remove('mh-penalty-shot');return;
 }
 const setPiece=value('ac19-play')||value('situation')||'';
 const e=storedEvent();
 // v37.19 stores play both in the contextual field and in 'situation'.
 const penalty=setPiece==='penalty'||value('penalty')==='yes'||
    (!!e?.shot?.penalty && value('ac19-play')==='penalty');
 const previouslyAuto=f.dataset.mbAutoPenalty==='yes';
 const setPieceShot=penalty||setPiece==='directFreeKick';
 stage.classList.toggle('mh-penalty-shot',penalty);
 stage.classList.toggle('mh-direct-free-kick-shot',!penalty&&setPiece==='directFreeKick');
 if(setPieceShot){
   // Open-play build-up is semantically inapplicable to penalties and direct FK.
   const prep=f.elements.namedItem('ac19-preparation');
   if(prep&&prep.value){prep.value='';f.querySelectorAll('[data-ac19-select="preparation"]').forEach(b=>b.setAttribute('aria-pressed','false'));}
   const pass=f.elements.namedItem('ac-creatorPassType'),control=f.elements.namedItem('ac-control');
   if(pass)pass.value='unknown';if(control)control.value='afterTouch';
   const assist=f.elements.namedItem('assist');if(assist&&value('type')==='Goal')assist.value='';
 }

 const x=f.elements.namedItem('location-x'),y=f.elements.namedItem('location-y');
 if(penalty){
   // Always use the regulation penalty spot, not a user-picked coordinate.
   // A single kick is still just ONE shot with the same target and goal mouth.
   if(x)x.value=String(PEN_X);if(y)y.value=String(PEN_Y);
   f.dataset.mbAutoPenalty='yes';origin.dataset.locationActive='destination';
   let note=stage.querySelector('.mh-penalty-info');
   if(!note){note=document.createElement('div');note.className='mh-penalty-info';note.innerHTML='<strong>Penalty kick</strong><span>Shot origin: penalty mark · 11 m from goal</span><small>Set automatically. Select the finish on the Goal Mouth below.</small>';origin.prepend(note)}
 }else{
   stage.querySelector('.mh-penalty-info')?.remove();
   if(previouslyAuto){if(x)x.value='';if(y)y.value='';}
   f.dataset.mbAutoPenalty='no';
 }
 try{if(typeof renderPickedLocation==='function')renderPickedLocation(origin)}catch(err){console.warn('[V37.27] location redraw',err)}
 try{if(typeof syncLocationFields==='function')syncLocationFields(f)}catch(err){console.warn('[V37.27] xG redraw',err)}
}
function refresh(){
 if(!editable())return;
 syncEditedLegacy();
 applyPenaltyWorkspace();
 const quick=form()?.querySelector('.next-event-suggestions');if(quick)quick.hidden=true;
 const bar=modal()?.querySelector('.ac19-timeline-heading');
 if(bar){
   const count=[...(db.matches||[]),...(db.draft?[db.draft]:[])].reduce((n,m)=>n+(m.actions||[]).filter(e=>normalizeLegacyEvent(e)!==e).length,0);
   let button=bar.querySelector('[data-mb27-upgrade]');
   if(count && !button){
     button=document.createElement('button');button.type='button';button.dataset.mb27Upgrade='yes';
     button.className='mb27-upgrade';button.textContent='Update old penalties';
     button.title='Optional: normalize old penalty goals with a restore point';
     button.onclick=()=>{const result=migrateWithBackup();if(result.ok){if(typeof toast==='function')toast('Updated '+result.changed+' historical penalties');if(typeof liveBoard==='function')liveBoard()}else if(typeof toast==='function'&&result.reason!=='Cancelled')toast(result.reason)};
     bar.append(button);
   }
   if(button)button.hidden=!count;
 }
}
let pending=false;
function soon(){if(pending)return;pending=true;setTimeout(()=>{pending=false;try{refresh()}catch(err){console.error('[V37.27] refresh',err)}},0)}
// Match History / Maker may re-render the complete form after saving an event.
if(typeof liveBoard==='function'){
 const oldBoard=liveBoard;
 liveBoard=function(...args){const ret=oldBoard(...args);soon();return ret};
}
document.addEventListener('click',e=>{
 if(e.target.closest?.('#modal .ac19-controls [data-ac19-select="play"],#modal .ac19-controls [data-ac19-select="result"],#modal [data-event-edit],#modal #cancel-edit,#modal #mh-new-action'))soon();
});
document.addEventListener('change',e=>{
 if(e.target.closest?.('#modal')&&['type','situation','penalty'].includes(e.target.name))soon();
});

// A safe, optional converter for explicit backups/migrations. Never rewrite
// saved careers just because the user opened the new UI. Unknown outcomes
// remain unchanged. IDs, minutes, players, groups, locations and xG persist.
function normalizeLegacyEvent(original){
 if(!original||typeof original!=='object')return original;
 if(original.type==='Penalty goal'){
   return {...original,type:'Goal',shot:{...(original.shot||{}),outcome:'goal',penalty:true,situation:'penalty'}};
 }
 if(original.type==='Penalty missed'){
  const outcome=original.shot?.outcome;
  const type=({saved:'Shot on target',target:'Shot on target',off:'Shot off target',post:'Post',bar:'Crossbar'})[outcome];
  if(!type)return original;
  return {...original,type,shot:{...original.shot,penalty:true,situation:'penalty'}};
 }
 return original;
}
function migrateWithBackup(){
 if(typeof db==='undefined'||typeof createRestorePoint!=='function'||typeof save!=='function')return {ok:false,reason:'Backup/save system unavailable'};
 const matches=[...(db.matches||[]),...(db.draft?[db.draft]:[])];
 const changes=matches.reduce((n,m)=>n+(m.actions||[]).filter(e=>normalizeLegacyEvent(e)!==e).length,0);
 if(!changes)return {ok:true,changed:0};
 if(!confirm(`Normalize ${changes} unambiguous legacy penalty events? A restore point will be created first.`))return {ok:false,reason:'Cancelled'};
 if(!createRestorePoint('Before V37.27 penalty event normalization'))return {ok:false,reason:'Restore point not created'};
 const previous=matches.map(m=>m.actions);
 matches.forEach(m=>{m.actions=(m.actions||[]).map(normalizeLegacyEvent)});
 if(!save()){matches.forEach((m,i)=>{m.actions=previous[i]});return {ok:false,reason:'Save failed; original events restored in memory'}}
 return {ok:true,changed:changes};
}
window.MatchbookEventSimplificationV3727={normalizeLegacyEvent,migrateWithBackup,equivalent,applyPenaltyWorkspace,penaltySpot:{x:PEN_X,y:PEN_Y}};
if(editable())soon();
})();
