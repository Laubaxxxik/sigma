# Matchbook V37.29 — Big Matches & Career Restore

This archive contains the complete production-facing Matchbook application. Put the files at the root of the same Vercel project, preserving `api/`. Do not deploy it in a nested subfolder.

Highlights:
- Unified Big Matches scope in the main Statistics filter row.
- Barcelona, Real Madrid and European knockout fixtures qualified correctly, with importance tiers and reasons.
- Historical Awards/Statistics classifications re-derived without editing stored match records.
- Readable Trophy Room Evidence modal.
- Additive IndexedDB copy restoring saved careers on startup when local primary data is absent.

IMPORTANT: Back up your JSON career before deployment. Verify the actual browser refresh/reopen workflow in a Vercel Preview deployment. The local IndexedDB mirror is **not** a replacement for cloud sync or an independent backup file.

Detailed QA: Matchbook-V37.29-QA.md (provided separately).
