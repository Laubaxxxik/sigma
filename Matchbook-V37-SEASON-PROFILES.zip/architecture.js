/* Matchbook V32 — lightweight extension hooks, derived-data cache and explicit schema migrations. */
const Matchbook=window.Matchbook||(window.Matchbook={});
Matchbook.hooks=Matchbook.hooks||Object.create(null);
function registerHook(name,fn,priority=0){if(typeof fn!=='function')return()=>{};const list=Matchbook.hooks[name]??=[];const row={fn,priority:Number(priority)||0,id:Symbol(name)};list.push(row);list.sort((a,b)=>b.priority-a.priority);return()=>{const i=list.findIndex(x=>x.id===row.id);if(i>=0)list.splice(i,1)}}
function runHooks(name,...args){const out=[];for(const row of [...(Matchbook.hooks[name]||[])]){try{out.push(row.fn(...args))}catch(error){console.error('[Matchbook hook]',name,error)}}return out}
function collectHooks(name,...args){return runHooks(name,...args).flatMap(x=>Array.isArray(x)?x:x==null?[]:[x])}
function firstHook(name,...args){for(const row of [...(Matchbook.hooks[name]||[])]){try{const value=row.fn(...args);if(value!==undefined&&value!==false)return value}catch(error){console.error('[Matchbook hook]',name,error)}}return undefined}
Matchbook.registerHook=registerHook;Matchbook.runHooks=runHooks;Matchbook.collectHooks=collectHooks;Matchbook.firstHook=firstHook;

Matchbook.cache=Matchbook.cache||{revision:0,items:new Map(),invalidate(){this.revision++;this.items.clear()},memo(key,builder){const hit=this.items.get(key);if(hit&&hit.revision===this.revision)return hit.value;const value=builder();this.items.set(key,{revision:this.revision,value});return value}};

const MATCHBOOK_SCHEMA_VERSION=4;
function mbValidPoint(p){return !!p&&Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y))&&Number(p.x)>=0&&Number(p.x)<=100&&Number(p.y)>=0&&Number(p.y)<=100}
function migrateSchema0to1(data){data.availability=Array.isArray(data.availability)?data.availability:[];data.schemaVersion=1;return data}
function migrateSchema1to2(data){
 const rows=[...(Array.isArray(data.matches)?data.matches:[]),...(data.draft?[data.draft]:[])];
 for(const m of rows)for(const e of Array.isArray(m?.actions)?m.actions:[]){
  if(!e||typeof e!=='object')continue;
  // Only migrate an explicitly stored legacy destination. Never invent coordinates.
  const legacy=e.passDestination||e.interaction?.passDestination;
  if(!mbValidPoint(e.pass?.destination)&&mbValidPoint(legacy)){e.pass={...(e.pass||{}),destination:{x:Number(legacy.x),y:Number(legacy.y)}}}
 }
 data.schemaVersion=2;return data
}
function migrateSchema2to3(data){data.availability=Array.isArray(data.availability)?data.availability:[];data.schemaVersion=3;data.schemaMeta={...(data.schemaMeta||{}),name:'Matchbook career',version:3};return data}
function migrateSchema3to4(data){ensureSeasonProfiles(data);data.schemaVersion=4;data.schemaMeta={...(data.schemaMeta||{}),name:'Matchbook career',version:4};return data}
const MATCHBOOK_MIGRATIONS={0:migrateSchema0to1,1:migrateSchema1to2,2:migrateSchema2to3,3:migrateSchema3to4};
function runMatchbookMigrations(source){
 const data=structuredClone(source||{}),from=Number.isInteger(Number(data.schemaVersion))?Number(data.schemaVersion):0,applied=[];
 if(from>MATCHBOOK_SCHEMA_VERSION)throw Error(`This career uses newer schema ${from}; this build supports ${MATCHBOOK_SCHEMA_VERSION}.`);
 let version=from;
 while(version<MATCHBOOK_SCHEMA_VERSION){const migration=MATCHBOOK_MIGRATIONS[version];if(typeof migration!=='function')throw Error(`Missing schema migration ${version} → ${version+1}.`);migration(data);applied.push(`${version}→${version+1}`);version=Number(data.schemaVersion)}
 return {data,changed:applied.length>0,from,to:version,applied}
}
Matchbook.schemaVersion=MATCHBOOK_SCHEMA_VERSION;Matchbook.runMigrations=runMatchbookMigrations;
