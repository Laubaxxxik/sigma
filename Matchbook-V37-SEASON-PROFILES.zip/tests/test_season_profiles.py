"""V37: season profile isolation, atomic creation, migration and backup round trips."""
import base64
import json
from pathlib import Path
import unittest

import test_browser as harness


class SeasonProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        harness.BrowserTests.setUpClass()
        cls.app = harness.BrowserTests('test_existing_regressions')
        cls.app.setUp()
        cls.page = cls.app.page

    @classmethod
    def tearDownClass(cls):
        cls.app.tearDown()
        harness.BrowserTests.tearDownClass()

    def setUp(self):
        self.page.evaluate("document.querySelector('#modal').close();db=structuredClone(initial);page='Dashboard';season='s1';profileCompetitionCategory='all'")
        self.page.evaluate(harness.FIXTURE)
        self.app.errors.clear()

    def tearDown(self):
        self.assertEqual(self.app.errors, [])

    def profile_step(self, club='Real Madrid', year='2027/28'):
        self.page.evaluate("act('new-season')")
        self.page.locator('#form [name=club]').fill(club)
        self.page.locator('#form [name=year]').fill(year)
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_function("document.querySelector('#form h2').textContent.includes('2 of 2')")

    def complete_profile(self):
        for name, value in [('number','9'),('positions','ST'),('height','186'),('weight','81'),('careerDate','2027-08-01')]:
            self.page.locator(f'#form [name={name}]').fill(value)

    def create_season(self):
        self.profile_step()
        self.complete_profile()
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_function('db.seasons.length===2')
        return self.page.evaluate('season')

    def test_legacy_migration_preserves_data_and_creates_independent_snapshots(self):
        result = self.page.evaluate('''() => {
          const old=structuredClone(db);old.schemaVersion=3;
          delete old.seasons[0].playerProfile;delete old.seasons[0].playerProfileSource;
          old.profile.height='180';old.profile.weight='70';
          old.seasons.push({id:'s2',name:'Liverpool · 2027/28',club:'Liverpool',year:'2027/28'});
          old.matches.push({...structuredClone(old.matches[0]),id:'later',season:'s2',date:'2027-09-01'});
          const source=JSON.stringify(old),a=runMatchbookMigrations(old),b=runMatchbookMigrations(a.data);
          const p=a.data.seasons.map(s=>s.playerProfile),matches=JSON.stringify(a.data.matches)===JSON.stringify(old.matches);
          p[1].weight='82';
          return {sourceUnchanged:source===JSON.stringify(old),matches,version:a.to,idempotent:!b.changed,
            clubs:p.map(p=>p.club),ages:p.map(p=>p.age),dates:p.map(p=>p.careerDate),
            isolated:p[0].weight==='70'&&a.data.profile.weight==='70',source:a.data.seasons[0].playerProfileSource,
            errors:careerErrors(a.data)};
        }''')
        self.assertTrue(result['sourceUnchanged'] and result['matches'] and result['idempotent'] and result['isolated'])
        self.assertEqual(result['version'],4)
        self.assertEqual(result['clubs'],['Arsenal','Liverpool'])
        self.assertEqual(result['ages'],['23','24'])
        self.assertEqual(result['dates'],['2026-10-07','2027-09-01'])
        self.assertEqual(result['source'],'legacy')
        self.assertEqual(result['errors'],[])

    def test_new_season_is_not_saved_without_its_profile(self):
        before = self.page.evaluate('JSON.stringify(db)')
        stored = self.page.evaluate('localStorage.getItem(KEY)')
        self.profile_step()
        self.assertEqual(self.page.locator('#form [name=name]').input_value(),'Alex Morgan')
        self.assertEqual(self.page.locator('#form [name=nationality]').input_value(),'England')
        for name in ['number','positions','height','weight','age','photoData','contract','bio']:
            self.assertEqual(self.page.locator(f'#form [name={name}]').input_value(),'',name)
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate('JSON.stringify(db)'),before)
        self.page.locator('#cancel').click()
        self.assertEqual(self.page.evaluate('JSON.stringify(db)'),before)
        self.assertEqual(self.page.evaluate('localStorage.getItem(KEY)'),stored)

    def test_creating_switching_and_editing_profiles_keeps_other_seasons(self):
        old = self.page.evaluate('JSON.stringify(db.seasons[0].playerProfile)')
        matches = self.page.evaluate('JSON.stringify(db.matches)')
        new_id = self.create_season()
        self.assertEqual(self.page.evaluate('JSON.stringify(db.seasons[0].playerProfile)'),old)
        self.assertEqual(self.page.evaluate('JSON.stringify(db.matches)'),matches)
        self.app.go('Statistics')
        self.assertIn('Real Madrid',self.page.locator('.fm-player-card').inner_text())
        self.assertIn('186 cm',self.page.locator('.fm-player-card').inner_text())
        self.assertEqual(self.page.evaluate('profileAge()'),24)
        self.page.evaluate("season='s1';render()")
        self.assertIn('Arsenal',self.page.locator('.fm-player-card').inner_text())
        self.assertEqual(self.page.evaluate('profileAge()'),23)
        newer = self.page.evaluate('id=>JSON.stringify(playerProfile(id))',new_id)
        self.app.go('Seasons')
        self.page.locator('[data-action="season-profile:s1"]').click()
        self.assertEqual(self.page.locator('#form [name=club]').input_value(),'Arsenal')
        self.page.locator('#form [name=height]').fill('181')
        self.page.locator('#form [name=weight]').fill('73')
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate('id=>JSON.stringify(playerProfile(id))',new_id),newer)
        self.page.evaluate("page='Statistics';season='@career';render()")
        self.assertEqual(self.page.evaluate('playerProfile().club'),'Real Madrid')
        self.assertIn('Latest season',self.page.locator('.fm-player-card').inner_text())
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])

    def test_photo_backup_reload_and_removal_are_scoped_to_season(self):
        self.profile_step();self.complete_profile()
        image = self.page.evaluate("() => {const c=document.createElement('canvas');c.width=8;c.height=10;c.getContext('2d').fillRect(0,0,8,10);return c.toDataURL('image/png').split(',')[1]}")
        self.page.locator('#player-photo-file').set_input_files({'name':'portrait.png','mimeType':'image/png','buffer':base64.b64decode(image)})
        self.page.wait_for_function("document.querySelector('#player-photo-status').textContent==='Photo ready to save.'")
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_function('db.seasons.length===2')
        new_id = self.page.evaluate('season')
        self.assertTrue(self.page.evaluate("playerProfile().photoData.startsWith('data:image/webp')"))
        expected = self.page.evaluate('JSON.stringify(db.seasons.map(s=>s.playerProfile))')
        with self.page.expect_download() as download_info:
            self.page.evaluate('backup()')
        raw = Path(download_info.value.path()).read_text()
        self.assertEqual(len(json.loads(raw)['seasons']),2)
        self.assertTrue(self.page.evaluate('raw=>replaceCareer(prepareCareerForLoad(JSON.parse(raw)))',raw))
        self.page.reload(wait_until='networkidle')
        self.assertEqual(self.page.evaluate('JSON.stringify(db.seasons.map(s=>s.playerProfile))'),expected)
        self.page.evaluate("id=>{season=id;editPlayerProfile()}",new_id)
        self.assertEqual(self.page.locator('.profile-photo-preview img').count(),1)
        self.page.locator('#player-photo-remove').click()
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate('playerProfile().photoData'),'')
        self.assertFalse(self.page.evaluate("!!playerProfile('s1').photoData"))
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])

    def test_failed_save_can_retry_without_partial_new_season(self):
        old = self.page.evaluate('JSON.stringify(db)')
        self.profile_step();self.complete_profile()
        self.page.evaluate('window.testSave=save;save=()=>false')
        try:
            self.page.locator('#form button[type=submit]').click()
            self.assertEqual(self.page.evaluate('JSON.stringify(db)'),old)
            self.assertTrue(self.page.locator('#modal').is_visible())
        finally:
            self.page.evaluate('save=window.testSave;delete window.testSave')
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_function('db.seasons.length===2')
        self.assertEqual(self.page.evaluate('playerProfile().club'),'Real Madrid')
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])

    def test_season_club_edits_and_market_values_are_scoped(self):
        new_id = self.create_season()
        self.page.evaluate("playerProfile('s1').marketValueOverride='12';playerProfile().marketValueOverride='44';save()")
        self.assertEqual(self.page.evaluate('fmMarketHistory().map(x=>x.value)'),[12,44])
        self.page.evaluate("act('season:s1')")
        self.page.locator('#form [name=club]').fill('Chelsea')
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate("playerProfile('s1').club"),'Chelsea')
        self.assertEqual(self.page.evaluate('id=>playerProfile(id).club',new_id),'Real Madrid')
        self.assertEqual(self.page.evaluate('fmCurrentMarketValue().value'),12)
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])

    def test_identity_corrections_preserve_old_match_attribution(self):
        new_id = self.create_season()
        self.page.evaluate("delete db.matches[0].trackedPlayer;save();act('season-profile:s1')")
        self.page.locator('#form [name=name]').fill('Alex Morgan Jr')
        self.page.locator('#form [name=nationality]').fill('Poland')
        self.page.locator('#form button[type=submit]').click()
        result = self.page.evaluate('''id => ({
          previousName:db.matches[0].trackedPlayer,
          attribution:playerMatcher(db.matches[0])('Alex Morgan'),
          otherName:playerProfile(id).name,
          next:newSeasonPlayerProfile({club:'Liverpool'}),errors:careerErrors(db)
        })''',new_id)
        self.assertEqual(result['previousName'],'Alex Morgan')
        self.assertTrue(result['attribution'])
        self.assertEqual(result['otherName'],'Alex Morgan')
        self.assertEqual(result['next']['name'],'Alex Morgan Jr')
        self.assertEqual(result['next']['nationality'],'Poland')
        self.assertEqual(result['next']['positions'],'')
        self.assertEqual(result['errors'],[])

    def test_legacy_portrait_is_preserved_without_duplicating_it_for_every_season(self):
        original = self.page.evaluate('''() => {
          const canvas=document.createElement('canvas');canvas.width=8;canvas.height=10;
          canvas.getContext('2d').fillRect(0,0,8,10);const photo=canvas.toDataURL();
          db.profile.photoData=photo;delete db.seasons[0].playerProfile;
          db.seasons.push({id:'s2',name:'Chelsea · 2027/28',club:'Chelsea',year:'2027/28',baseM:0,baseG:0,baseA:0});
          db.schemaVersion=3;db=prepareCareerForLoad(db);save();return photo;
        }''')
        self.assertEqual(self.page.evaluate('JSON.stringify(db).split(db.profile.photoData).length-1'),1)
        self.page.evaluate("act('season-profile:s2')")
        self.assertEqual(self.page.locator('.profile-photo-preview img').get_attribute('src'),original)
        self.page.locator('#player-photo-remove').click()
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate("playerProfilePhoto(playerProfile('s1'))"),original)
        self.assertEqual(self.page.evaluate("playerProfilePhoto(playerProfile('s2'))"),'')
        self.assertTrue(self.page.evaluate('''() => {
          const copy=compactSafetySnapshot(db);
          return !copy.profile.photoData&&copy.profile.photoOmittedFromSafetySnapshot&&replaceCareer(copy);
        }'''))
        self.assertEqual(self.page.evaluate("playerProfilePhoto(playerProfile('s1'))"),original)
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])

    def test_back_and_first_season_creation(self):
        self.profile_step('Barcelona','2028/29')
        self.page.get_by_role('button',name='Back to season',exact=True).click()
        self.assertEqual(self.page.locator('#form [name=club]').input_value(),'Barcelona')
        self.assertEqual(self.page.locator('#form [name=year]').input_value(),'2028/29')
        self.assertEqual(self.page.evaluate('db.seasons.length'),1)
        self.page.locator('#cancel').click()
        self.page.evaluate("db.seasons=[];db.matches=[];db.profileReady=true;storageState.allowReplacement=true;save();storageState.allowReplacement=false;season='';render()")
        self.profile_step('Arsenal','2026/27')
        self.assertEqual(self.page.locator('#form [name=positions]').input_value(),'CAM, CM')
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_function('db.seasons.length===1')
        self.assertEqual(self.page.evaluate('careerErrors(db)'),[])
        self.assertEqual(self.page.evaluate('season'),self.page.evaluate('db.seasons[0].id'))


if __name__ == '__main__':
    unittest.main()
