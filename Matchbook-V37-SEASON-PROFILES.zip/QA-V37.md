# V37 · profile zawodnika dla każdego sezonu

## Zmiana

`season-profiles.js` przechowuje profil w `season.playerProfile`. Wspólny
`db.profile` zachowuje poprzedni zapis i dane tożsamości używane do rozpoczęcia
następnego sezonu. Ustawienia kariery reprezentacyjnej pozostają wspólne.

Nowy sezon powstaje po ukończeniu formularza sezonu i formularza jego zawodnika.
Anulowanie albo błąd zapisu nie dodają częściowo skonfigurowanego sezonu.
Przycisk powrotu zachowuje wprowadzone dane profilu. Zapis można ponowić.

Istniejące przyciski edycji profilu korzystają z wybranego sezonu. Na stronie
Seasons każdy sezon ma dodatkowo własny przycisk **Edit player profile**.
Profil oraz formularz pokazują rok i klub, których dotyczą.

Dashboard, Statistics, profil kariery, raporty i kontekst korzystają z profilu
wybranego sezonu. Widok Entire career pokazuje najnowszy sezon według roku,
z kolejnością dodania jako rozstrzygnięciem przy tym samym roku.
Wzrost i waga są widoczne w danych profilu. Układ sekcji statystyk pozostaje
zachowany. Wycena, kontrakt i wiek korzystają z danych konkretnego sezonu.

## Zachowanie dotychczasowych danych

Migracja schematu 3 → 4 zachowuje mecze i poprzedni wspólny profil. Kopiuje
jego dane do istniejących sezonów i przypisuje klub zapisany przy sezonie.
Formularz informuje, że dane są odziedziczone i wymagają sprawdzenia.
Nie da się odtworzyć historycznego wzrostu czy wagi z zapisu, który ich nie
przechowywał osobno. Ręcznego wieku nie wyliczamy wstecz.

Wiek z daty urodzenia wyliczamy z najpóźniejszego poprawnie datowanego meczu
danego sezonu, uwzględniając przypisane do niego występy reprezentacyjne.
Przed pierwszym meczem można podać datę profilu albo wiek ręcznie.

Zmiana nazwiska nie zmienia przypisania zapisanych zdarzeń. Starsze zdarzenia
bez jawnego `trackedPlayer` otrzymują poprzednią tożsamość przed edycją.

Poprzedni wspólny portret nie jest wielokrotnie osadzany w zapisie przy migracji.
Poszczególne sezony mogą później zapisać albo usunąć własne zdjęcie.
Pełny JSON zawiera wszystkie profile i ich obrazy. Kompaktowe kopie awaryjne
pomijają zdjęcia, zachowując przy odtwarzaniu dostępne obrazy tego samego sezonu.

Klucz localStorage `fesedyo-career-v1` i nadrzędne `version: 1` pozostają te same.
Nowe kopie mają `schemaVersion: 4` i wymagają V37 lub nowszej aplikacji.

## Weryfikacja

Nowe testy Chromium w `tests/test_season_profiles.py` obejmują dziewięć scenariuszy:

- migrację bez zmiany źródła, niezależne kopie i daty sezonów, ponowienie migracji;
- wymagany profil nowego sezonu, automatyczną tożsamość i anulowanie;
- tworzenie, przełączanie i edycję starszego profilu bez zmiany nowszego;
- zdjęcie, rzeczywiste pobranie JSON, import, ponowne otwarcie i usunięcie zdjęcia;
- błąd zapisu i ponowienie bez częściowego sezonu;
- zmianę klubu i niezależne ręczne wyceny;
- korektę tożsamości bez zmiany przypisania starych zdarzeń;
- dawny wspólny portret i odzyskanie kompaktowej kopii bez powielania obrazu;
- powrót w formularzu i utworzenie pierwszego sezonu.

Kontrole dotychczasowych funkcji obejmują 13 przypadków przeglądarkowych:
składnię i zasoby, 20 testów wbudowanych, 19 stron przy szerokościach
360/390/768/1440 px, nawigację i ponowne otwarcie, zapis występu, przygotowanie
i start meczu, reprezentację w statystykach, okna edycji, pobieranie JSON,
angielskie daty i nazwy, filtry, eksport CSV i klawiaturę mapy strzałów.
Porównanie HTML i geometrii wszystkich czterech widoków Statistics z arkuszem
kolorów włączonym i wyłączonym działa przy 390 i 1440 px.

Osobno sprawdzono składnię 41 plików JavaScript oraz sześć testów
`tests/history-english.test.cjs`. Zrzuty kontrolne profilu i formularza
wykonano przy 390 i 1440 px; formularz mieści się również przy 360 px.

Testy używają syntetycznych danych i blokują sieć zewnętrzną. Nie logują się
na rzeczywiste konto chmurowe. Wdrożenia Vercel ani rzeczywistej synchronizacji
Supabase nie wykonano. ZIP wymaga opublikowania jako nowa wersja strony.
