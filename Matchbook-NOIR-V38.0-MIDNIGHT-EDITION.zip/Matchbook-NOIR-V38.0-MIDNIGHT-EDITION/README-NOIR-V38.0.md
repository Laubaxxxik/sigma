# Matchbook Noir — Midnight Edition · V38.0

Complete application source, based on V37.32. Open through an HTTP server or deploy the folder to the existing Vercel project. There is no required frontend build and no career-data migration.

## Run locally

From this folder: `python3 -m http.server 8000`, then open `http://localhost:8000`. Keep your existing JSON backup. Browser-local careers belong to their original origin; opening a different host or port does not transfer that storage. Use the existing JSON import to move a career.

## Design architecture

`noir-foundations.css` owns semantic colors, spacing, type, radii and self-hosted Manrope. `noir-legacy.css` is a checked-in compatibility bundle generated from the original 36 stylesheets; it preserves specialized component geometry and replaces literal palettes with shared tokens. Original stylesheets remain as compiler inputs and are not also loaded by index.html. `noir.css` owns the new shell, responsive layouts and shared components. `noir.js` supplies the new Dashboard, Career centre, Media hierarchy, calendar view switch, navigation and optional view restoration.

This is a staged presentation architecture: existing specialized editors and football models remain authoritative. New product layouts sit above their handlers. A future cleanup can gradually remove redundant legacy selectors without rebuilding the event engine.

## Optional development tools

No npm install is needed to run or deploy the checked-in application. To regenerate the compatibility stylesheet, install the pinned tooling under `scripts/` using `npm install --prefix scripts`, then run `node scripts/compile-noir.cjs`. For browser checks set `NODE_PATH=./scripts/node_modules` and `CHROMIUM_PATH` to an installed Chromium executable. Run the test files under `tests/` with Node; `awards-v4.test.cjs` uses `node --test`. The browser tests use synthetic fixture careers in isolated Chromium contexts.

Read `NOIR-DEVELOPMENT-REPORT.md` for the actual verification, known limits and deployment considerations. `validation/` contains transcripts, the source-change inventory and selected screenshots.
