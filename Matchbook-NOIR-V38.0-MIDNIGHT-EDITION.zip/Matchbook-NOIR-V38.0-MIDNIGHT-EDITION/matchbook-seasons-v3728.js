/* Matchbook V37.28 — Your Seasons, read-only overview over the current career data.
   Existing season editing, competition assignment and close-season workflows are reused. */
(function(){
 'use strict';
 const e=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let expanded='';
 function selected(){return (db.seasons||[]).find(s=>String(s.id)===String(season))||null;}
 function seasons(){return db.seasons||[];}
 function seasonState(s){const open=seasons().slice().reverse().find(x=>!x.awardsV3717?.closed);
   if(open&&String(open.id)===String(s.id))return 'Current season';
   if(s.awardsV3717?.closed)return 'Completed season';
   return 'Archived / unfinished';}
 function rated(s){
   const list=allMatchViews().filter(m=>String(m.season)===String(s.id)&&m.count!==false);
   const rs=list.map(m=>Number(m.rating)).filter(n=>Number.isFinite(n)&&n>=1&&n<=10);
   return rs.length?{value:(rs.reduce((a,b)=>a+b,0)/rs.length).toFixed(1),count:rs.length}:null;
 }
 function confirmed(s){
   const snap=s.awardsV3717?.seasonSnapshot,base=snap?.snapshotLocked?snap.competitions:s.competitions;
   return (Array.isArray(base)?base:[]).filter(c=>String(c?.status||'').toLowerCase()==='won').map(c=>String(c.name||'Trophy'));
 }
 function awards(s){const a=s.awardsV3717||{},list=[];
   for(const [id,result] of Object.entries(a.global||{}))if(result?.status==='Won')list.push('Legacy ceremony · '+id.replaceAll('_',' '));
   for(const row of a.manualAwards||[])if(row?.status==='Won')list.push(row.label||row.type||'Individual award');
   for(const [id,v] of Object.entries(s.awardResultsV4||{}))if(v.winner)list.push((v.kind==='official'?'Confirmed':'Simulated')+' · '+id.replaceAll('_',' '));
   return [...new Set(list)];}
 function seasonMatches(s){return allMatchViews().filter(m=>String(m.season)===String(s.id)&&m.count!==false);}
 function history(s){const matches=seasonMatches(s);if(!matches.length)return '<p class="mb28-season-empty">No saved fixtures in this season yet.</p>';
   return `<div class="mb28-season-fixtures">${matches.slice(-8).reverse().map(m=>`<button type="button" data-action="recap:${e(m.id)}"><span>${e(m.date||'Date unknown')} · ${e(m.opponent||'Opponent')} · ${e(m.competition||'Competition')}</span><b>${e(m.score||'View report')} →</b></button>`).join('')}</div>`;
 }
 function card(s,index){const t=seasonTotals(s),rating=rated(s),medals=confirmed(s),prizes=awards(s),state=seasonState(s),isSelected=String(s.id)===String(season),isOpen=expanded===String(s.id);
   return `<article class="mb28-season-card ${isSelected?'is-selected':''}">
    <div class="mb28-season-main"><span class="mb28-season-crest">${typeof clubBadge==='function'?clubBadge(s.club||'', 'large'):'⚽'}</span>
      <div class="mb28-season-label"><span class="mb28-season-year">${e(s.year||'Season')}</span><h2>${e(s.club||s.name||'Club not entered')}</h2>${(s.competitions||[]).some(c=>typeof competitionCategory==='function'&&competitionCategory({competition:c.name})==='League')?`<span class="noir-season-league">${e((s.competitions||[]).filter(c=>competitionCategory({competition:c.name})==='League').map(c=>c.name).join(' · '))}</span>`:''}<span class="mb28-season-status">${e(state)}${isSelected?' · Selected':''}</span></div>
      <div class="mb28-season-kpis">${[['Apps',t.m],['Goals',t.g],['Assists',t.a],['Rating',rating?.value??'—']].map(([k,v])=>`<div><strong>${e(v)}</strong><small>${k}</small></div>`).join('')}</div>
      <button type="button" class="mb28-season-expand" data-mb28-season-expand="${e(s.id)}" aria-expanded="${isOpen}">${isOpen?'Hide details −':'Season details +'} </button>
    </div>
    ${medals.length?`<div class="mb28-season-honours">${medals.slice(0,4).map(name=>`<span>🏆 ${e(name)}</span>`).join('')}${medals.length>4?`<small>+${medals.length-4} more</small>`:''}</div>`:''}
    ${isOpen?`<div class="mb28-season-details"><div class="mb28-season-actions"><button type="button" data-mb28-season-nav="stats" data-season-id="${e(s.id)}">View Statistics →</button><button type="button" data-mb28-season-nav="awards" data-season-id="${e(s.id)}">View Awards →</button>${btn('Edit season','season:'+s.id)}${btn('Edit player profile','season-profile:'+s.id)}</div>
      <div class="mb28-season-detail-grid"><section><h3>Competition results</h3>${competitionsView(s)}<h3>Recorded individual awards</h3>${prizes.length?`<div class="mb28-honours-list">${prizes.map(x=>`<span>${e(x)}</span>`).join('')}</div>`:'<p class="mb28-season-empty">No individual award wins recorded.</p>'}</section><section><h3>Competition breakdown</h3>${competitionBreakdown(s)}<p class="mb28-season-note">Average rating: ${rating?.value??'—'} (${rating?.count||0} rated games). Historical aggregate totals without match-level evidence are not assigned to a competition.</p></section></div>
      ${window.MatchbookAwardsV4UI?window.MatchbookAwardsV4UI.rankings(s):''}<section class="mb28-season-fixture-panel"><h3>Recent fixtures</h3>${history(s)}</section>
      ${typeof matchbookSeasonHonoursControls==='function'?matchbookSeasonHonoursControls(s):''}
      ${s.note?`<p class="mb28-season-note">${e(s.note)}</p>`:''}</div>`:''}
   </article>`;
 }
 function screen(){const entries=seasons();const newest=entries.slice().reverse();const t=entries.reduce((a,s)=>{const n=seasonTotals(s);a.apps+=n.m;a.goals+=n.g;a.assists+=n.a;return a;},{apps:0,goals:0,assists:0});
  return `<div class="mb28-seasons"><header class="mb28-seasons-header"><div><span>MATCHBOOK / CAREER MANAGEMENT</span><h1>Your Seasons</h1><p>Every club, season and confirmed achievement in your career history.</p></div><div class="mb28-seasons-ops">${btn('+ New season','new-season','primary')}${btn('Remove empty starter seasons','clear-starters')}</div></header>
   <section class="mb28-career-strip" aria-label="Career summary">${[['Seasons',entries.length],['Appearances',t.apps],['Goals',t.goals],['Assists',t.assists]].map(([label,n])=>`<div><b>${n}</b><span>${label}</span></div>`).join('')}</section>
   <div class="mb28-season-heading"><div><small>CHRONOLOGICAL CAREER</small><h2>Season Timeline</h2></div><p>Select a season for reports and editing. Existing history remains unchanged.</p></div>
   ${newest.length?`<div class="mb28-season-list">${newest.map(card).join('')}</div>`:'<section class="mb28-season-card mb28-season-empty">No seasons recorded yet. Create your first season to begin.</section>'}
  </div>`;
 }
 const previous=typeof managementView==='function'?managementView:null;
 if(previous)managementView=function(){return page==='Seasons'?screen():previous();};
 document.addEventListener('click',event=>{
   const expand=event.target.closest?.('[data-mb28-season-expand]');
   if(expand&&page==='Seasons'){event.preventDefault();expanded=expanded===expand.dataset.mb28SeasonExpand?'':expand.dataset.mb28SeasonExpand;render();return;}
   const nav=event.target.closest?.('[data-mb28-season-nav]');if(!nav||page!=='Seasons')return;
   event.preventDefault();const id=nav.dataset.seasonId;if(!seasons().some(s=>String(s.id)===String(id)))return;
   season=id;page=nav.dataset.mb28SeasonNav==='stats'?'Statistics':'Awards';
   if(page==='Awards'){window.MatchbookTrophyRoomV3726?.selectSeason?.(id);window.MatchbookTrophyRoomV3730?.selectSeason?.(id);}
   if(typeof render==='function')render();
 });
 window.MatchbookSeasonsV3728={screen,selectSeason(id){expanded=String(id);},detailSeason(){return expanded;}};
})();
