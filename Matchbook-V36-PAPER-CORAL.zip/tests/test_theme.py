"""V36 visual contract: Statistics stays unchanged; all dialogs fit a phone."""
import unittest
import test_browser as harness


class ThemeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        harness.BrowserTests.setUpClass()
        cls.app = harness.BrowserTests('test_existing_regressions')
        cls.app.setUp()
        cls.page = cls.app.page

    @classmethod
    def tearDownClass(cls):
        cls.app.tearDown()
        harness.BrowserTests.tearDownClass()

    def test_statistics_has_identical_pixels_with_new_theme_enabled(self):
        self.app.go('Statistics')
        self.page.evaluate("document.querySelector('link[href^=\"v36-theme\"]').disabled=true")
        before = self.page.locator('#content').screenshot()
        self.page.evaluate("document.querySelector('link[href^=\"v36-theme\"]').disabled=false")
        after = self.page.locator('#content').screenshot()
        self.assertEqual(before, after)

    def test_windows_fit_a_phone_and_keep_form_fields_accessible(self):
        self.app.go('Dashboard')
        self.page.set_viewport_size({'width':390,'height':844})
        actions = ["act('profile')", "act('new-season')", "act('new-match')",
                   'openCalendarFixture()', "act('new-transfer')", "act('new-canon')",
                   'v32OpenAvailability()', 'openV2BracketCreate()', 'editClubLineup()',
                   'mediaAccountEditor()', 'openGlobalSearch()', 'recoveryPanel()',
                   'matchRecap(db.matches[0])', 'careerClips()', 'openStoryStudio()']
        for action in actions:
            with self.subTest(action=action):
                self.page.evaluate("document.querySelector('#modal').close()")
                self.page.evaluate(action)
                box = self.page.locator('#modal').evaluate('''e=>({width:e.getBoundingClientRect().width,client:e.clientWidth,scroll:e.scrollWidth,bg:getComputedStyle(e).backgroundColor})''')
                self.assertLessEqual(box['width'], 390)
                self.assertLessEqual(box['scroll'], box['client'] + 1, box)
                self.assertNotIn('v34-live-modal', self.page.locator('#modal').get_attribute('class'))
        self.page.evaluate("document.querySelector('#modal').close()")
        self.assertEqual(self.app.errors, [])

    def test_auxiliary_picker_and_backup_windows(self):
        self.app.go('Dashboard')
        self.page.set_viewport_size({'width':390,'height':844})
        self.page.evaluate("downloadJson(JSON.stringify(db),'theme-test.json')")
        self.assertTrue(self.page.locator('#json-export-dialog').is_visible())
        colors = self.page.locator('#json-download').evaluate('e=>({fg:getComputedStyle(e).color,bg:getComputedStyle(e).backgroundColor})')
        self.assertNotEqual(colors['fg'], colors['bg'])
        self.page.locator('#json-close').click()
        self.page.evaluate("act('live')")
        self.page.wait_for_selector('.v34-setup-grid')
        self.page.locator('[name=lineupMode]').select_option('manual')
        self.page.locator('[name=away]').fill('Liverpool')
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_selector('#add-event')
        self.page.evaluate("openPlayerPicker(document.querySelector('#form [name=type]'))")
        picker = self.page.locator('#player-search-dialog')
        self.assertTrue(picker.is_visible())
        self.assertLessEqual(picker.bounding_box()['width'], 390)
        self.assertEqual(picker.evaluate('e=>getComputedStyle(e).backgroundColor'), 'rgb(255, 250, 244)')
        self.page.locator('#player-search-close').click()
        self.page.evaluate("document.querySelector('#modal').close()")


if __name__ == '__main__':
    unittest.main()
