# Matchbook · V35.3

Poprawiona wersja bazująca na paczce **V35.2 SINGLE DARK THEME OVERLAP FIX**.
Ogólny układ i format zapisanej kariery pozostają zachowane. Interfejs zachowuje
dotychczasowy język angielski.

## Co się zmieniło

- Ciemna paleta grafitu i zieleni, czytelniejsze nagłówki i spójne stany przycisków.
- Nagłówki kart rosną wraz z treścią; panel startowy nie nachodzi na następny mecz.
- Statystyki mieszczą się na telefonach i korzystają z całej szerokości na komputerze.
- Sekcje **Overview / Performance / Matches / Career**, wykres ostatnich ocen,
  podsumowanie udziału przy golach i widoczny zakres dostępnych danych.
- Eksport CSV respektuje bieżące filtry i zabezpiecza tekst przed interpretacją
  jako formuły arkusza. Pełna kopia JSON nadal działa niezależnie.
- „All” obejmuje również występy reprezentacyjne powiązane z wybranym sezonem;
  „Entire career” obejmuje wszystkie sezony.
- Szczegółowe wskaźniki na 90 minut uwzględniają minuty tylko tych spotkań,
  w których daną metrykę zapisano. Nieznane dane nadal pokazują `—`.
- Wynik bez pełnego raportu nie generuje fałszywego ostrzeżenia o brakujących golach.
- Ręcznie dodane występy działają z filtrem miejsca meczu; ich podsumowania
  prawidłowo pokazują miejsce i nie przedstawiają nieznanego xG/xA jako zera.
- Ostatnie wyniki są sortowane po datach; nieznana data trafia do „Undated”.
- Niedostępne herby zachowują inicjały bez błędów JavaScript.
- Autouzupełnienie stadionu nie otwiera nieaktywnej listy i nie przesuwa przycisku
  rozpoczęcia meczu podczas klikania.
- Ponowne otwarcie przygotowania meczu i późniejsza edycja profilu nie dziedziczą
  starego układu formularza.
- Przyciski kopii zapasowej, wyszukiwania i chmury są dostępne na telefonie.
- Biblioteka chmury może pobrać się ponownie po błędzie; pobieranie ma limit czasu.
- Strona odzyskiwania udostępnia oryginalną kopię nieczytelnego zapisu.
- Usunięto nieaktualne wywołanie nieistniejącego pomocnika z testów wbudowanych;
  zastępuje je kontrola migracji jawnie zapisanych miejsc docelowych podań.

## Uruchomienie lokalne

Aplikacja nie wymaga instalacji zależności ani etapu budowania:

```sh
cd /workspace/sigma
python3 -m http.server 4173 --bind 127.0.0.1
```

Serwer statyczny obsługuje interfejs. Funkcja `api/fixture-difficulty.js` wymaga
środowiska Vercel Functions; zwykły serwer Pythona jej nie wykonuje.

## Testy

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m playwright install chromium
.venv/bin/python -m unittest discover -s tests -v
```

Testy korzystają z syntetycznej kariery, osobnych kontekstów przeglądarki i lokalnego
serwera. Blokują połączenia zewnętrzne, nie logują do prawdziwej chmury i nie
modyfikują zapisów użytkownika. Wymagają także Node.js do sprawdzenia składni plików
JavaScript. Jeśli systemowy Chromium nie jest dostępny, używają przeglądarki
zainstalowanej przez Playwright. Opcjonalnie można wskazać binarkę przez
`MATCHBOOK_CHROMIUM_PATH`.

## Wdrożenie na Vercel

Prześlij pliki aplikacji jako katalog główny projektu. Ustaw preset **Other**, bez
komendy budowania, z katalogiem wyjściowym `.`. Zachowaj folder `api`.
Wersje zasobów w `index.html` są podniesione do V35.3, aby przeglądarki pobrały poprawki.

Wdrożenie na tym samym adresie zachowuje dostęp do dotychczasowego localStorage.
Nowy adres ma osobny magazyn przeglądarki — przed zmianą domeny pobierz kopię JSON.
Format danych i klucz magazynu `fesedyo-career-v1` nie zostały zmienione.

Kod chmury zachowuje dotychczasową konfigurację Supabase. Pełne logowanie,
synchronizacja z rzeczywistym kontem i zewnętrzne źródła trudności terminarza
wymagają osobnego sprawdzenia z dostępem do tych usług. Lokalny pakiet nie publikuje
automatycznie zmian na istniejącym wdrożeniu.
