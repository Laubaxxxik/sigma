# V36 · Paper & Coral · kontrola wizualna

Sprawdzono lokalną aplikację w Chromium na syntetycznej karierze.

- Nowa paleta głównych widoków: papierowe tło, śliwka, terakota i koral.
- 19 głównych widoków sprawdzonych przy 360, 390, 768 i 1440 px; brak poszerzania
  całego dokumentu poza ekran.
- Okna profilu, sezonu, występu, terminarza, transferu, notatki, dostępności,
  drabinki, składu, mediów, wyszukiwania, odzyskiwania i podsumowania meczu.
- Dodatkowo okno wyboru zdarzenia/zawodnika, pobieranie JSON i biblioteka klipów.
- Start meczu z formularza działa po pierwszym kliknięciu.
- Panel zdarzeń i podglądy na telefonie sprawdzone w rzeczywistej przeglądarce.
- 20 wbudowanych regresji silnika: 20 zaliczonych, 0 błędów.
- Trzy nowe automatyczne kontrole wyglądu: zaliczone.
- Brak błędów JavaScript w przejściach kontrolnych.

## Statystyki

Treść głównej zakładki Statistics porównano piksel po pikselu z nowym arkuszem
V36 włączonym i wyłączonym: identyczny obraz. Sześć plików odpowiedzialnych za
dotychczasowy wygląd i działanie statystyk pozostaje identycznych bajtowo z ZIP-em
V35.3. Wspólne okienka otwierane ze statystyk mają nową oprawę.

Nie zmieniono formatu kariery, obliczeń, danych użytkownika ani konfiguracji chmury.
Zewnętrzna chmura i źródła rankingu nie są przedmiotem tej zmiany wyglądu.
Paczka nie publikuje automatycznie aktualizacji strony Vercel.

Testy nowego stylu: `python3 -m unittest discover -s tests -p test_theme.py -v`.
Cały zestaw: `python3 -m unittest discover -s tests -v`.
