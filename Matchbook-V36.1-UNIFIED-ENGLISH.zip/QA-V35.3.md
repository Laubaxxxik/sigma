# Weryfikacja V35.3 · 2 listopada 2026

Testowano kod z dołączonej paczki V35.2 po poprawkach, lokalnie w Chromium.

| Kontrola | Wynik |
| --- | --- |
| 20 wbudowanych regresji silnika, migracji i danych | 20 zaliczonych, 0 błędów |
| 19 dostępnych widoków przy 360, 390, 768 i 1440 px | 76 kontroli zaliczonych; brak poziomego rozszerzania dokumentu |
| Nagłówek pulpitu przy 360, 768 i 1440 px | Nie nachodzi na kartę kolejnego meczu |
| Sekcje statystyk i sterowanie klawiaturą | Działają; widoczny jest jeden panel |
| Filtry rozgrywek, ostatnich spotkań, miejsca i reprezentacji | Zaliczone |
| Przeliczniki przy częściowych danych i brakujących minutach | Zaliczone |
| CSV wybranego zakresu i ochrona przed formułami arkusza | Zaliczone; sprawdzono zawartość pobranego pliku |
| Nawigacja, odświeżenie i zachowanie załadowanej kariery | Zaliczone po przygotowaniu danych testowych przez rzeczywisty importer |
| Dodanie występu i odświeżenie strony | Zaliczone; zachowane gole, asysty i liczba występów |
| Przygotowanie meczu, ponowne otwarcie i edycja profilu | Zaliczone |
| Start meczu pierwszym kliknięciem po autouzupełnieniu stadionu | Zaliczone |
| Niedostępne herby i ponowienie pobrania SDK chmury | Zaliczone przy kontrolowanym błędzie sieci |
| Mapa strzałów, Enter i przejście do następnego strzału | Zaliczone |
| Odzyskanie oryginalnej nieczytelnej kopii i ochrona uszkodzonego magazynu | Zaliczone |
| Baza 355 klubów i 217 relacji stadionów | Brak ostrzeżeń audytu |

Zestaw zawiera 22 scenariusze przeglądarkowe. Sprawdzono je w pełnym przebiegu
i powtórkach po poprawkach. Początkowa kontrola bajtowej zgodności po odświeżeniu
wykryła brak normalizacji syntetycznej próbki przed zapisem; próbka przechodzi teraz
przez ten sam importer co rzeczywista kariera. Powtórka dokładnej zgodności danych
oraz startu meczu zakończyła się powodzeniem. Nie pomijano asercji aplikacji.

Składnię JavaScript sprawdzono przez `node --check`. Wszystkie lokalne odwołania
do skryptów i arkuszy w `index.html` prowadzą do istniejących plików.
Końcowe podglądy statystyk i pulpitu nie wygenerowały błędów JavaScript.

## Zakres i ograniczenia

- Dane w testach i na podglądach są syntetyczne. Nie odczytywano kariery użytkownika
  z publicznej strony i nie zmieniano jej zapisów.
- Publiczny adres strony był niedostępny przez politykę sieci środowiska. Bazą prac
  jest dostarczony ZIP; nie potwierdzono identyczności z plikami aktualnie na Vercel.
- Zewnętrzne połączenia w testach były blokowane. Sprawdzono bezpieczne zachowanie
  przy braku sieci i możliwość ponowienia pobrania biblioteki. Nie testowano logowania
  ani synchronizacji z rzeczywistym kontem Supabase, ani zewnętrznych źródeł rankingu.
- Nie opublikowano nowego wdrożenia Vercel.
