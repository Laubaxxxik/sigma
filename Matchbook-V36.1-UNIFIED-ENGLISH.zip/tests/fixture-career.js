// Synthetic test data only; never loaded by index.html.
// Prepare it through the real importer, including existing shot/schema migrations.
() => {
          document.querySelector('#modal').close();
          db.profile={...db.profile,name:'Alex Morgan',club:'Arsenal',nationality:'England',positions:'CAM, CM',number:8,age:23,birthDate:'2003-04-12'};
          db.seasons=[{id:'s1',name:'Arsenal · 2026/27',year:'2026/27',club:'Arsenal',baseM:0,baseG:0,baseA:0,competitions:[{name:'Premier League',status:'In progress'}]}];
          season='s1';
          db.matches=Array.from({length:12},(_,i)=>({id:'m'+i,season:'s1',count:true,teamContext:'club',date:`2026-${i<9?'09':'10'}-${String((i%9)*3+1).padStart(2,'0')}`,home:i%2?'Chelsea':'Arsenal',away:i%2?'Arsenal':'Brighton',opponent:i%2?'Chelsea':'Brighton',playerSide:i%2?'away':'home',score:i%3===0?'2:1':i%3===1?'1:1':'0:1',goals:i%3===0?1:0,assists:i%4===0?1:0,minutes:i%4===0?65:90,rating:6.5+(i%5)*.5,competitionType:i%4===0?'Champions League':'League',competition:i%4===0?'Champions League':'Premier League',competitionName:i%4===0?'Champions League':'Premier League',statsSource:'manual',coverage:i%2?'result':'highlights',position:'CAM',trackedPlayer:'Alex Morgan',actions:i%2?[]:[{type:'Shot on target',minute:15,side:'home',player:'Alex Morgan',location:{x:85,y:45},shot:{body:'right',situation:'openPlay'}},{type:'Pass',minute:20,side:'home',player:'Alex Morgan',location:{x:45,y:50},pass:{destination:{x:65,y:50}}},...(i%3===0?[{type:'Goal',minute:40,side:'home',player:'Alex Morgan',location:{x:90,y:50},shot:{body:'right',situation:'openPlay'}}]:[])]}));
          db.calendarFixtures=[]; db.draft=null; db=prepareCareerForLoad(db); save(); render();
        }
