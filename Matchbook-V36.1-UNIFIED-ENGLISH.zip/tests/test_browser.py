"""Real Chromium checks against an isolated local server and synthetic careers.

Run: python3 -m unittest discover -s tests -v
External requests are deliberately blocked: no real cloud accounts or saves are used.
"""
import functools
import http.server
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import unittest

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = (ROOT / 'tests/fixture-career.js').read_text()


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


class BrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(ROOT)))
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.origin = f'http://127.0.0.1:{cls.server.server_port}'
        cls.pw = sync_playwright().start()
        executable = os.environ.get('MATCHBOOK_CHROMIUM_PATH') or shutil.which('chromium')
        cls.browser = cls.pw.chromium.launch(executable_path=executable, headless=True, args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.context = self.browser.new_context(viewport={'width':1440, 'height':1000}, reduced_motion='reduce')
        self.page = self.context.new_page()
        self.errors = []
        self.page.on('pageerror', lambda error: self.errors.append(error.stack))
        self.page.on('console', lambda message: self.errors.append(message.text) if message.type == 'error' and not message.text.startswith('Failed to load resource:') else None)
        self.page.route('**/*', lambda route: route.continue_() if route.request.url.startswith(self.origin) else route.abort())
        self.page.goto(self.origin, wait_until='networkidle')
        self.page.evaluate(FIXTURE)

    def tearDown(self):
        self.context.close()

    def go(self, name):
        self.page.evaluate('(name) => {page=name;render()}', name)

    def test_assets_and_javascript_syntax(self):
        html = (ROOT / 'index.html').read_text()
        refs = re.findall(r'(?:src|href)="([^"?]+)(?:\?[^" ]*)?"', html)
        for ref in refs:
            if ref.endswith(('.js', '.css')):
                self.assertTrue((ROOT / ref).is_file(), ref)
        for source in [*ROOT.glob('*.js'), *ROOT.glob('api/*.js')]:
            result = subprocess.run(['node', '--check', str(source)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_existing_regressions(self):
        report = self.page.evaluate('Matchbook.runRegressionTests()')
        self.assertGreaterEqual(report['passed'], 20)
        self.assertEqual(report['failed'], 0, json.dumps(report))

    def test_all_pages_and_mobile_widths(self):
        names = ['Dashboard','Matches','Calendar','Statistics','Club squad','Career','Media','Data & Help', 'Seasons','Transfers','International','Notebook','Brackets','Records','Timeline','Availability','Opponents','Tracking Guide','Export']
        for width in [360, 390, 768, 1440]:
            self.page.set_viewport_size({'width':width,'height':1000})
            for name in names:
                with self.subTest(width=width, page=name):
                    print(f'  Checking {name} at {width}px', flush=True)
                    self.go(name)
                    self.assertGreater(len(self.page.locator('#content').inner_text()), 5)
                    dimensions = self.page.evaluate('({actual:document.body.scrollWidth,expected:innerWidth})')
                    self.assertLessEqual(dimensions['actual'], dimensions['expected'] + 1, dimensions)
        self.assertEqual(self.errors, [])

    def test_dashboard_header_does_not_overlap(self):
        for width in [360, 768, 1440]:
            self.page.set_viewport_size({'width':width,'height':1000})
            self.go('Dashboard')
            boxes = self.page.evaluate('''() => {const a=document.querySelector('.v34-pagebar').getBoundingClientRect(), b=document.querySelector('.v34-next-match').getBoundingClientRect(), h=document.querySelector('.v34-pagebar h1').getBoundingClientRect();return {header:a.bottom,next:b.top,title:h.bottom}}''')
            self.assertLessEqual(boxes['title'], boxes['header'] + 1)
            self.assertLessEqual(boxes['header'], boxes['next'])

    def test_mobile_backup_and_cloud_actions_are_accessible(self):
        self.page.set_viewport_size({'width':390,'height':844})
        for selector in ['#backup','#global-search','#cloud-account']:
            self.assertTrue(self.page.locator(selector).is_visible(), selector)
        self.page.locator('#global-search').click()
        self.assertTrue(self.page.locator('#modal').is_visible())

    def test_statistics_sections_and_keyboard(self):
        self.go('Statistics')
        self.page.get_by_role('tab', name='Overview', exact=True).focus()
        self.page.keyboard.press('ArrowRight')
        self.assertEqual(self.page.locator('[role=tab][aria-selected=true]').inner_text(), 'Performance')
        self.assertEqual(self.page.locator('[role=tabpanel]:visible').count(), 1)
        self.page.locator('[data-stat-mode=per90]').click()
        self.assertTrue(self.page.locator('#stats-panel-performance').is_visible())
        self.page.get_by_role('tab', name='Performance', exact=True).focus()
        self.page.keyboard.press('End')
        self.assertTrue(self.page.locator('#stats-panel-career').is_visible())
        self.assertEqual(self.page.locator('[data-stats-context] .v32-context-suite').count(), 1)
        self.assertEqual(self.page.locator('[role=tabpanel]:visible').count(), 1)
        self.page.keyboard.press('Home')
        self.assertTrue(self.page.locator('#stats-panel-overview').is_visible())
        self.assertEqual(self.errors, [])

    def test_competition_recent_and_venue_filters(self):
        self.go('Statistics')
        self.page.locator('[data-profile-category=europe]').click()
        self.assertEqual(self.page.evaluate('analyticsFilter(statisticsSource().matches).length'), 3)
        self.page.locator('[data-stat-reset-all]').first.click()
        self.page.locator('.fm-more-filters summary').click()
        self.page.locator('[name=analytics-venue]').select_option('home')
        self.assertEqual(self.page.evaluate('analyticsFilter(statisticsSource().matches).length'), 6)
        self.page.locator('[data-stat-recent="5"]').click()
        self.assertEqual(self.page.evaluate('analyticsFilter(statisticsSource().matches).length'), 5)
        self.page.locator('[data-stat-reset-all]').first.click()
        self.assertEqual(self.page.evaluate('analyticsFilter(statisticsSource().matches).length'), 12)

    def test_all_category_includes_international(self):
        result = self.page.evaluate('''() => {const m={...db.matches[0],id:'international-test',teamContext:'international',sourceClubSeasonId:'s1',home:'England',away:'France',nationalTeamId:'england'};db.matches.push(m);page='Statistics';render();return {all:statisticsSource().matches.length,included:profileCategoryMatches(m,'all'),league:profileCategoryMatches(m,'league')}}''')
        self.assertEqual(result, {'all':13,'included':True,'league':False})

    def test_manual_matches_support_venue_filter(self):
        count = self.page.evaluate('''() => {analyticsState.venue='home';return analyticsFilter([{venueType:'home',minutes:90},{venueType:'away',minutes:90},{venueType:'neutral',minutes:90}]).length}''')
        self.assertEqual(count, 1)

    def test_rates_use_metric_coverage_and_unknown_minutes(self):
        values = self.page.evaluate('''() => {
          const r={sum:{shots:4},coverage:{shots:1},count:2,minutes:180,rows:[{m:{minutes:90},available:new Set(['shots'])},{m:{minutes:90},available:new Set()}]};
          const observed=metricDisplay(r,'shots','per90'),perMatch=metricDisplay(r,'shots','perMatch');
          r.rows[1].m.minutes='';const untrackedUnknown=metricDisplay(r,'shots','per90');
          r.rows[0].m.minutes='';const trackedUnknown=metricDisplay(r,'shots','per90');
          r.coverage.shots=0;const noData=metricDisplay(r,'shots');
          return {observed,perMatch,untrackedUnknown,trackedUnknown,noData};
        }''')
        self.assertEqual(values, {'observed':'4','perMatch':'4','untrackedUnknown':'4','trackedUnknown':'—','noData':'—'})

    def test_result_only_summaries_do_not_raise_false_event_warning(self):
        self.assertEqual(self.page.evaluate("analyticsGoalWarnings([{...db.matches[0],actions:[],goals:2,coverage:'result'}])"), '')
        self.assertIn('Goal totals differ', self.page.evaluate("analyticsGoalWarnings([{...db.matches[0],actions:[],goals:2,coverage:'full'}])"))

    def test_csv_export_uses_filters_and_escapes_spreadsheet_input(self):
        self.go('Statistics')
        self.page.locator('[data-profile-category=europe]').click()
        with self.page.expect_download() as event:
            self.page.locator('[data-stats-export]').click()
        content = Path(event.value.path()).read_text(encoding='utf-8-sig')
        self.assertEqual(len(content.splitlines()), 4)
        self.assertIn('Champions League', content)
        self.assertNotIn('Premier League', content)
        cells = self.page.evaluate('''() => [statisticsCsvCell('=1+1'),statisticsCsvCell('  @SUM(A1)'),statisticsCsvCell('a"b,c')]''')
        self.assertEqual(cells, ['"\'=1+1"','"\'  @SUM(A1)"','"a""b,c"'])

    def test_navigation_and_reload_preserve_career(self):
        before = self.page.evaluate('JSON.stringify(db.matches)')
        for name in ['Statistics', 'Matches', 'Calendar', 'Career', 'Dashboard']:
            self.page.locator(f'#nav [data-page="{name}"]').click()
        self.assertEqual(self.page.evaluate('JSON.stringify(db.matches)'), before)
        self.page.reload(wait_until='networkidle')
        self.assertEqual(self.page.evaluate('JSON.stringify(db.matches)'), before)
        self.assertEqual(self.page.evaluate('db.profile.name'), 'Alex Morgan')
        self.assertFalse(self.page.evaluate('storageState.blocked'))

    def test_new_appearance_is_saved_with_unknown_metrics_and_correct_venue(self):
        self.page.evaluate("act('new-match')")
        for name,value in {'opponent':'Liverpool','date':'2026-11-02','score':'2:0','minutes':'90','goals':'1','assists':'1','rating':'8.4'}.items():
            self.page.locator(f'[name="{name}"]').fill(value)
        self.page.locator('#form button[type=submit]').click()
        self.assertEqual(self.page.evaluate('db.matches.length'), 13)
        self.assertEqual(self.page.evaluate('db.matches.at(-1).goals'), 1)
        details = self.page.evaluate('''() => {const m=db.matches.at(-1);return {html:v32MatchCentreSummary(m),shots:v32StatForMatch(m,'shots')}}''')
        self.assertIn('Home', details['html'])
        self.assertIn('—</b><small>xG', details['html'])
        self.assertIn('—</b><small>xA', details['html'])
        self.assertIsNone(details['shots'])
        self.page.reload(wait_until='networkidle')
        self.assertEqual(self.page.evaluate('db.matches.length'), 13)
        self.assertEqual(self.errors, [])

    def test_shot_map_keyboard_selection(self):
        self.go('Statistics')
        marker = self.page.locator('[data-shot-map-marker]').first
        marker.focus()
        marker.press('Enter')
        self.assertTrue(self.page.locator('[data-shot-detail-content]').is_visible())
        self.assertFalse(self.page.locator('[data-shot-detail-placeholder]').is_visible())
        self.page.get_by_role('button', name='Next shot', exact=True).click()
        self.assertTrue(self.page.locator('[data-shot-detail-content]').is_visible())
        self.assertEqual(self.errors, [])

    def test_match_setup_can_be_reopened_and_profile_resets_layout(self):
        self.page.evaluate("act('live')")
        self.page.wait_for_selector('.v34-setup-grid')
        self.page.evaluate("document.querySelector('#modal').close()")
        self.page.evaluate("act('live')")
        self.page.wait_for_selector('.v34-setup-grid')
        self.assertEqual(self.page.locator('.v34-setup-grid').count(), 1)
        self.page.evaluate("document.querySelector('#modal').close();act('profile')")
        self.assertFalse(self.page.locator('#modal').evaluate("e=>e.classList.contains('v34-setup-modal')"))
        self.assertFalse(self.page.locator('#form').evaluate("e=>e.classList.contains('v34-setup-form')"))
        self.assertEqual(self.errors, [])

    def test_match_starts_with_first_click_after_autofill(self):
        self.page.evaluate("act('live')")
        self.page.wait_for_selector('.v34-setup-grid')
        self.assertEqual(self.page.locator('#venue-name').get_attribute('aria-expanded'), 'false')
        self.page.locator('[name=lineupMode]').select_option('manual')
        self.page.locator('[name=away]').fill('Liverpool')
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_selector('#add-event')
        self.assertTrue(self.page.evaluate('db.draft.started'))
        self.assertEqual(self.errors, [])

    def test_invalid_date_falls_back_and_recent_matches_are_sorted(self):
        self.page.evaluate("db.matches.unshift({...db.matches[0],id:'newest-test',date:'2026-12-01',opponent:'Newest'});db.matches.push({...db.matches[1],id:'undated-test',date:'unknown'});page='Matches';render()")
        self.assertEqual(self.page.locator('.v34-match-row').first.get_attribute('data-action'), 'recap:newest-test')
        self.assertIn('Undated', self.page.locator('#content').inner_text())
        self.assertEqual(self.errors, [])

    def test_empty_statistics_have_no_fake_matches(self):
        self.page.evaluate("db.matches=[];db.seasons=[];season='';page='Statistics';render()")
        self.assertIn('Your next match starts the story', self.page.locator('#content').inner_text())
        self.assertTrue(self.page.locator('[data-stats-export]').is_disabled())
        self.assertEqual(self.errors, [])

    def test_failed_cloud_download_can_retry(self):
        outcomes = self.page.evaluate('''async () => {const out=[];for(let i=0;i<2;i++)out.push(await Promise.race([loadSupabaseSdk().then(()=>'loaded',()=> 'failed'),new Promise(r=>setTimeout(()=>r('stuck'),1500))]));return out}''')
        self.assertEqual(outcomes, ['failed','failed'])
        self.assertEqual(self.page.locator('script[data-matchbook-supabase]').count(), 0)

    def test_recovery_includes_original_unreadable_save(self):
        self.page.evaluate("localStorage.setItem(KEY+'-unreadable','original unreadable bytes')")
        self.page.goto(self.origin + '/recovery.html', wait_until='networkidle')
        record = self.page.locator('#records article').filter(has_text='Protected previous save')
        self.assertEqual(record.count(), 1)
        with self.page.expect_download() as event:
            record.get_by_role('button').click()
        self.assertEqual(Path(event.value.path()).read_text(), 'original unreadable bytes')

    def test_corrupt_storage_is_preserved(self):
        self.page.evaluate("localStorage.setItem(KEY,'{broken original')")
        self.page.reload(wait_until='networkidle')
        self.assertTrue(self.page.evaluate('storageState.blocked'))
        self.assertEqual(self.page.evaluate('localStorage.getItem(KEY)'), '{broken original')


if __name__ == '__main__':
    unittest.main()
