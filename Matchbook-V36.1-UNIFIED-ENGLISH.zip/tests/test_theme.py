"""V36.1: statistics content and layout survive recolouring; dialogs fit a phone."""
from pathlib import Path
import unittest
import test_browser as harness


class ThemeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        harness.BrowserTests.setUpClass()
        cls.app = harness.BrowserTests('test_existing_regressions')
        cls.app.setUp()
        cls.page = cls.app.page

    @classmethod
    def tearDownClass(cls):
        cls.app.tearDown()
        harness.BrowserTests.tearDownClass()

    def test_statistics_layout_and_content_survive_colour_change(self):
        snapshot = '''() => {
          const root=document.querySelector('#content'),r=root.getBoundingClientRect();
          return {html:root.innerHTML,boxes:[...root.querySelectorAll('.fm-player-card,.fm-season-card,.fm-season-summary,.mb-stats-tabs,.mb-form-card,.mb-snapshot,.mb-form-column,.shot-map-panel,.fm-performance,.fm-stat-row,.fm-match-table,.fm-career-layout,.fm-coverage')].map(e=>{
            const b=e.getBoundingClientRect();return {cls:e.className,box:[b.x-r.x,b.y-r.y,b.width,b.height].map(v=>Math.round(v*100)/100),grid:getComputedStyle(e).gridTemplateColumns};
          })};
        }'''
        self.app.go('Statistics')
        data_before = self.page.evaluate('JSON.stringify(db.matches)')
        for width in [1440,390]:
            self.page.set_viewport_size({'width':width,'height':1000})
            for view in ['overview','performance','matches','career']:
                with self.subTest(width=width,view=view):
                    self.page.evaluate('(v)=>selectStatisticsView(v,false)',view)
                    self.page.wait_for_timeout(120)
                    self.page.evaluate("document.querySelector('link[href^=\"v36-theme\"]').disabled=true")
                    before = self.page.evaluate(snapshot)
                    old_bg = self.page.locator('.fm-player-card').evaluate('e=>getComputedStyle(e).backgroundColor')
                    self.page.evaluate("document.querySelector('link[href^=\"v36-theme\"]').disabled=false")
                    after = self.page.evaluate(snapshot)
                    new_bg = self.page.locator('.fm-player-card').evaluate('e=>getComputedStyle(e).backgroundColor')
                    self.assertEqual(before, after)
                    self.assertNotEqual(old_bg, new_bg)
                    self.assertLessEqual(self.page.evaluate('document.body.scrollWidth'),width)
        self.assertEqual(self.page.evaluate('JSON.stringify(db.matches)'), data_before)

    def test_statistics_filters_export_and_shot_map_remain_available(self):
        self.app.go('Statistics')
        self.page.evaluate("selectStatisticsView('overview',false)")
        self.page.locator('[data-profile-category=europe]').click()
        self.assertEqual(self.page.evaluate('analyticsFilter(statisticsSource().matches).length'),3)
        with self.page.expect_download() as event:
            self.page.locator('[data-stats-export]').click()
        csv = Path(event.value.path()).read_text(encoding='utf-8-sig')
        self.assertEqual(len(csv.splitlines()),4)
        self.assertIn('Champions League',csv)
        self.page.locator('[data-stat-reset-all]').first.click()
        self.page.evaluate("selectStatisticsView('performance',false)")
        self.page.locator('[data-stat-mode=per90]').click()
        self.assertTrue(self.page.locator('#stats-panel-performance').is_visible())
        self.page.evaluate("selectStatisticsView('overview',false)")
        marker=self.page.locator('[data-shot-map-marker]').first
        marker.focus();marker.press('Enter')
        self.assertTrue(self.page.locator('[data-shot-detail-content]').is_visible())
        self.assertRegex(self.page.locator('[data-shot-detail-date]').inner_text(),r'\d+ (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4}')
        self.assertEqual(self.app.errors,[])

    def test_windows_fit_a_phone_and_keep_form_fields_accessible(self):
        self.app.go('Dashboard')
        self.page.set_viewport_size({'width':390,'height':844})
        actions = ["act('profile')", "act('new-season')", "act('new-match')",
                   'openCalendarFixture()', "act('new-transfer')", "act('new-canon')",
                   'v32OpenAvailability()', 'openV2BracketCreate()', 'editClubLineup()',
                   'mediaAccountEditor()', 'openGlobalSearch()', 'recoveryPanel()',
                   'matchRecap(db.matches[0])', 'careerClips()', 'openStoryStudio()']
        for action in actions:
            with self.subTest(action=action):
                self.page.evaluate("document.querySelector('#modal').close()")
                self.page.evaluate(action)
                box = self.page.locator('#modal').evaluate('''e=>({width:e.getBoundingClientRect().width,client:e.clientWidth,scroll:e.scrollWidth,bg:getComputedStyle(e).backgroundColor})''')
                self.assertLessEqual(box['width'], 390)
                self.assertLessEqual(box['scroll'], box['client'] + 1, box)
                self.assertNotIn('v34-live-modal', self.page.locator('#modal').get_attribute('class'))
        self.page.evaluate("document.querySelector('#modal').close()")
        self.assertEqual(self.app.errors, [])

    def test_auxiliary_picker_and_backup_windows(self):
        self.app.go('Dashboard')
        self.page.set_viewport_size({'width':390,'height':844})
        self.page.evaluate("downloadJson(JSON.stringify(db),'theme-test.json')")
        self.assertTrue(self.page.locator('#json-export-dialog').is_visible())
        colors = self.page.locator('#json-download').evaluate('e=>({fg:getComputedStyle(e).color,bg:getComputedStyle(e).backgroundColor})')
        self.assertNotEqual(colors['fg'], colors['bg'])
        self.page.locator('#json-close').click()
        self.page.evaluate("act('live')")
        self.page.wait_for_selector('.v34-setup-grid')
        self.page.locator('[name=lineupMode]').select_option('manual')
        self.page.locator('[name=away]').fill('Liverpool')
        self.page.locator('#form button[type=submit]').click()
        self.page.wait_for_selector('#add-event')
        self.page.evaluate("openPlayerPicker(document.querySelector('#form [name=type]'))")
        picker = self.page.locator('#player-search-dialog')
        self.assertTrue(picker.is_visible())
        self.assertLessEqual(picker.bounding_box()['width'], 390)
        self.assertEqual(picker.evaluate('e=>getComputedStyle(e).backgroundColor'), 'rgb(255, 250, 244)')
        self.page.locator('#player-search-close').click()
        self.page.evaluate("document.querySelector('#modal').close()")

    def test_historical_descriptions_display_english_without_rewriting_records(self):
        saved = self.page.evaluate('JSON.stringify(db.matches)')
        note = 'liga konferencji · Data: 07.10.2026\nDobry mecz, wynik 2:1. https://example.com/2026-10-07'
        try:
            self.page.evaluate('''(note)=>{const m=db.matches.at(-1);m.competition='liga konferencji';m.competitionName='liga konferencji';m.competitionType='Conference League';m.date='7 października 2026';m.events=note;Matchbook.cache.invalidate();page='Matches';render()}''',note)
            before = self.page.evaluate('JSON.stringify(db.matches)')
            self.assertIn('Conference League',self.page.locator('#content').inner_text())
            self.assertIn('7 Oct 2026',self.page.locator('#content').inner_text())
            self.page.evaluate('matchRecap(db.matches.at(-1))')
            descriptions='\n'.join(self.page.locator('#form .listtext').all_text_contents())
            self.assertIn('Conference League',descriptions)
            self.assertIn('7 October 2026',descriptions)
            self.assertIn('https://example.com/2026-10-07',descriptions)
            self.assertIn('7 October 2026',self.page.evaluate('context()'))
            self.page.evaluate("document.querySelector('#modal').close();editMatch(db.matches.at(-1))")
            self.assertEqual(self.page.locator('#form [name=events]').input_value(),note)
            self.assertEqual(self.page.locator('#form [name=date]').input_value(),'7 października 2026')
            self.assertEqual(self.page.evaluate('JSON.stringify(db.matches)'),before)
            option=self.page.evaluate('''()=>{const s=document.createElement('select');s.innerHTML='<option>liga konferencji</option>';document.querySelector('#content').append(s);MatchbookEnglish.localiseRenderedText();const result={value:s.value,label:s.options[0].textContent};s.remove();return result}''')
            self.assertEqual(option,{'value':'liga konferencji','label':'Conference League'})
            self.assertEqual(self.app.errors,[])
        finally:
            self.page.evaluate("(saved)=>{document.querySelector('#modal').close();db.matches=JSON.parse(saved);Matchbook.cache.invalidate();page='Dashboard';render()}",saved)


if __name__ == '__main__':
    unittest.main()
