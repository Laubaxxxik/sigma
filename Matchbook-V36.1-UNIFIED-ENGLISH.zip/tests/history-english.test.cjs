const {test}=require('node:test');
const assert=require('node:assert/strict');
const {text,dateText}=require('../history-english.js');

test('recognises competition names regardless of case and Polish inflection',()=>{
  assert.equal(text('liga konferencji · Liga Mistrzów · LIGA EUROPY'), 'Conference League · Champions League · Europa League');
  assert.equal(text('w Lidze Konferencji, finał Ligi Mistrzów'), 'w Conference League, finał Champions League');
  assert.equal(text('UEFA Liga Konferencji Europy'), 'UEFA Conference League');
  assert.equal(text('Superpuchar Europy; Puchar Polski; Puchar ligi'), 'UEFA Super Cup; Polish Cup; League cup');
});
test('written Polish dates use English month names',()=>{
  assert.equal(text('7 października 2026 r. — liga konferencji'), '7 October 2026 — Conference League');
  assert.equal(text('07 pazdziernika 2026',{compact:true}), '7 Oct 2026');
  assert.equal(text('7 paź. 2026 r'), '7 October 2026');
  assert.equal(text('2 lis 2026, 20:30'), '2 November 2026, 20:30');
  const months=['stycznia','lutego','marca','kwietnia','maja','czerwca','lipca','sierpnia','września','października','listopada','grudnia'];
  months.forEach((month,index)=>assert.equal(text(`7 ${month} 2026`),dateText(2026,index+1,7)));
});
test('numeric historical dates are day-first; ISO dates also work',()=>{
  assert.equal(text('07.10.2026 / 2026-12-31 / 11/02/2026'), '7 October 2026 / 31 December 2026 / 11 February 2026');
  assert.equal(text('29 lutego 2024'), '29 February 2024');
});
test('invalid dates, season labels, scores and unrelated names stay original',()=>{
  const original='31 lutego 2026 · 31.04.2026 · 2026-13-01 · 2026/27 · 2:1 · 90+3′ · xG 0.78 · Jan Maj · Ligue 1';
  assert.equal(text(original),original);
  assert.equal(text('konferencja prasowa; mistrz klubu'), 'konferencja prasowa; mistrz klubu');
});
test('links and structured timestamps are preserved',()=>{
  const url='https://example.com/2026-10-07/report?date=07.10.2026';
  assert.equal(text(`${url} — Liga Konferencji`),`${url} — Conference League`);
  assert.equal(text('2026-10-07T20:30:00Z'),'2026-10-07T20:30:00Z');
});
test('translation is idempotent and leaves other description text alone',()=>{
  const original='Dobry mecz. liga konferencji, 7 października 2026. Alex: 2 gole.';
  const result=text(original);
  assert.equal(result,'Dobry mecz. Conference League, 7 October 2026. Alex: 2 gole.');
  assert.equal(text(result),result);
});
