/* Matchbook V32.7 — final player-profile polish + global competition filters. */
let profileCompetitionCategory='all';

function profileCompetitionBucket(match){
  if(typeof isInternationalRecord==='function'&&isInternationalRecord(match))return 'international';
  const category=typeof competitionCategory==='function'?competitionCategory(match):String(match?.competitionType||'');
  if(category==='League')return 'league';
  if(['Champions League','Europa League','Conference League'].includes(category))return 'europe';
  if(['Domestic cup','League cup','Super cup'].includes(category))return 'domestic';
  return 'other';
}
function profileCategoryLabel(value){return ({all:'All',league:'League',europe:'Europe',domestic:'Domestic Cups',international:'International'})[value]||value}
function profileMatchBelongsToSeason(match,seasonId){
  if(seasonId==='@career')return true;
  if(typeof isInternationalRecord==='function'&&isInternationalRecord(match))return match.sourceClubSeasonId===seasonId;
  return match.season===seasonId;
}
function profilePeriodViews(){
  const out=[];
  for(const raw of (db.matches||[])){
    if(!raw?.count||!profileMatchBelongsToSeason(raw,season))continue;
    try{out.push(matchView(raw))}catch{}
  }
  return out;
}
function profileAvailableCategories(){
  const rows=profilePeriodViews(),set=new Set(rows.map(profileCompetitionBucket));
  const order=['all','league','europe','domestic','international'];
  return order.filter(k=>k==='all'||set.has(k));
}
function profileCompetitionName(match){
  if(typeof isInternationalRecord==='function'&&isInternationalRecord(match))return typeof internationalCompetitionName==='function'?internationalCompetitionName(match):String(match.competitionName||match.competition||'International');
  return String(match.competitionName||match.leagueName||match.competition||competitionCategory(match)||'').split(' · ')[0].trim();
}
function profileCategoryMatches(match,category=profileCompetitionCategory){
  if(category==='all')return true;
  return profileCompetitionBucket(match)===category;
}
function profileCompetitionOptions(){
  const rows=profilePeriodViews().filter(m=>profileCategoryMatches(m));
  return [...new Set(rows.map(profileCompetitionName).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
}
function playerInitials(name){return String(name||'P').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'P'}
function playerPhotoMarkup(className=''){
  const p=db.profile||{},photo=String(p.photoData||'');
  return photo?`<span class="player-photo ${className}"><img src="${esc(photo)}" alt="${esc(p.name||'Player')} profile photo"></span>`:`<span class="player-photo player-photo-fallback ${className}" aria-label="${esc(p.name||'Player')} profile photo fallback">${esc(playerInitials(p.name))}</span>`;
}
async function playerPhotoDataFromFile(file){
  if(!file||!String(file.type||'').startsWith('image/'))throw new Error('Choose an image file.');
  const raw=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('Could not read image.'));r.readAsDataURL(file)});
  const image=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Could not decode image.'));img.src=raw});
  const targetW=360,targetH=450,sourceW=image.naturalWidth||1,sourceH=image.naturalHeight||1,sourceRatio=sourceW/sourceH,targetRatio=targetW/targetH;
  let sx=0,sy=0,sw=sourceW,sh=sourceH;
  if(sourceRatio>targetRatio){sw=sourceH*targetRatio;sx=(sourceW-sw)/2}else{sh=sourceW/targetRatio;sy=(sourceH-sh)/2}
  const canvas=document.createElement('canvas');canvas.width=targetW;canvas.height=targetH;
  const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('Image processing is unavailable in this browser.');
  ctx.fillStyle='#151a20';ctx.fillRect(0,0,targetW,targetH);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(image,sx,sy,sw,sh,0,0,targetW,targetH);
  let quality=.82,data=canvas.toDataURL('image/webp',quality);
  while(data.length>150000&&quality>.5){quality-=.08;data=canvas.toDataURL('image/webp',quality)}
  if(data.length>190000)throw new Error('Photo could not be reduced enough. Try a different image.');
  return data;
}
function trophyIconSvg(){return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h10v3c0 3.6-2 6.4-5 7.3C9 13.4 7 10.6 7 7V4Zm-3 2h3v2H6c0 1.7.9 3 2.4 3.5l-.8 1.8C4.9 12.4 4 10.2 4 8V6Zm13 0h3v2c0 2.2-.9 4.4-3.6 5.3l-.8-1.8C18.1 11 19 9.7 19 8h-2V6ZM11 14h2v3h4v2H7v-2h4v-3Z"/></svg>`}
function matchOpponentForProfile(m){
  if(typeof isInternationalRecord==='function'&&isInternationalRecord(m)&&typeof internationalOpponent==='function')return internationalOpponent(m);
  return m.playerSide==='home'?(m.away||m.opponent):(m.home||m.opponent);
}
function matchOpponentBadge(m,name){
  if(typeof isInternationalRecord==='function'&&isInternationalRecord(m)&&typeof nationalTeamBadge==='function')return nationalTeamBadge(typeof internationalTeamByName==='function'?(internationalTeamByName(name)||{name,countryCode:m.opponentCountryCode||''}):{name,countryCode:m.opponentCountryCode||''});
  return typeof clubBadge==='function'?clubBadge(name):'';
}
function currentNationalTeamMarkup(){
  const team=typeof internationalTeamById==='function'?internationalTeamById(db.profile?.nationalTeamId):null;
  return team&&typeof nationalTeamBadge==='function'?`${nationalTeamBadge(team)}<span>${esc(team.name)}</span>`:'';
}

function installProfilePolishV327(){
  const sourceBase=statisticsSource;
  statisticsSource=function(){
    const available=profileAvailableCategories();if(!available.includes(profileCompetitionCategory))profileCompetitionCategory='all';
    const matches=[],errors=[];
    for(const raw of (db.matches||[]).filter(m=>m?.count&&profileMatchBelongsToSeason(m,season)&&profileCategoryMatches(m))){
      try{const view=matchView(raw);view.analyticsMinutesKnown=(raw.statsSource==='events'&&eventSummary(raw).minutesKnown)||(raw.minutes!==''&&raw.minutes!=null&&Number.isFinite(Number(raw.minutes)));aggregateStats([view],true);matches.push(view)}catch(error){errors.push({id:raw.id,name:raw.opponent||[raw.home,raw.away].filter(Boolean).join(' — ')||'Unnamed match',message:error?.message||String(error)})}
    }
    const names=new Set(matches.map(profileCompetitionName).filter(Boolean));if(statsCompetition&&!names.has(statsCompetition))statsCompetition='';
    return {matches,errors};
  };
  analyticsCategoryMatches=function(m,value){return !value||value===profileCompetitionName(m)||value===competitionCategory(m)||value===analyticsCompetition(m)};

  fotmobSeasonSummary=function(range,list,a){
    const rows=range.rows,starts=rows.filter(r=>analyticsRole(r.m)==='starter').length,yellow=metricDisplay(range,'yellow','total'),red=metricDisplay(range,'directRed','total'),rating=a.avg?.toFixed(2)||'—';
    const items=[[a.goals,'Goals'],[a.assists,'Assists'],[starts,'Started'],[list.length,'Matches'],[range.minutes??'—','Minutes played'],[rating,'Rating'],[yellow,'Yellow cards'],[red,'Red cards']];
    const cats=profileAvailableCategories();if(!cats.includes(profileCompetitionCategory))profileCompetitionCategory='all';
    const comps=profileCompetitionOptions();if(statsCompetition&&!comps.includes(statsCompetition))statsCompetition='';
    const chips=`<nav class="fm-global-filters" aria-label="Competition type">${cats.map(k=>`<button type="button" data-profile-category="${k}" aria-pressed="${profileCompetitionCategory===k}">${profileCategoryLabel(k)}</button>`).join('')}</nav>`;
    const secondary=comps.length>1?`<label>Competition<select id="stats-competition"><option value="">All competitions</option>${comps.map(c=>`<option value="${esc(c)}" ${c===statsCompetition?'selected':''}>${esc(c)}</option>`).join('')}</select></label>`:'';
    return `<section class="fm-season-card"><div class="fm-season-head"><div><span class="fm-eyebrow">${esc(season==='@career'?'CAREER':'SEASON PERFORMANCE')}</span><h2>${esc(season==='@career'?'Entire career':current().name||season)}</h2></div><div class="fm-season-selects"><label>Season${selectSeason()}</label>${secondary}</div></div>${chips}<div class="fm-season-summary">${items.map(([v,l])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div></section>`;
  };

  fotmobProfileHeader=function(){
    const p=db.profile||{},club=fmLatestSeason()?.club||p.club||'',age=typeof profileAge==='function'?profileAge(p):p.age,positions=String(p.positions||'').split(',').map(x=>x.trim()).filter(Boolean),primary=positions[0]||'—',other=positions.slice(1),contractEnd=p.contractEnd?fmPrettyDate(p.contractEnd):(p.contract||''),birth=p.birthDate?fmPrettyDate(p.birthDate):'',market=fmCurrentMarketValue(),facts=[];
    if(p.height)facts.push(['Height',`${p.height} cm`]);if(p.number)facts.push(['Shirt',`#${p.number}`]);if(age!=null&&age!=='')facts.push(['Age',String(age)]);if(birth)facts.push(['Date of birth',birth]);if(p.foot)facts.push(['Preferred foot',p.foot]);if(p.nationality)facts.push(['Nationality',p.nationality]);if(market.value!=null)facts.push(['Market value',fmFormatMarketValue(market.value)]);if(contractEnd)facts.push(['Contract end',contractEnd]);
    const national=currentNationalTeamMarkup();
    return `<section class="fm-player-card fm-player-card-photo"><div class="fm-player-portrait">${playerPhotoMarkup('large')}</div><div class="fm-player-main"><span class="fm-eyebrow">PLAYER PROFILE</span><h1>${esc(p.name||'Player')}</h1><div class="fm-player-clubline">${club&&typeof clubBadge==='function'?clubBadge(club):''}<strong>${esc(club||'Entire career')}</strong></div>${national?`<div class="fm-player-national">${national}</div>`:''}<div class="fm-position-block"><small>Position</small><div class="fm-position-pills">${positions.length?positions.map((x,i)=>`<span ${i===0?'class="primary"':''}>${esc(x)}</span>`).join(''):'<span>—</span>'}</div>${other.length?`<small>Primary: ${esc(primary)} · Other: ${esc(other.join(', '))}</small>`:''}</div></div><div class="fm-player-facts">${facts.map(([l,v])=>`<div><small>${esc(l)}</small><b>${esc(v)}</b></div>`).join('')}</div></section>`;
  };

  fotmobRecentMatches=function(range){
    const rows=range.rows.slice(-10).reverse();if(!rows.length)return '';
    const card=row=>{const m=row.m,opp=matchOpponentForProfile(m),badge=matchOpponentBadge(m,opp),comp=profileCompetitionName(m)||'Match',isInt=typeof isInternationalRecord==='function'&&isInternationalRecord(m),compLabel=isInt?`${comp} · ${analyticsClub(m)}${typeof internationalLevel==='function'?` · ${internationalLevel(m)}`:''}`:comp,mins=suppliedNumber(m.minutes),pos=m.position||m.playerPosition||m.role||'—',yellow=row.available.has('yellow')?num(row.s.yellow):'—',red=row.available.has('directRed')?num(row.s.directRed):'—',rating=suppliedNumber(m.rating),out=matchOutcome(m,analyticsClub(m));return `<button type="button" class="fm-match-row" data-action="recap:${esc(m.id)}"><span class="fm-match-comp">${esc(compLabel)}</span><span class="fm-match-date">${esc(m.date||'—')}</span><span class="fm-match-opponent"><i>${badge}</i><span><b>${esc(opp||'Opponent')}</b><small>${esc(m.score||'—')}</small></span></span><span>${mins===null?'—':mins}</span><span>${esc(pos)}</span><span>${num(m.goals)}</span><span>${num(m.assists)}</span><span>${yellow}</span><span>${red}</span><span class="fm-rating ${rating!==null&&rating>=8?'high':rating!==null&&rating>=7?'good':rating!==null&&rating<6.5?'low':''}" data-result="${esc(out||'')}">${rating===null?'—':rating.toFixed(1)}</span></button>`};
    return `<section class="fm-matches-card"><div class="fm-section-title"><div><span class="fm-eyebrow">MATCH STATS</span><h2>Recent matches</h2></div><small>Latest ${rows.length} recorded appearances</small></div><div class="fm-match-table"><div class="fm-match-header"><span>Competition</span><span>Date</span><span>Opponent</span><span>Min</span><span>Pos</span><span>G</span><span>A</span><span>YC</span><span>RC</span><span>Rating</span></div>${rows.map(card).join('')}</div></section>`;
  };

  fotmobCareer=function(){
    const rows=typeof fmCareerRows==='function'?fmCareerRows():[];
    const intl=(db.matches||[]).filter(m=>m?.count&&typeof isInternationalRecord==='function'&&isInternationalRecord(m));
    const groups=new Map();
    for(const raw of intl){const view=matchView(raw),team=typeof internationalTeamById==='function'?internationalTeamById(raw.nationalTeamId):null,teamName=team?.name||analyticsClub(view)||'National team',level=typeof internationalLevel==='function'?internationalLevel(raw):raw.nationalTeamLevel||'Senior',key=`${raw.nationalTeamId||teamName}|${level}`;if(!groups.has(key))groups.set(key,{team,teamName,level,m:0,g:0,a:0});const row=groups.get(key);row.m++;row.g+=num(view.goals);row.a+=num(view.assists)}
    if(!rows.length&&!groups.size)return '';
    return `<section class="fm-career"><div class="fm-section-title"><div><span class="fm-eyebrow">CAREER</span><h2>Senior career</h2></div></div>${rows.length?`<div class="fm-career-head"><span>Club</span><span>Seasons</span><span>Apps</span><span>Goals</span><span>Assists</span></div>${rows.map(r=>`<div class="fm-career-row"><span class="fm-career-club">${typeof clubBadge==='function'?clubBadge(r.club):''}<b>${esc(r.club)}</b></span><span>${esc(r.seasons.join(' · '))}</span><b>${r.m}</b><b>${r.g}</b><b>${r.a}</b></div>`).join('')}`:''}${groups.size?`<div class="fm-career-subhead">National team</div>${[...groups.values()].map(r=>`<div class="fm-career-row"><span class="fm-career-club">${typeof nationalTeamBadge==='function'&&r.team?nationalTeamBadge(r.team):''}<b>${esc(r.teamName)}</b></span><span>${esc(r.level)}</span><b>${r.m}</b><b>${r.g}</b><b>${r.a}</b></div>`).join('')}`:''}</section>`;
  };

  if(typeof fotmobTrophies==='function'){
    const trophiesBase=fotmobTrophies;
    fotmobTrophies=function(){return trophiesBase().replaceAll('<span class="fm-trophy-icon">🏆</span>',`<span class="fm-trophy-icon">${trophyIconSvg()}</span>`)};
  }

  const profileBase=editPlayerProfile;
  editPlayerProfile=function(first=false){
    profileBase(first);const form=$('#form');if(!form||form.querySelector('#player-photo-file'))return;
    const p=db.profile||{},section=form.querySelector('.profile-section');
    const html=`<div class="wide profile-photo-editor"><div class="profile-photo-preview">${playerPhotoMarkup('editor')}</div><div><h3>Player photo</h3><p>Optional profile portrait. Matchbook automatically crops and compresses it so it does not overload browser storage.</p><input id="player-photo-file" type="file" accept="image/png,image/jpeg,image/webp,image/avif"><input type="hidden" name="photoData" value="${esc(p.photoData||'')}"><div class="actions"><button type="button" id="player-photo-remove" ${p.photoData?'':'hidden'}>Remove photo</button></div><small id="player-photo-status"></small></div></div>`;
    section?.insertAdjacentHTML('afterend',html);
    const input=$('#player-photo-file'),hidden=form.elements.namedItem('photoData'),preview=form.querySelector('.profile-photo-preview'),remove=$('#player-photo-remove'),status=$('#player-photo-status'),saveButton=form.querySelector('button[type="submit"]');
    input?.addEventListener('change',async()=>{const file=input.files?.[0];if(!file)return;saveButton.disabled=true;status.textContent='Preparing photo…';try{const data=await playerPhotoDataFromFile(file);hidden.value=data;preview.innerHTML=`<span class="player-photo editor"><img src="${esc(data)}" alt="Player photo preview"></span>`;remove.hidden=false;status.textContent='Photo ready to save.'}catch(error){input.value='';status.textContent=error.message}finally{saveButton.disabled=false}});
    remove?.addEventListener('click',()=>{hidden.value='';input.value='';preview.innerHTML=`<span class="player-photo player-photo-fallback editor">${esc(playerInitials(p.name))}</span>`;remove.hidden=true;status.textContent='Photo will be removed when you save.'});
  };


  /* Finish Location: preserve existing normalized 0–100 goal coordinates, but allow
     a small outside-goal range for wide/over shots without rewriting old data. */
  clampGoalMouth=function(value){const n=suppliedNumber(value);return n===null?null:Math.max(-20,Math.min(120,n))};
  goalMouthRenderX=function(x){const n=clampGoalMouth(x);return n===null?null:20+n};
  goalMouthRenderY=function(y){const n=clampGoalMouth(y);return n===null?null:72-n*.58};
  goalMouthLabel=function(x,y){const gx=clampGoalMouth(x),gy=clampGoalMouth(y);if(gx===null||gy===null)return 'Not recorded';if(gy>104)return 'over the bar';if(gx<0)return 'wide left';if(gx>100)return 'wide right';if(Math.abs(gx)<=2)return 'left post area';if(Math.abs(gx-100)<=2)return 'right post area';if(Math.abs(gy-100)<=3)return 'crossbar area';const horiz=gx<33?'left':gx>67?'right':'centre',vert=gy<26?'low':gy>70?'high':'middle';return `${vert} ${horiz}`};
  if(typeof goalMouthPointX==='function')goalMouthPointX=function(x){return 20+Number(x)};
  if(typeof goalMouthPointY==='function')goalMouthPointY=function(y){return 72-Number(y)*.58};
  if(typeof goalMouthText==='function')goalMouthText=function(x,y){return goalMouthLabel(x,y)};
  const locationPickerBase=locationPicker;
  locationPicker=function(...args){
    let html=locationPickerBase(...args);
    const marker=html.match(/<circle class="goalmouth-marker"[^>]*>/)?.[0]||'<circle class="goalmouth-marker" cx="70" cy="43" r="3.2" hidden/>';
    const realistic=`<svg class="finish-location-pitch" viewBox="0 0 140 90" tabindex="0" role="button" aria-label="Select where the shot finished relative to the goal"><defs><linearGradient id="finishNetBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#32383d"/><stop offset="1" stop-color="#24292e"/></linearGradient></defs><path class="finish-goal-depth" d="M20 14 14 8h112l-6 6M20 72l-6 8h112l-6-8M14 8v72M126 8v72"/><rect class="finish-goal-net-bg" x="20" y="14" width="100" height="58" rx="1"/><path class="goalmouth-net finish-net" d="M20 28h100 M20 42h100 M20 56h100 M36 14v58 M52 14v58 M68 14v58 M84 14v58 M100 14v58"/><path class="finish-goal-frame" d="M20 72V14H120V72"/>${marker}</svg>`;
    html=html.replace(/<svg class="goalmouth-pitch"[\s\S]*?<\/svg>/,realistic);
    html=html.replace('Optional · mark exactly where the shot crossed or hit the goal / frame.','Select where the shot finished. The area also allows wide and over-the-bar attempts.');
    return html;
  };
  const capturePlusBase=typeof capturePlusEvent==='function'?capturePlusEvent:null;
  if(capturePlusBase)capturePlusEvent=function(e,v,prefix=''){e=capturePlusBase(e,v,prefix);if(shotTypes.includes(e.type)&&(v[prefix+'mouth-x']!==undefined||v[prefix+'mouth-y']!==undefined)){e.shot??={};const x=suppliedNumber(v[prefix+'mouth-x']),y=suppliedNumber(v[prefix+'mouth-y']);if(x!==null&&y!==null)e.shot.goalMouth={x:clampGoalMouth(x),y:clampGoalMouth(y)};else delete e.shot.goalMouth}return e};
  document.addEventListener('click',e=>{const pitch=e.target.closest?.('.finish-location-pitch');if(!pitch)return;e.preventDefault();e.stopPropagation();const box=pitch.closest('.location-input'),r=pitch.getBoundingClientRect(),vx=(e.clientX-r.left)/r.width*140,vy=(e.clientY-r.top)/r.height*90,x=Math.round((vx-20)*100)/100,y=Math.round(((72-vy)/.58)*100)/100;setGoalMouthLocation(box,clampGoalMouth(x),clampGoalMouth(y))},true);
  document.addEventListener('keydown',e=>{if(!e.target.matches?.('.finish-location-pitch'))return;if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Delete','Backspace','Escape'].includes(e.key))return;e.preventDefault();const box=e.target.closest('.location-input'),f=box?.closest('form'),p=box?.dataset.locationPrefix||'';if(!box||!f)return;if(['Delete','Backspace','Escape'].includes(e.key)){clearPickedLocation(box,'mouth');return}let x=suppliedNumber(f.elements.namedItem(p+'mouth-x')?.value)??50,y=suppliedNumber(f.elements.namedItem(p+'mouth-y')?.value)??50;if(e.key==='ArrowUp')y+=4;if(e.key==='ArrowDown')y-=4;if(e.key==='ArrowLeft')x-=4;if(e.key==='ArrowRight')x+=4;setGoalMouthLocation(box,clampGoalMouth(x),clampGoalMouth(y))},true);

  document.addEventListener('click',e=>{const button=e.target.closest?.('[data-profile-category]');if(!button)return;e.preventDefault();profileCompetitionCategory=button.dataset.profileCategory||'all';statsCompetition='';analyticsPlus.map='all';render()});
}
