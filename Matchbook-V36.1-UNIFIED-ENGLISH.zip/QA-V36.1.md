# V36.1 · wspólna paleta i angielskie nazwy/datowanie

## Statystyki

Zakładka Statistics zachowuje wszystkie elementy i funkcje wersji V36.
Nowe reguły dotyczą wyłącznie kolorów tła, tekstów, obramowań, wykresów i akcentów.
Nie zmieniają rozmiarów, marginesów, pozycjonowania, kolejności ani widoczności sekcji.

Automatyczna kontrola porównuje identyczność struktury HTML i geometrii kart
we wszystkich czterech widokach przy 390 i 1440 px, z nowym arkuszem włączonym
i wyłączonym. Ładowanie herbów kończy się przed porównaniem, aby zmiana obrazka
na inicjały nie była mylona z efektem kolorystyki.

Sprawdzono filtry rozgrywek, tryb Per 90, eksport CSV i wybieranie strzału klawiaturą.
Sześć dotychczasowych plików statystyk pozostaje bez zmian względem paczki V36.

## Historyczne opisy

Nowy moduł wyświetlania ujednolica znane nazwy rozgrywek i rozpoznane daty:

- `liga konferencji`, `Liga Konferencji`, `Lidze Konferencji` → `Conference League`;
- `Liga Mistrzów` → `Champions League`; `Liga Europy` → `Europa League`;
- `7 października 2026`, `7 paź. 2026`, `07.10.2026` → `7 October 2026`;
- w zwartych wierszach daty używają formy `7 Oct 2026`.

Daty numeryczne z kropką lub ukośnikiem są interpretowane jako dzień/miesiąc/rok.
Nieprawidłowe daty, sezony typu `2026/27`, wyniki, minuty, adresy URL i techniczne
znaczniki czasu pozostają zachowane. Tłumaczenie jest ograniczone do znanych nazw
i dat; reszta swobodnie napisanego opisu pozostaje oryginalna.

Oryginalne rekordy, pola edycji i kopie JSON nie są przepisywane. Angielski widok
działa także w kopiowanych raportach i kontekście kariery. Przetłumaczenie etykiety
opcji nie zmienia wartości używanej przez formularz lub filtr.

## Kontrole

- 6 testów nazw i dat: `node tests/history-english.test.cjs`.
- 5 scenariuszy przeglądarkowych: `python3 -m unittest discover -s tests -p test_theme.py -v`.
- Wbudowane regresje silnika: 20 zaliczonych, 0 błędów.
- Podglądy czterech widoków statystyk i wersji mobilnej: brak błędów JavaScript.

Testy używają syntetycznych danych i lokalnego serwera. Nie publikują nowego
wdrożenia Vercel ani nie zmieniają istniejących zapisów użytkownika.
