# Matchbook · V36.1 · Wspólna kolorystyka

Poprawiona wersja bazująca na paczce **V35.2 SINGLE DARK THEME OVERLAP FIX**.
Ogólny układ i format zapisanej kariery pozostają zachowane. Interfejs zachowuje
dotychczasowy język angielski.

## Nowy styl V36.1

- Nowa paleta: jasne papierowe tło, śliwkowa nawigacja i koralowe przyciski.
- Dopracowane karty, tabele, zakładki, kalendarz, skład, media i widoki kariery.
- Spójne okna profilu, sezonu, meczu, terminarza, transferu, składu, wyszukiwania,
  kopii zapasowej, odzyskiwania i wyboru zawodnika lub zdarzenia.
- Wygodniejsze pola, przyciski, komunikaty, odstępy i stany aktywne.
- Główna zakładka **Statistics** otrzymała tę samą paletę papier / śliwka / koral.
  Zachowuje wszystkie elementy, ich kolejność, wymiary i rozmieszczenie, mapę
  strzałów, filtry, eksport oraz poszczególne widoki. Porównanie struktury HTML
  i geometrii kart sprawdza, że arkusz zmienia jedynie oprawę kolorystyczną.
  Okienka korzystają z tego samego systemu wizualnego.
- Starsze opisy pokazują standardowe nazwy rozgrywek po angielsku, również przy
  małych literach i typowych polskich odmianach: „liga konferencji” → „Conference League”.
- Rozpoznane daty są prezentowane po angielsku, np. „7 października 2026” lub
  „07.10.2026” → „7 October 2026”. W wąskich wierszach używany jest skrót „7 Oct 2026”.
  Daty numeryczne w zapisie kropkowym i z ukośnikiem są interpretowane jako dzień/miesiąc/rok.
- Oryginalne opisy, pola edycji, linki i kopie JSON pozostają zachowane. Podmiana
  standardowych nazw i dat działa w widoku oraz w kopiowanych raportach/kontekście;
  nie jest pełnym tłumaczeniem dowolnej narracji na angielski.
- Format danych i sposób liczenia statystyk pozostają bez zmian.

## Zachowane poprawki V35.3

- Ciemna paleta grafitu i zieleni, czytelniejsze nagłówki i spójne stany przycisków.
- Nagłówki kart rosną wraz z treścią; panel startowy nie nachodzi na następny mecz.
- Statystyki mieszczą się na telefonach i korzystają z całej szerokości na komputerze.
- Sekcje **Overview / Performance / Matches / Career**, wykres ostatnich ocen,
  podsumowanie udziału przy golach i widoczny zakres dostępnych danych.
- Eksport CSV respektuje bieżące filtry i zabezpiecza tekst przed interpretacją
  jako formuły arkusza. Pełna kopia JSON nadal działa niezależnie.
- „All” obejmuje również występy reprezentacyjne powiązane z wybranym sezonem;
  „Entire career” obejmuje wszystkie sezony.
- Szczegółowe wskaźniki na 90 minut uwzględniają minuty tylko tych spotkań,
  w których daną metrykę zapisano. Nieznane dane nadal pokazują `—`.
- Wynik bez pełnego raportu nie generuje fałszywego ostrzeżenia o brakujących golach.
- Ręcznie dodane występy działają z filtrem miejsca meczu; ich podsumowania
  prawidłowo pokazują miejsce i nie przedstawiają nieznanego xG/xA jako zera.
- Ostatnie wyniki są sortowane po datach; nieznana data trafia do „Undated”.
- Niedostępne herby zachowują inicjały bez błędów JavaScript.
- Autouzupełnienie stadionu nie otwiera nieaktywnej listy i nie przesuwa przycisku
  rozpoczęcia meczu podczas klikania.
- Ponowne otwarcie przygotowania meczu i późniejsza edycja profilu nie dziedziczą
  starego układu formularza.
- Przyciski kopii zapasowej, wyszukiwania i chmury są dostępne na telefonie.
- Biblioteka chmury może pobrać się ponownie po błędzie; pobieranie ma limit czasu.
- Strona odzyskiwania udostępnia oryginalną kopię nieczytelnego zapisu.
- Usunięto nieaktualne wywołanie nieistniejącego pomocnika z testów wbudowanych;
  zastępuje je kontrola migracji jawnie zapisanych miejsc docelowych podań.

## Uruchomienie lokalne

Aplikacja nie wymaga instalacji zależności ani etapu budowania:

```sh
cd /workspace/sigma
python3 -m http.server 4173 --bind 127.0.0.1
```

Serwer statyczny obsługuje interfejs. Funkcja `api/fixture-difficulty.js` wymaga
środowiska Vercel Functions; zwykły serwer Pythona jej nie wykonuje.

## Testy

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m playwright install chromium
.venv/bin/python -m unittest discover -s tests -v
```

Kontrole nazw i dat: `node tests/history-english.test.cjs`.

Testy korzystają z syntetycznej kariery, osobnych kontekstów przeglądarki i lokalnego
serwera. Blokują połączenia zewnętrzne, nie logują do prawdziwej chmury i nie
modyfikują zapisów użytkownika. Wymagają także Node.js do sprawdzenia składni plików
JavaScript. Jeśli systemowy Chromium nie jest dostępny, używają przeglądarki
zainstalowanej przez Playwright. Opcjonalnie można wskazać binarkę przez
`MATCHBOOK_CHROMIUM_PATH`.

## Wdrożenie na Vercel

Prześlij pliki aplikacji jako katalog główny projektu. Ustaw preset **Other**, bez
komendy budowania, z katalogiem wyjściowym `.`. Zachowaj folder `api`.
Wersje zasobów w `index.html` są zaktualizowane dla zmienionych plików V36, aby przeglądarki pobrały poprawki.

Wdrożenie na tym samym adresie zachowuje dostęp do dotychczasowego localStorage.
Nowy adres ma osobny magazyn przeglądarki — przed zmianą domeny pobierz kopię JSON.
Format danych i klucz magazynu `fesedyo-career-v1` nie zostały zmienione.

Kod chmury zachowuje dotychczasową konfigurację Supabase. Pełne logowanie,
synchronizacja z rzeczywistym kontem i zewnętrzne źródła trudności terminarza
wymagają osobnego sprawdzenia z dostępem do tych usług. Lokalny pakiet nie publikuje
automatycznie zmian na istniejącym wdrożeniu.
